<?php
/**
 * Plugin Name: DP Cookie Consent
 * Description: Design Pixels cookiebanner met échte script-blocking, ingebouwde cookie-scanner (handmatig én periodiek via cron), automatische cookiebeleid-pagina, consent-logboek (bewijs van toestemming) en optionele Google Consent Mode v2. Tracking-scripts en embeds worden server-side geblokkeerd totdat de bezoeker toestemming geeft.
 * Version: 1.15.1
 * Author: Design Pixels
 * Author URI: https://designpixels.nl
 * Text Domain: dp-cookie-consent
 * GitHub Plugin URI: KoenKerkvliet/dp-cookie-consent
 * Primary Branch: main
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DPCC_VERSION', '1.15.1' );
define( 'DPCC_PATH', plugin_dir_path( __FILE__ ) );
define( 'DPCC_URL', plugin_dir_url( __FILE__ ) );
define( 'DPCC_COOKIE', 'dpcc_consent' );

require_once DPCC_PATH . 'includes/class-dpcc-services.php';
require_once DPCC_PATH . 'includes/class-dpcc-settings.php';
require_once DPCC_PATH . 'includes/class-dpcc-blocker.php';
require_once DPCC_PATH . 'includes/class-dpcc-banner.php';
require_once DPCC_PATH . 'includes/class-dpcc-scanner.php';
require_once DPCC_PATH . 'includes/class-dpcc-policy.php';
require_once DPCC_PATH . 'includes/class-dpcc-consent-log.php';
require_once DPCC_PATH . 'includes/class-dpcc-consent-mode.php';
require_once DPCC_PATH . 'includes/class-dpcc-admin.php';
require_once DPCC_PATH . 'includes/dp-menu-groep.php'; // gedeeld met alle DP-plugins

/**
 * Activatie: defaults + scan-sleutel aanmaken.
 */
register_activation_hook( __FILE__, function () {
    if ( ! get_option( 'dpcc_settings' ) ) {
        add_option( 'dpcc_settings', DPCC_Settings::defaults() );
    }
    if ( ! get_option( 'dpcc_scan_key' ) ) {
        add_option( 'dpcc_scan_key', wp_generate_password( 24, false, false ) );
    }
    DPCC_Scanner::instance()->reschedule();
    DPCC_Consent_Log::instance()->create_table();
    if ( ! wp_next_scheduled( 'dpcc_prune_consent_log' ) ) {
        wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'dpcc_prune_consent_log' );
    }
} );

register_deactivation_hook( __FILE__, function () {
    wp_clear_scheduled_hook( 'dpcc_auto_scan' );
    wp_clear_scheduled_hook( 'dpcc_prune_consent_log' );
} );

add_action( 'plugins_loaded', function () {
    DPCC_Blocker::instance()->init();
    DPCC_Banner::instance()->init();
    DPCC_Scanner::instance()->init();
    DPCC_Policy::instance()->init();
    DPCC_Consent_Log::instance()->init();
    DPCC_Consent_Mode::instance()->init();

    if ( is_admin() ) {
        DPCC_Admin::instance()->init();
    }
} );

/**
 * Lichte upgrade-routine: draait éénmalig na een versiewijziging (bijv. na een
 * Git Updater-update, waarbij de activatie-hook niet fired). Nu: de badge-cache
 * legen zodat de teller met de actuele logica herberekend wordt.
 */
add_action( 'admin_init', function () {
    if ( get_option( 'dpcc_version' ) === DPCC_VERSION ) {
        return;
    }
    delete_transient( 'dpcc_pending_scan_count' );
    update_option( 'dpcc_version', DPCC_VERSION, false );
} );
