/**
 * Cookiebeleid-pagina: automatische tekstcontrast-detectie.
 *
 * Meet de effectieve achtergrondkleur áchter de .dpcc-policy-content en zet
 * lichte tekst wanneer die achtergrond donker is. Zo blijft de pagina leesbaar
 * op zowel lichte als donkere secties, ongeacht het thema.
 */
(function () {
    'use strict';

    function parseRgb(str) {
        var m = String(str).match(/rgba?\(([^)]+)\)/);
        if (!m) {
            return null;
        }
        var parts = m[1].split(',').map(function (x) { return parseFloat(x); });
        if (parts.length < 3) {
            return null;
        }
        // Volledig transparant telt niet mee.
        if (parts.length >= 4 && parts[3] === 0) {
            return null;
        }
        return { r: parts[0], g: parts[1], b: parts[2] };
    }

    // Loop omhoog tot een element met een niet-transparante achtergrond.
    function effectiveBg(el) {
        var node = el;
        while (node && node.nodeType === 1) {
            var rgb = parseRgb(getComputedStyle(node).backgroundColor);
            if (rgb) {
                return rgb;
            }
            node = node.parentElement;
        }
        return { r: 255, g: 255, b: 255 };
    }

    function isDark(rgb) {
        // Eenvoudige relatieve luminantie (0 = zwart, 1 = wit).
        var l = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
        return l < 0.5;
    }

    function run() {
        var el = document.querySelector('.dpcc-policy');
        if (!el) {
            return;
        }
        el.classList.toggle('dpcc-policy--dark', isDark(effectiveBg(el)));
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }
})();
