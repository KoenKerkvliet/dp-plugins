/**
 * DP Cookie Consent — front-end consent manager.
 *
 * De server heeft tracking-scripts al herschreven naar type="text/plain"
 * en embed-iframes geneutraliseerd (src -> data-dpcc-src). Dit script:
 *  1. leest de consent-cookie
 *  2. toont de banner als er (nog) geen geldige consent is
 *  3. activeert na consent de toegestane scripts/embeds — pas dán worden ze
 *     daadwerkelijk uitgevoerd/geladen.
 */
(function () {
    'use strict';

    var cfg = window.dpccConfig || {};
    var COOKIE = cfg.cookieName || 'dpcc_consent';
    var CATEGORIES = cfg.categories || ['statistieken', 'marketing'];
    var VERSION = parseInt(cfg.consentVersion, 10) || 1;
    var EXPIRY_DAYS = parseInt(cfg.expiryDays, 10) || 180;
    var LABELS = cfg.labels || {};

    /* ------------------------------------------------------------------ */
    /*  Consent-cookie                                                     */
    /* ------------------------------------------------------------------ */

    function readConsent() {
        var match = document.cookie.match(new RegExp('(?:^|;\\s*)' + COOKIE + '=([^;]*)'));
        if (!match) {
            return null;
        }
        try {
            var data = JSON.parse(decodeURIComponent(match[1]));
            if (!data || parseInt(data.sv, 10) !== VERSION) {
                return null; // verouderde consent-versie -> opnieuw vragen
            }
            return data;
        } catch (e) {
            return null;
        }
    }

    function writeConsent(consent) {
        consent.sv = VERSION;
        consent.t = Math.floor(Date.now() / 1000);
        var value = encodeURIComponent(JSON.stringify(consent));
        var secure = location.protocol === 'https:' ? ';Secure' : '';
        document.cookie = COOKIE + '=' + value + ';path=/;max-age=' + (EXPIRY_DAYS * 86400) + ';SameSite=Lax' + secure;
    }

    /* Uniek consent-ID: koppelt het server-side logboek aan deze bezoeker. */
    function generateId() {
        try {
            if (window.crypto && crypto.getRandomValues) {
                var a = new Uint8Array(16);
                crypto.getRandomValues(a);
                return Array.prototype.map.call(a, function (b) {
                    return ('0' + b.toString(16)).slice(-2);
                }).join('');
            }
        } catch (e) {}
        return 'x' + Math.random().toString(16).slice(2) + Date.now().toString(16);
    }

    function consentId(existing) {
        if (existing && existing.cid) {
            return existing.cid;
        }
        return generateId();
    }

    /* Stuur de keuze naar het server-side logboek (bewijs van toestemming). */
    function logConsent(consent) {
        if (!cfg.logConsent || !cfg.restUrl) {
            return;
        }
        var payload = { cid: consent.cid, sv: VERSION, url: location.href, categories: {} };
        CATEGORIES.forEach(function (cat) {
            payload.categories[cat] = consent[cat] === true;
        });
        var body = JSON.stringify(payload);
        try {
            if (navigator.sendBeacon) {
                navigator.sendBeacon(cfg.restUrl, new Blob([body], { type: 'application/json' }));
                return;
            }
        } catch (e) {}
        try {
            fetch(cfg.restUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.restNonce || '' },
                body: body,
                keepalive: true,
                credentials: 'same-origin'
            });
        } catch (e) {}
    }

    function allowedCategories(consent) {
        var allowed = [];
        if (!consent) {
            return allowed;
        }
        CATEGORIES.forEach(function (cat) {
            if (consent[cat] === true) {
                allowed.push(cat);
            }
        });
        return allowed;
    }

    /* ------------------------------------------------------------------ */
    /*  Activeren van geblokkeerde scripts & iframes                       */
    /* ------------------------------------------------------------------ */

    function activateScripts(cats) {
        var blocked = Array.prototype.slice.call(
            document.querySelectorAll('script[type="text/plain"][data-dpcc]')
        );
        var queue = blocked.filter(function (s) {
            return cats.indexOf(s.getAttribute('data-dpcc')) !== -1 && !s.getAttribute('data-dpcc-done');
        });

        // Sequentieel uitvoeren zodat afhankelijkheden (loader -> init) kloppen.
        (function next() {
            var s = queue.shift();
            if (!s) {
                return;
            }
            s.setAttribute('data-dpcc-done', '1');

            var el = document.createElement('script');
            var type = s.getAttribute('data-dpcc-type');
            if (type) {
                el.type = type;
            }

            var src = s.getAttribute('src');
            if (src) {
                el.async = false;
                el.onload = next;
                el.onerror = next;
                el.src = src;
                s.parentNode.insertBefore(el, s.nextSibling);
            } else {
                el.text = s.text;
                s.parentNode.insertBefore(el, s.nextSibling);
                next();
            }
        })();
    }

    function activateIframes(cats) {
        Array.prototype.forEach.call(document.querySelectorAll('iframe[data-dpcc]'), function (frame) {
            if (cats.indexOf(frame.getAttribute('data-dpcc')) === -1) {
                return;
            }
            var placeholder = frame._dpccPlaceholder;
            if (placeholder && placeholder.parentNode) {
                placeholder.parentNode.removeChild(placeholder);
                frame._dpccPlaceholder = null;
            }
            frame.style.removeProperty('display');

            var lazy = frame.getAttribute('data-dpcc-lazy-src');
            if (lazy && !frame.getAttribute('data-src')) {
                frame.setAttribute('data-src', lazy);
            }
            var src = frame.getAttribute('data-dpcc-src');
            if (src && frame.getAttribute('src') !== src) {
                frame.setAttribute('src', src);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /*  Placeholders op geblokkeerde embeds                                */
    /* ------------------------------------------------------------------ */

    function buildPlaceholders(consent) {
        var allowed = allowedCategories(consent);

        Array.prototype.forEach.call(document.querySelectorAll('iframe[data-dpcc]'), function (frame) {
            var cat = frame.getAttribute('data-dpcc');
            if (allowed.indexOf(cat) !== -1 || frame._dpccPlaceholder) {
                return;
            }

            var src = frame.getAttribute('data-dpcc-src') || '';
            var host = '';
            try {
                host = new URL(src, location.href).hostname;
            } catch (e) {
                host = 'externe partij';
            }

            var box = document.createElement('div');
            box.className = 'dpcc-placeholder';

            var text = document.createElement('p');
            text.textContent = (LABELS.placeholder || 'Deze ingesloten content van %s is geblokkeerd totdat je toestemming geeft.').replace('%s', host);
            box.appendChild(text);

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'dpcc-btn dpcc-btn-primary';
            btn.textContent = LABELS.placeholderBtn || 'Content laden en cookies accepteren';
            btn.addEventListener('click', function () {
                grantCategory(cat);
            });
            box.appendChild(btn);

            frame.style.display = 'none';
            frame.parentNode.insertBefore(box, frame);
            frame._dpccPlaceholder = box;
        });
    }

    /* ------------------------------------------------------------------ */
    /*  Toepassen + banner-UI                                              */
    /* ------------------------------------------------------------------ */

    var ui = {};

    /* Google Consent Mode v2: stuur de huidige toestemming als 'update'. */
    function pushConsentMode(consent) {
        if (!cfg.consentMode) {
            return;
        }
        var stats = !!(consent && consent.statistieken === true);
        var mkt = !!(consent && consent.marketing === true);
        var params = {
            analytics_storage: stats ? 'granted' : 'denied',
            ad_storage: mkt ? 'granted' : 'denied',
            ad_user_data: mkt ? 'granted' : 'denied',
            ad_personalization: mkt ? 'granted' : 'denied'
        };
        // Bij voorkeur via de globale gtag (arguments-semantiek van Google);
        // valt terug op een directe dataLayer-push als gtag nog niet bestaat.
        if (typeof window.gtag === 'function') {
            window.gtag('consent', 'update', params);
        } else {
            (window.dataLayer = window.dataLayer || []).push(['consent', 'update', params]);
        }
    }

    function applyConsent(consent) {
        var allowed = allowedCategories(consent);
        if (allowed.length) {
            activateScripts(allowed);
            activateIframes(allowed);
        }
        pushConsentMode(consent);
        buildPlaceholders(consent);
        document.dispatchEvent(new CustomEvent('dpcc:consent', { detail: { consent: consent, allowed: allowed } }));
    }

    function newConsent(statistieken, marketing) {
        return { statistieken: !!statistieken, marketing: !!marketing };
    }

    function saveAndApply(consent) {
        if (!consent.cid) {
            consent.cid = consentId(readConsent());
        }
        writeConsent(consent);
        logConsent(consent);
        applyConsent(consent);
        hideBanner();
        showBadge();
    }

    function grantCategory(cat) {
        var consent = readConsent() || newConsent(false, false);
        consent[cat] = true;
        saveAndApply(consent);
    }

    /* ------------------------------------------------------------------ */
    /*  Toegankelijkheid: focusbeheer + focus-trap + Escape                */
    /* ------------------------------------------------------------------ */

    function focusable(container) {
        if (!container) {
            return [];
        }
        var sel = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
        return Array.prototype.filter.call(container.querySelectorAll(sel), function (el) {
            return !el.disabled && el.offsetParent !== null; // zichtbaar én bruikbaar
        });
    }

    function handleKeydown(e) {
        var key = e.key || '';

        // Escape sluit het voorkeuren-paneel (niet de hele banner: geen keuze
        // afdwingen of stilzwijgend wegklikken).
        if (key === 'Escape' || e.keyCode === 27) {
            if (ui.prefs && !ui.prefs.hidden) {
                setPrefs(false);
                if (ui.openPrefs) {
                    ui.openPrefs.focus();
                }
            }
            return;
        }

        // Tab-focus binnen de banner houden zolang die open staat.
        if (key === 'Tab' || e.keyCode === 9) {
            var f = focusable(ui.banner);
            if (!f.length) {
                return;
            }
            var first = f[0];
            var last = f[f.length - 1];
            if (e.shiftKey && document.activeElement === first) {
                e.preventDefault();
                last.focus();
            } else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }

    function setPrefs(open) {
        if (ui.prefs) {
            ui.prefs.hidden = !open;
        }
        if (ui.save) {
            ui.save.hidden = !open;
        }
        if (ui.openPrefs) {
            ui.openPrefs.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
    }

    function focusBadge() {
        if (ui.badge && !ui.badge.hidden) {
            try {
                ui.badge.focus();
            } catch (e) {}
        }
    }

    /* ------------------------------------------------------------------ */

    function showBanner(consent) {
        if (!ui.banner) {
            return;
        }
        // Voorkeuren-checkboxes vooraf invullen met huidige stand.
        CATEGORIES.forEach(function (cat) {
            var box = document.getElementById('dpcc-cat-' + cat);
            if (box) {
                box.checked = !!(consent && consent[cat]);
            }
        });
        ui.banner.hidden = false;
        if (ui.badge) {
            ui.badge.hidden = true;
        }
        // Focus in de banner zetten zodat toetsenbord-/schermlezergebruikers
        // de melding direct bereiken.
        try {
            ui.banner.focus();
        } catch (e) {}
    }

    function hideBanner() {
        if (ui.banner) {
            ui.banner.hidden = true;
        }
        setPrefs(false);
    }

    function showBadge() {
        if (ui.badge) {
            ui.badge.hidden = false;
        }
    }

    function bindUi() {
        ui.banner = document.getElementById('dpcc-banner');
        ui.prefs = document.getElementById('dpcc-prefs');
        // Heropen-control: rond icoon (#dpcc-badge) of smalle strook (#dpcc-tab).
        // Slechts één van beide staat in de DOM; de rest van de UI-logica
        // (tonen/verbergen/focus/klik) werkt identiek voor allebei.
        ui.badge = document.getElementById('dpcc-badge') || document.getElementById('dpcc-tab');
        ui.save = document.getElementById('dpcc-save');
        ui.openPrefs = document.getElementById('dpcc-open-prefs');

        var accept = document.getElementById('dpcc-accept');
        var reject = document.getElementById('dpcc-reject');

        if (accept) {
            accept.addEventListener('click', function () {
                saveAndApply(newConsent(true, true));
                focusBadge();
            });
        }
        if (reject) {
            reject.addEventListener('click', function () {
                saveAndApply(newConsent(false, false));
                focusBadge();
            });
        }
        if (ui.openPrefs) {
            ui.openPrefs.addEventListener('click', function () {
                setPrefs(ui.prefs ? ui.prefs.hidden : true);
            });
        }
        if (ui.save) {
            ui.save.addEventListener('click', function () {
                var stats = document.getElementById('dpcc-cat-statistieken');
                var marketing = document.getElementById('dpcc-cat-marketing');
                saveAndApply(newConsent(stats && stats.checked, marketing && marketing.checked));
                focusBadge();
            });
        }
        if (ui.badge) {
            ui.badge.addEventListener('click', function () {
                showBanner(readConsent());
            });
        }
        if (ui.banner) {
            ui.banner.addEventListener('keydown', handleKeydown);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Global Privacy Control / Do-Not-Track                              */
    /* ------------------------------------------------------------------ */

    function optOutSignal() {
        try {
            if (navigator.globalPrivacyControl === true) {
                return true;
            }
        } catch (e) {}
        var dnt = navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack;
        return dnt === '1' || dnt === 'yes';
    }

    /* ------------------------------------------------------------------ */
    /*  Start                                                              */
    /* ------------------------------------------------------------------ */

    function boot() {
        bindUi();
        var consent = readConsent();
        if (consent) {
            applyConsent(consent);
            hideBanner();
            showBadge();
            return;
        }
        // Respecteer een opt-out-signaal van de browser: automatisch weigeren,
        // geen banner tonen (de bezoeker heeft z'n voorkeur al kenbaar gemaakt).
        if (cfg.honorGpc && optOutSignal()) {
            saveAndApply(newConsent(false, false));
            return;
        }
        buildPlaceholders(null);
        showBanner(null);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
