<?php
/**
 * Opruimen bij verwijderen van de plugin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

wp_clear_scheduled_hook( 'dpcc_auto_scan' );
wp_clear_scheduled_hook( 'dpcc_prune_consent_log' );

delete_option( 'dpcc_settings' );
delete_option( 'dpcc_scan_key' );
delete_option( 'dpcc_scan_results' );
delete_option( 'dpcc_scan_changes' );
delete_option( 'dpcc_browser_results' );
delete_option( 'dpcc_cookie_register' );
delete_transient( 'dpcc_pending_scan_count' );
delete_post_meta_by_key( '_dpcc_scanned' );
delete_option( 'dpcc_log_db_version' );
// De cookiebeleid-pagina zelf blijft bewust staan (inhoud van de site).
delete_option( 'dpcc_policy_page_id' );

// Consent-logboek verwijderen.
global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}dpcc_consent_log" ); // phpcs:ignore
