=== DP Cookie Consent ===
Contributors: designpixels
Tags: cookies, consent, gdpr, avg, cookie banner
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.15.1
License: GPLv2 or later

Design Pixels cookiebanner met échte script-blocking en ingebouwde cookie-scanner.

== Description ==

Cookiebanner die tracking-scripts en embeds daadwerkelijk server-side blokkeert totdat de bezoeker toestemming geeft — geen cosmetische banner.

* **Echte blocking**: bekende trackers (Google Analytics, GTM, Meta Pixel, Hotjar, Clarity, LinkedIn, TikTok, etc.) worden in de HTML-output herschreven naar `type="text/plain"` en pas na consent uitgevoerd. Embeds (YouTube, Vimeo, Google Maps) krijgen een placeholder.
* **Cache-safe**: er wordt altijd geblokkeerd in de HTML; activatie gebeurt client-side op basis van de consent-cookie. Werkt dus ook correct achter LiteSpeed of andere page-caches.
* **Cookie-scanner**: scant de site en toont welke diensten en cookies er draaien, plus onbekende externe scripts.
* **Cookie-overzicht**: shortcode `[dpcc_cookies]` voor een automatische tabel op de cookieverklaring-pagina.
* **AVG-proof UX**: weigeren is net zo makkelijk als accepteren (beide op het eerste scherm), voorkeuren per categorie, consent-versie ophogen om opnieuw toestemming te vragen.

== Changelog ==

= 1.14.1 =
* Fix: de sidebar-badge telt nu alleen nog niet-gescande pagina's en berichten, niet elk los custom-post-type-item (FAQ's, reviews, portfolio, enz.) of Bricks-templates. Die deelden toch hun template. Custom post types worden voortaan met één voorbeeld per type meegescand (template-dekking), en Bricks-templates worden overgeslagen. Zo klopt de badge met wat je als "pagina" ziet en loopt hij na een volledige scan naar 0.

= 1.14.0 =
* Verbeterd: de browser-scan rapporteert nu alleen cookies en opslag die de gescande pagina's zélf zetten. Aan het begin van een scan wordt vastgelegd wat er al in de browser van de beheerder stond (cookies + local/session storage); die "voorraad" wordt weggefilterd, tenzij het een bekende tracker is. Zo verdwijnen builder-/admin-restanten (bijv. van de Bricks-editor) en oude cookies van verwijderde plugins uit het resultaat, terwijl echte trackers als _ga zichtbaar blijven — ook als je ze zelf al had geaccepteerd. Cookies die je eerder handmatig als statistiek/marketing classificeerde tellen ook als tracker.
* Nieuw: PostHog wordt herkend en geblokkeerd (product-analytics).
* Verbeterd: de heropen-strook is iets breder in ingeklapte staat (blijft even laag).

= 1.13.0 =
* Nieuw: cookie-register. Onbekende cookies uit de browser-scan classificeer je nu met één dropdown-keuze (noodzakelijk/statistieken/marketing/negeren, optioneel met dienstnaam) — daarna worden ze overal herkend én automatisch opgenomen in de [dpcc_cookies]-tabel op de beleidspagina.
* Nieuw: scan-geheugen + badge. De scanner onthoudt per pagina wanneer die gescand is; nog-nooit-gescande pagina's krijgen voorrang in de scanlijst en het aantal verschijnt als badge naast "Cookiebanner" in de admin-sidebar. Publiceer je een nieuwe pagina, dan zie je dus meteen dat er gescand moet worden. Eerder gescande pagina's rouleren automatisch mee (oudste eerst), zodat later toegevoegde trackers ook gevonden worden.
* Verbeterd: één scan-knop. "Scan de site nu" draait nu automatisch beide stappen: eerst de server-scan (diensten, onbekende scripts, server-cookies), direct daarna de browser-scan (JavaScript-cookies). De automatische periodieke scan blijft server-only draaien.
* Verbeterd: veel meer cookies worden out-of-the-box herkend (WordPress-reacties/beveiligde pagina's, Polylang/WPML, LiteSpeed, Cloudflare, Stripe, WPForms, Jetpack, Mailchimp/MailPoet, andere cookiebanners).

= 1.12.0 =
* Nieuw: browser-scan. Naast de server-side scan kan de scanner nu de pagina's in een verborgen venster in de browser van de beheerder laden, alle scripts echt laten draaien en daarna aflezen welke cookies en local/session storage-sleutels er daadwerkelijk gezet zijn — inclusief cookies die puur via JavaScript gezet worden (zoals _ga, _fbp, _hj*) en die de server-side scan per definitie mist. Gevonden cookies worden automatisch herkend (bekende diensten + WordPress-/WooCommerce-basiscookies); onbekende cookies worden gemarkeerd.
* Verbeterd: de scanner neemt nu ook één voorbeeldpagina per publiek custom post type mee, plus de webshop-pagina's (winkelwagen, afrekenen, account) waar sessie-cookies ontstaan.
* Verbeterd: de heropen-strook is gehalveerd (14px) — ingeklapt alleen een pijltje-omhoog, bij hover klapt hij uit met de tekst. Nieuw: instelbare randkleur en schaduw aan/uit voor de strook.

= 1.11.0 =
* Nieuw: keuze voor de heropen-knop. Naast het bekende ronde cookie-icoon kun je nu een smalle strook onderin kiezen (Complianz-stijl): een plat balkje tegen de onderrand dat ingeklapt alleen het icoon toont en bij hover uitklapt met een tekst ("Beheer toestemming", instelbaar). Zo blijft het laag bij de grond en botst het niet met een zwevende chat- of "terug naar boven"-knop. De strook volgt de positie (links/rechts); "midden onder" valt terug op links. De eigen icoon-kleuren gelden voor beide varianten.

= 1.10.1 =
* Fix/robuustheid: de kleurkiezers in de instellingen gebruiken nu WordPress' eigen inline kleurkiezer (Iris) in plaats van de native browser-/OS-kleurdialoog. Die kon in sommige gevallen vastlopen (aanhoudende pieptoon bij elke klik). Valt de JS weg, dan blijft het een gewoon tekstveld voor een hex-code.

= 1.10.0 =
* Nieuw: het cookie-icoon (cirkel + pictogram) is nu apart van de banner te stylen. Zet "apart stylen" aan en kies eigen kleuren voor het pictogram en de cirkel; bij hover wisselen die twee. Staat het uit, dan volgt het icoon de banner zoals voorheen. De banner (accent/achtergrond/tekst) en het icoon zijn zo volledig onafhankelijk in te stellen.

= 1.9.0 =
* Nieuw: de cookiebeleid-pagina detecteert automatisch een donkere achtergrond en zet dan lichte tekst, zodat de pagina op elke sectie leesbaar blijft.
* Verbeterd: kies je in de instellingen bewust een accentkleur, dan springt "Accent-kleur" automatisch op "Eigen kleur" zodat die kleur ook echt op de frontend verschijnt (icoon + banner). Verduidelijkt dat het cookie-icoon de Accent- en Achtergrond-kleuren gebruikt.

= 1.8.0 =
* Nieuw: toegankelijkheid. De banner is een echte toegankelijke dialog: focus verspringt bij openen naar de banner, Tab blijft binnen de banner (focus-trap), Escape sluit het voorkeuren-paneel, en na een keuze gaat focus terug naar het cookie-icoon. Plus aria-modal/aria-describedby/aria-expanded.
* Nieuw: Global Privacy Control / Do-Not-Track. Stuurt de browser een opt-out-signaal, dan wordt automatisch geweigerd en verschijnt de banner niet (instelbaar, standaard aan). Een eerder gegeven expliciete keuze blijft leidend.

= 1.7.0 =
* Nieuw: optionele Google Consent Mode v2. Aan te zetten in de instellingen. Zet vroeg in de head alle Google-consent-signalen op 'denied', laat Google-tags (GTM/Analytics/Ads) cookieloos in denied-modus draaien i.p.v. hard te blokkeren, en stuurt bij toestemming een 'update'-signaal. Overige trackers blijven hard geblokkeerd tot toestemming. Standaard uit (strengste gedrag blijft de default).

= 1.6.0 =
* Nieuw: zoeken & verifiëren in het consent-logboek. Zoek op (deel van) het consent-ID en klik op een "Ref." voor het volledige record; verifieer een IP-adres (wordt gehasht met de sitesleutel) om te zien of/wanneer dat IP toestemming gaf. Zo koppel je een record aan een bezoeker zonder ruwe IP-opslag.

= 1.5.0 =
* Nieuw: consent-logboek (bewijs van toestemming, AVG art. 7). Elke keuze wordt server-side vastgelegd in een eigen tabel: consent-ID (ook in de cookie), tijdstip, keuzes per categorie, consent-versie, URL, gepseudonimiseerd IP (HMAC-hash) en user-agent. Nieuw tabblad "Consent-log" met overzicht en CSV-export, instelbare bewaartermijn met dagelijkse opruiming via cron.

= 1.4.1 =
* Banner: compacter (lagere hoogte) en breder; de knoppen Accepteren, Weigeren en Voorkeuren staan nu altijd op één rij. De knop "Voorkeuren opslaan" staat in het voorkeuren-paneel.

= 1.4.0 =
* Nieuw: instelbaar contact-e-mailadres voor het cookiebeleid (standaard info@<domein>). Het adres wordt via een token op rendertijd ingevuld, dus wijzigen werkt direct door op de bestaande pagina.
* Nieuw: banner-accent volgt standaard de ACSS-kleur --primary van de site (met de ingestelde hex als fallback). Instelbaar op "eigen kleur" indien gewenst.

= 1.3.1 =
* Fix: dubbele "Cookiebeleid"-titel. De titel-kop staat niet meer in de content (het thema toont de paginatitel al) en wordt op bestaande pagina's op rendertijd weggehaald.

= 1.3.0 =
* Nieuw: de cookiebeleid-pagina wordt automatisch gestyled. De content krijgt op rendertijd een .dpcc-policy-wrapper en een eigen stylesheet die ACSS-tokens (--primary, --space-*, --text-*) met fallbacks gebruikt, zodat de pagina de brand van de site overneemt. Geen wijziging aan de opgeslagen content; werkt ook op de reeds aangemaakte pagina.

= 1.2.0 =
* Nieuw: automatische periodieke cookie-scan via WP-cron, instelbaar (uit / 1 / 2 / 3 / 6 / 12 maanden).
* Nieuw: bij gevonden wijzigingen wordt de "Laatst bijgewerkt"-datum van de beleidspagina automatisch bijgewerkt; bij nieuwe consent-plichtige diensten wordt de consent-versie opgehoogd zodat bezoekers opnieuw om toestemming gevraagd worden.
* De knop "Maak cookiebeleid-pagina aan" is pas beschikbaar nadat er een scan is uitgevoerd (anders zou de cookie-tabel leeg zijn).

= 1.1.0 =
* Nieuw: automatische cookiebeleid-pagina. Eén klik genereert een complete beleidspagina (uitleg, categorieën, [dpcc_cookies]-tabel, intrekken van toestemming, AVG-rechten, contact) en koppelt die als beleids-URL aan de banner.

= 1.0.0 =
* Eerste release: banner, server-side script/iframe-blocking, cookie-scanner, shortcode [dpcc_cookies], instellingenpagina.
