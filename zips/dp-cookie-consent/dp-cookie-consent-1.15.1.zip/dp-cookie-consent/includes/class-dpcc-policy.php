<?php
/**
 * Cookiebeleid-pagina: genereert een complete beleidspagina (incl. de
 * [dpcc_cookies]-overzichtstabel) en koppelt die aan de banner.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Policy {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'admin_post_dpcc_create_policy', [ $this, 'handle_create_request' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );
        add_filter( 'the_content', [ $this, 'wrap_content' ], 20 );
    }

    /**
     * De pagina-ID uit de instellingen.
     */
    private function page_id() {
        return (int) get_option( 'dpcc_policy_page_id' );
    }

    /**
     * Laad de beleids-styling, maar alleen op de beleidspagina zelf.
     */
    public function enqueue() {
        $page_id = $this->page_id();
        if ( $page_id && is_page( $page_id ) ) {
            wp_enqueue_style( 'dpcc-policy', DPCC_URL . 'assets/css/dpcc-policy.css', [], DPCC_VERSION );
            wp_enqueue_script( 'dpcc-policy', DPCC_URL . 'assets/js/dpcc-policy.js', [], DPCC_VERSION, true );
        }
    }

    /**
     * Wrap de content van de beleidspagina in .dpcc-policy zodat de styling
     * deterministisch scope't, onafhankelijk van thema of pagebuilder.
     *
     * Gebeurt op rendertijd — geen wijziging in de opgeslagen content, dus
     * de gebruiker kan de pagina vrij bewerken zonder dat de wrapper stoort.
     */
    public function wrap_content( $content ) {
        $page_id = $this->page_id();
        if ( ! $page_id || ! is_page( $page_id ) || ! is_main_query() || ! in_the_loop() ) {
            return $content;
        }
        if ( false !== strpos( $content, 'class="dpcc-policy"' ) ) {
            return $content;
        }

        // Contact-e-mail dynamisch invullen: het {dpcc_email}-token resolven
        // (nieuwe pagina's) én een eerder ingebakken adres vervangen (bestaande
        // pagina's). Zo volgt het adres altijd de instelling zonder DB-wijziging.
        $email = sanitize_email( (string) DPCC_Settings::val( 'contact_email' ) );
        if ( ! $email ) {
            $email = (string) get_option( 'admin_email' );
        }
        $content = str_replace( '{dpcc_email}', esc_html( $email ), $content );
        $admin   = (string) get_option( 'admin_email' );
        if ( $admin && $email && $admin !== $email ) {
            $content = str_replace( $admin, esc_html( $email ), $content );
        }

        // Het thema toont de paginatitel al; verwijder een dubbele titel-kop
        // bovenaan de content (voor pagina's aangemaakt vóór v1.3.1).
        $title = get_the_title( $page_id );
        if ( $title ) {
            $content = preg_replace(
                '#^\s*<h2[^>]*>\s*' . preg_quote( $title, '#' ) . '\s*</h2>\s*#i',
                '',
                $content,
                1
            );
        }

        return '<div class="dpcc-policy">' . $content . '</div>';
    }

    /**
     * De eerder door ons aangemaakte pagina, of null.
     */
    public function existing_page() {
        $page_id = (int) get_option( 'dpcc_policy_page_id' );
        if ( $page_id ) {
            $page = get_post( $page_id );
            if ( $page && 'page' === $page->post_type && 'trash' !== $page->post_status ) {
                return $page;
            }
        }
        return null;
    }

    /**
     * POST-handler vanaf de admin-pagina.
     */
    public function handle_create_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_create_policy' );

        $existing = $this->existing_page();
        if ( $existing ) {
            wp_safe_redirect( add_query_arg(
                [ 'page' => 'dp-cookie-consent', 'dpcc_policy_exists' => 1 ],
                admin_url( 'admin.php' )
            ) );
            exit;
        }

        // Eerst scannen, dan pas een beleidspagina — anders is de tabel leeg.
        $results = get_option( 'dpcc_scan_results', [] );
        if ( empty( $results['time'] ) ) {
            wp_safe_redirect( add_query_arg(
                [ 'page' => 'dp-cookie-consent', 'dpcc_policy_noscan' => 1 ],
                admin_url( 'admin.php' )
            ) );
            exit;
        }

        $page_id = $this->create_page();

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'dp-cookie-consent', 'dpcc_policy_created' => is_wp_error( $page_id ) ? 0 : 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /**
     * Maak de pagina aan en koppel 'm als beleids-URL aan de banner.
     *
     * @return int|WP_Error pagina-ID
     */
    public function create_page() {
        $page_id = wp_insert_post( [
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => 'Cookiebeleid',
            'post_name'    => 'cookiebeleid',
            'post_content' => $this->content(),
        ], true );

        if ( is_wp_error( $page_id ) ) {
            return $page_id;
        }

        update_option( 'dpcc_policy_page_id', $page_id );

        // Beleids-URL in de banner-instellingen zetten (alleen als nog leeg).
        $settings = DPCC_Settings::get();
        if ( empty( $settings['policy_url'] ) ) {
            $settings['policy_url'] = get_permalink( $page_id );
            update_option( 'dpcc_settings', $settings );
        }

        return $page_id;
    }

    /**
     * Werk de "Laatst bijgewerkt"-datum op de beleidspagina bij.
     * Aangeroepen wanneer een scan wijzigingen in de dienstenlijst vindt —
     * de cookie-tabel zelf ([dpcc_cookies]) is al dynamisch.
     */
    public function touch_date() {
        $page = $this->existing_page();
        if ( ! $page ) {
            return;
        }

        $content = $page->post_content;
        $updated = preg_replace(
            '/Laatst bijgewerkt: [^<]*/u',
            'Laatst bijgewerkt: ' . wp_date( 'j F Y' ),
            $content,
            1
        );

        if ( is_string( $updated ) && $updated !== $content ) {
            wp_update_post( [
                'ID'           => $page->ID,
                'post_content' => wp_slash( $updated ),
            ] );
        }
    }

    /**
     * De beleids-tekst. Bewust gewone HTML: werkt in de block-editor
     * (classic block) én in pagebuilder-omgevingen.
     */
    public function content() {
        $site_name = get_bloginfo( 'name' );
        $site_url  = home_url( '/' );
        $date      = wp_date( 'j F Y' );

        // Geen titel-kop hier: het thema toont de paginatitel al (voorkomt dubbele "Cookiebeleid").
        $content = <<<HTML
<p><em>Laatst bijgewerkt: {date}</em></p>

<p>{site_name} ({site_url}) gebruikt cookies. In dit cookiebeleid leggen we uit wat cookies zijn, welke cookies wij gebruiken, met welk doel, en hoe je jouw voorkeuren kunt beheren of intrekken.</p>

<h3>Wat zijn cookies?</h3>
<p>Cookies zijn kleine tekstbestanden die bij het bezoeken van een website op je computer, tablet of telefoon worden opgeslagen. Ze zorgen er bijvoorbeeld voor dat de website goed werkt, onthouden je voorkeuren, of geven ons inzicht in hoe bezoekers de site gebruiken. Naast cookies bestaan er vergelijkbare technieken zoals scripts en pixels; waar we in dit beleid "cookies" schrijven, bedoelen we ook die technieken.</p>

<h3>Welke categorie&euml;n gebruiken wij?</h3>
<p><strong>Noodzakelijke cookies.</strong> Deze zijn vereist voor de basisfunctionaliteit van de website, zoals het onthouden van jouw cookie-voorkeuren en beveiliging van formulieren. Hiervoor is geen toestemming vereist; ze worden altijd geplaatst.</p>
<p><strong>Statistiek-cookies.</strong> Hiermee meten we anoniem hoe bezoekers de website gebruiken, zodat we de site kunnen verbeteren. Deze plaatsen we alleen met jouw toestemming.</p>
<p><strong>Marketing- &amp; embed-cookies.</strong> Deze worden gebruikt voor advertentiedoeleinden en door ingesloten content van derden, zoals YouTube-video's en Google Maps-kaarten. Deze plaatsen we alleen met jouw toestemming. Zonder toestemming zie je in plaats van de ingesloten content een melding met de mogelijkheid om die alsnog te laden.</p>

<h3>Hoe blokkeren wij cookies zonder toestemming?</h3>
<p>Wij tonen niet alleen een cookiebanner: scripts en ingesloten content in de categorie&euml;n statistieken en marketing worden daadwerkelijk niet geladen en niet uitgevoerd totdat je daarvoor toestemming geeft. Geef je geen (of gedeeltelijke) toestemming, dan worden de bijbehorende cookies dus ook echt niet geplaatst.</p>

<h3>Overzicht van cookies op deze website</h3>
<p>Onderstaande tabel wordt automatisch samengesteld op basis van de meest recente scan van deze website.</p>

[dpcc_cookies]

<h3>Toestemming aanpassen of intrekken</h3>
<p>Je kunt jouw keuze op elk moment aanpassen of intrekken via het cookie-icoon onderaan de pagina. Daar kun je per categorie toestemming geven of weigeren. Het intrekken van toestemming geldt vanaf dat moment; al geplaatste cookies kun je daarnaast zelf verwijderen via je browser.</p>
<p>Cookies verwijderen of blokkeren kan ook via de instellingen van je browser:</p>
<ul>
<li><a href="https://support.google.com/chrome/answer/95647?hl=nl" rel="noopener" target="_blank">Google Chrome</a></li>
<li><a href="https://support.mozilla.org/nl/kb/cookies-verwijderen-gegevens-wissen-websites-opgeslagen" rel="noopener" target="_blank">Mozilla Firefox</a></li>
<li><a href="https://support.apple.com/nl-nl/guide/safari/sfri11471/mac" rel="noopener" target="_blank">Safari</a></li>
<li><a href="https://support.microsoft.com/nl-nl/microsoft-edge/cookies-verwijderen-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" rel="noopener" target="_blank">Microsoft Edge</a></li>
</ul>
<p>Houd er rekening mee dat de website mogelijk niet optimaal werkt als je alle cookies blokkeert.</p>

<h3>Cookies van derden</h3>
<p>Sommige cookies worden geplaatst door derde partijen (zoals Google of Meta) wanneer je toestemming geeft voor statistiek- of marketing-cookies. Op het gebruik van die cookies is het privacybeleid van de betreffende partij van toepassing. Wij hebben geen controle over wat deze partijen met de verzamelde gegevens doen.</p>

<h3>Jouw rechten</h3>
<p>Op grond van de Algemene Verordening Gegevensbescherming (AVG) heb je onder andere recht op inzage, rectificatie en verwijdering van jouw persoonsgegevens, en het recht om een eerder gegeven toestemming in te trekken. Je hebt daarnaast het recht een klacht in te dienen bij de <a href="https://www.autoriteitpersoonsgegevens.nl/" rel="noopener" target="_blank">Autoriteit Persoonsgegevens</a>.</p>

<h3>Contact</h3>
<p>Vragen over dit cookiebeleid? Neem contact met ons op via <a href="mailto:{dpcc_email}">{dpcc_email}</a>.</p>

<p><em>Wij kunnen dit cookiebeleid aanpassen wanneer onze website of de regelgeving verandert. Bij ingrijpende wijzigingen vragen we je opnieuw om toestemming.</em></p>
HTML;

        // {dpcc_email} blijft bewust als token staan: dat wordt op rendertijd
        // ingevuld vanuit de instelling (zie wrap_content).
        $content = strtr( $content, [
            '{site_name}' => esc_html( $site_name ),
            '{site_url}'  => esc_html( $site_url ),
            '{date}'      => esc_html( $date ),
        ] );

        return apply_filters( 'dpcc_policy_content', $content );
    }
}
