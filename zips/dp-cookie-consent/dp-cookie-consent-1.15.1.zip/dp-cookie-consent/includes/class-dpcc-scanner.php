<?php
/**
 * Cookie-scanner: haalt een set pagina's van de site op (met scan-bypass zodat
 * de blocker niet in de weg zit) en detecteert bekende diensten, onbekende
 * externe scripts en first-party cookies uit de HTTP-headers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Scanner {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'admin_post_dpcc_scan', [ $this, 'handle_scan_request' ] );
        add_action( 'dpcc_auto_scan', [ $this, 'run_scan_and_process' ] );
        add_filter( 'cron_schedules', [ $this, 'cron_schedules' ] );

        // Browser-scan: collector op de frontend (alleen voor ingelogde
        // beheerders met geldige scan-key) + REST-endpoint voor de resultaten.
        add_action( 'wp_footer', [ $this, 'inject_collector' ], 9999 );
        add_action( 'rest_api_init', [ $this, 'register_browser_scan_rest' ] );

        // Badge-teller verversen zodra er nieuwe content gepubliceerd wordt.
        add_action( 'transition_post_status', [ $this, 'maybe_flush_pending_count' ], 10, 3 );
    }

    /* ------------------------------------------------------------------ */
    /*  Automatische scan (WP-cron)                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Eigen cron-interval, gebaseerd op de instelling (in maanden).
     */
    public function cron_schedules( $schedules ) {
        $months = max( 1, (int) DPCC_Settings::val( 'auto_scan_interval' ) );

        $schedules['dpcc_auto_scan_interval'] = [
            'interval' => $months * MONTH_IN_SECONDS,
            'display'  => sprintf( 'DP Cookie Consent: elke %d maand(en)', $months ),
        ];
        return $schedules;
    }

    /**
     * (Her)plan de automatische scan op basis van de huidige instelling.
     * Aanroepen na settings-save, bij activatie en als self-heal na updates.
     */
    public function reschedule() {
        wp_clear_scheduled_hook( 'dpcc_auto_scan' );

        $months = (int) DPCC_Settings::val( 'auto_scan_interval' );
        if ( $months > 0 ) {
            wp_schedule_event( time() + $months * MONTH_IN_SECONDS, 'dpcc_auto_scan_interval', 'dpcc_auto_scan' );
        }
    }

    /**
     * Zorg dat het cron-event bestaat als de instelling aan staat
     * (bijv. na een plugin-update waarbij de activatie-hook niet fired).
     */
    public function ensure_scheduled() {
        if ( (int) DPCC_Settings::val( 'auto_scan_interval' ) > 0 && ! wp_next_scheduled( 'dpcc_auto_scan' ) ) {
            $this->reschedule();
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Scan uitvoeren + wijzigingen verwerken                             */
    /* ------------------------------------------------------------------ */

    /**
     * POST-handler vanaf de admin-pagina.
     */
    public function handle_scan_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_scan' );

        $this->run_scan_and_process();

        // Aangeroepen vanuit de gecombineerde scan-knop (fetch): geen redirect,
        // de browser-scan neemt het stokje over.
        if ( ! empty( $_POST['dpcc_ajax'] ) ) {
            wp_send_json_success();
        }

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'dp-cookie-consent', 'tab' => 'scanner', 'dpcc_scanned' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /**
     * Scan draaien, resultaten opslaan en wijzigingen afhandelen.
     * Wordt gebruikt door zowel de handmatige knop als het cron-event.
     */
    public function run_scan_and_process() {
        $old     = get_option( 'dpcc_scan_results', [] );
        $results = $this->scan();
        update_option( 'dpcc_scan_results', $results, false );
        $this->handle_changes( is_array( $old ) ? $old : [], $results );
    }

    /**
     * Vergelijk oude en nieuwe scanresultaten. Bij wijzigingen:
     *  - beleidspagina krijgt een nieuwe "Laatst bijgewerkt"-datum
     *  - bij NIEUWE consent-plichtige diensten: consent-versie ophogen,
     *    zodat alle bezoekers opnieuw om toestemming gevraagd worden.
     */
    private function handle_changes( $old, $new ) {
        if ( empty( $old['time'] ) ) {
            return; // eerste scan = nulmeting, geen "wijziging"
        }

        $old_ids = isset( $old['services'] ) ? array_keys( (array) $old['services'] ) : [];
        $new_ids = isset( $new['services'] ) ? array_keys( (array) $new['services'] ) : [];

        $added   = array_values( array_diff( $new_ids, $old_ids ) );
        $removed = array_values( array_diff( $old_ids, $new_ids ) );

        if ( ! $added && ! $removed ) {
            return;
        }

        DPCC_Policy::instance()->touch_date();

        // Alleen opnieuw consent vragen bij nieuwe consent-plichtige diensten.
        $services      = DPCC_Services::all();
        $needs_consent = [];
        foreach ( $added as $id ) {
            if ( isset( $services[ $id ] ) && 'noodzakelijk' !== $services[ $id ]['category'] ) {
                $needs_consent[] = $id;
            }
        }

        $bumped = false;
        if ( $needs_consent ) {
            $settings                    = DPCC_Settings::get();
            $settings['consent_version'] = (int) $settings['consent_version'] + 1;
            update_option( 'dpcc_settings', $settings );
            $bumped = true;
        }

        update_option( 'dpcc_scan_changes', [
            'time'    => time(),
            'added'   => $added,
            'removed' => $removed,
            'bumped'  => $bumped,
        ], false );
    }

    /**
     * Post-types die per stuk gescand worden én meetellen voor de sidebar-badge.
     *
     * Bewust alleen pagina's en berichten: dat is de content die de gebruiker
     * zelf maakt en die een eigen layout met eigen embeds kan hebben. Custom
     * post types (FAQ-items, reviews, portfolio, enz.) delen hun template en
     * worden apart als één voorbeeld gescand (zie cpt_sample_urls) — die zetten
     * geen andere cookies per item, dus ze hoeven niet stuk voor stuk.
     */
    public static function scannable_post_types() {
        return apply_filters( 'dpcc_scannable_post_types', [ 'page', 'post' ] );
    }

    /**
     * Eén voorbeeld-URL per publiek custom post type, voor template-dekking.
     * Deze tellen NIET mee voor de badge en worden niet als "gescand"
     * gemarkeerd (post_id 0) — het gaat puur om het draaien van hun template.
     */
    private function cpt_sample_urls() {
        $urls  = [];
        $badge = self::scannable_post_types();
        $cpts  = get_post_types( [ 'public' => true, '_builtin' => false ], 'names' );
        unset( $cpts['bricks_template'] ); // bouwblokken, geen bezoekerspagina's

        foreach ( $cpts as $cpt ) {
            if ( in_array( $cpt, $badge, true ) ) {
                continue; // die scannen we al volledig
            }
            $sample = get_posts( [
                'post_type'      => $cpt,
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ] );
            foreach ( $sample as $id ) {
                $url = get_permalink( $id );
                if ( $url ) {
                    $urls[ $url ] = 0;
                }
            }
        }
        return apply_filters( 'dpcc_cpt_sample_urls', $urls );
    }

    /**
     * Scan-doelen als url => post_id (0 = geen post, zoals de homepage).
     *
     * Opbouw:
     *  1. Vaste kern: home + webshop-pagina's (daar leven sessie-cookies).
     *  2. Voorrang: content die nog nooit gescand is (geen _dpcc_scanned meta)
     *     — dit voedt ook de sidebar-badge.
     *  3. Rouleren: de oudst-gescande pagina's opnieuw, zodat later
     *     toegevoegde trackers op bestaande pagina's ook boven water komen.
     */
    private function scan_targets() {
        $targets = [ home_url( '/' ) => 0 ];

        if ( class_exists( 'WooCommerce' ) ) {
            foreach ( [ 'woocommerce_shop_page_id', 'woocommerce_cart_page_id', 'woocommerce_checkout_page_id', 'woocommerce_myaccount_page_id' ] as $opt ) {
                $id = (int) get_option( $opt );
                if ( $id && 'publish' === get_post_status( $id ) ) {
                    $targets[ get_permalink( $id ) ] = $id;
                }
            }
        }

        $pending = get_posts( [
            'post_type'      => self::scannable_post_types(),
            'post_status'    => 'publish',
            'posts_per_page' => 40,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ [ 'key' => '_dpcc_scanned', 'compare' => 'NOT EXISTS' ] ],
        ] );
        foreach ( $pending as $id ) {
            $targets[ get_permalink( $id ) ] = $id;
        }

        $stale = get_posts( [
            'post_type'      => self::scannable_post_types(),
            'post_status'    => 'publish',
            'posts_per_page' => 5,
            'meta_key'       => '_dpcc_scanned',
            'orderby'        => 'meta_value_num',
            'order'          => 'ASC',
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ] );
        foreach ( $stale as $id ) {
            $targets[ get_permalink( $id ) ] = $id;
        }

        // Eén voorbeeld per custom post type (template-dekking, badge-irrelevant).
        foreach ( $this->cpt_sample_urls() as $url => $pid ) {
            if ( ! isset( $targets[ $url ] ) ) {
                $targets[ $url ] = $pid;
            }
        }

        return array_slice( array_filter( $targets, 'strlen', ARRAY_FILTER_USE_KEY ), 0, 50, true );
    }

    private function urls_to_scan() {
        return apply_filters( 'dpcc_scan_urls', array_keys( $this->scan_targets() ) );
    }

    /**
     * Aantal gepubliceerde pagina's/berichten dat nog nooit gescand is.
     * Gecachet in een transient; voedt de badge in de admin-sidebar.
     */
    public function pending_count() {
        $count = get_transient( 'dpcc_pending_scan_count' );
        if ( false !== $count ) {
            return (int) $count;
        }
        $ids = get_posts( [
            'post_type'      => self::scannable_post_types(),
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ [ 'key' => '_dpcc_scanned', 'compare' => 'NOT EXISTS' ] ],
        ] );
        $count = count( $ids );
        set_transient( 'dpcc_pending_scan_count', $count, 10 * MINUTE_IN_SECONDS );
        return $count;
    }

    /**
     * Nieuwe publicatie van scanbaar content-type: badge-teller verversen.
     */
    public function maybe_flush_pending_count( $new_status, $old_status, $post ) {
        if ( 'publish' === $new_status && $new_status !== $old_status
            && in_array( $post->post_type, self::scannable_post_types(), true ) ) {
            delete_transient( 'dpcc_pending_scan_count' );
        }
    }

    /**
     * Voer de scan uit.
     *
     * @return array resultaten voor optie dpcc_scan_results
     */
    public function scan() {
        $scan_key  = (string) get_option( 'dpcc_scan_key' );
        $services  = DPCC_Services::all();
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );

        $found_services = [];
        $unknown_hosts  = [];
        $http_cookies   = [];
        $scanned        = [];
        $errors         = [];

        $targets = $this->scan_targets();

        foreach ( apply_filters( 'dpcc_scan_urls', array_keys( $targets ) ) as $url ) {
            $scan_url = add_query_arg( 'dpcc_scan', rawurlencode( $scan_key ), $url );
            $response = wp_remote_get( $scan_url, [
                'timeout'     => 15,
                'redirection' => 3,
                'user-agent'  => 'DP-Cookie-Consent-Scanner/' . DPCC_VERSION,
            ] );

            if ( is_wp_error( $response ) ) {
                $errors[] = $url . ' — ' . $response->get_error_message();
                continue;
            }

            $body = wp_remote_retrieve_body( $response );
            if ( '' === $body ) {
                $errors[] = $url . ' — lege response';
                continue;
            }
            $scanned[] = $url;

            // Scan-geheugen: onthoud per pagina wanneer die gescand is.
            if ( ! empty( $targets[ $url ] ) ) {
                update_post_meta( $targets[ $url ], '_dpcc_scanned', time() );
            }

            // --- Bekende diensten detecteren -----------------------------
            foreach ( $services as $id => $service ) {
                if ( isset( $found_services[ $id ] ) && in_array( $url, $found_services[ $id ]['pages'], true ) ) {
                    continue;
                }
                $patterns = array_merge( $service['src'], $service['inline'], $service['iframe'] );
                foreach ( $patterns as $pattern ) {
                    if ( @preg_match( '#' . $pattern . '#i', $body ) ) {
                        if ( ! isset( $found_services[ $id ] ) ) {
                            $found_services[ $id ] = [ 'pages' => [] ];
                        }
                        $found_services[ $id ]['pages'][] = $url;
                        break;
                    }
                }
            }

            // --- Onbekende externe script-hosts --------------------------
            if ( preg_match_all( '#<script\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']#i', $body, $matches ) ) {
                foreach ( $matches[1] as $src ) {
                    $host = wp_parse_url( html_entity_decode( $src ), PHP_URL_HOST );
                    if ( ! $host || $host === $site_host ) {
                        continue;
                    }
                    $known = false;
                    foreach ( $services as $service ) {
                        foreach ( array_merge( $service['src'], $service['iframe'] ) as $pattern ) {
                            if ( @preg_match( '#' . $pattern . '#i', $src ) ) {
                                $known = true;
                                break 2;
                            }
                        }
                    }
                    if ( ! $known && ! isset( $unknown_hosts[ $host ] ) ) {
                        $unknown_hosts[ $host ] = $url;
                    }
                }
            }

            // --- First-party cookies uit de Set-Cookie headers ------------
            $cookies = wp_remote_retrieve_cookies( $response );
            foreach ( $cookies as $cookie ) {
                $name = is_object( $cookie ) ? $cookie->name : '';
                if ( $name && ! isset( $http_cookies[ $name ] ) ) {
                    $http_cookies[ $name ] = $url;
                }
            }
        }

        delete_transient( 'dpcc_pending_scan_count' );

        return [
            'time'     => time(),
            'scanned'  => $scanned,
            'services' => $found_services,
            'unknown'  => $unknown_hosts,
            'cookies'  => $http_cookies,
            'errors'   => $errors,
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Browser-scan                                                       */
    /*                                                                     */
    /*  De server-side scan hierboven ziet alleen de HTML en de Set-Cookie */
    /*  headers — cookies die puur via JavaScript gezet worden (zoals _ga, */
    /*  _fbp, _hj*) zijn daarmee onzichtbaar. De browser-scan laadt de     */
    /*  pagina's daarom in een verborgen iframe in de browser van de       */
    /*  beheerder (met scan-bypass zodat alle scripts écht draaien), en    */
    /*  leest na het laden document.cookie + local/sessionStorage uit.     */
    /* ------------------------------------------------------------------ */

    /**
     * De frontend-URLs voor de browser-scan, voorzien van scan-bypass en
     * collector-trigger. De eerste URL krijgt een reset-vlag mee zodat een
     * nieuwe scan met een schone lei begint.
     */
    public function browser_scan_urls() {
        $key  = rawurlencode( (string) get_option( 'dpcc_scan_key' ) );
        $urls = [];
        foreach ( $this->urls_to_scan() as $url ) {
            $urls[] = add_query_arg( [ 'dpcc_scan' => $key, 'dpcc_browser_scan' => 1 ], $url );
        }
        return $urls;
    }

    /**
     * Collector-script op de frontend. Alleen actief wanneer:
     *  - de scan-bypass key klopt (zelfde check als de blocker), én
     *  - er om een browser-scan gevraagd wordt, én
     *  - de bezoeker een ingelogde beheerder is (het iframe deelt de sessie).
     */
    public function inject_collector() {
        if ( ! isset( $_GET['dpcc_browser_scan'], $_GET['dpcc_scan'] ) ) {
            return;
        }
        if ( ! hash_equals( (string) get_option( 'dpcc_scan_key' ), (string) wp_unslash( $_GET['dpcc_scan'] ) ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $rest  = esc_url_raw( rest_url( 'dpcc/v1/browser-scan' ) );
        $nonce = wp_create_nonce( 'wp_rest' );
        ?>
        <script>
        (function () {
            'use strict';
            function collect() {
                var cookies = [];
                if (document.cookie) {
                    document.cookie.split(';').forEach(function (c) {
                        var name = c.split('=')[0].trim();
                        if (name && cookies.indexOf(name) === -1) { cookies.push(name); }
                    });
                }
                var storage = [];
                try { for (var i = 0; i < localStorage.length; i++) { storage.push(localStorage.key(i)); } } catch (e) {}
                try { for (var j = 0; j < sessionStorage.length; j++) { storage.push(sessionStorage.key(j)); } } catch (e) {}

                var done = function () {
                    try { parent.postMessage('dpcc:page-done', '*'); } catch (e) {}
                };
                try {
                    fetch(<?php echo wp_json_encode( $rest ); ?>, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': <?php echo wp_json_encode( $nonce ); ?> },
                        credentials: 'same-origin',
                        body: JSON.stringify({
                            cookies: cookies,
                            storage: storage,
                            url: location.href.split('?')[0]
                        })
                    }).then(done, done);
                } catch (e) { done(); }
            }
            // Even wachten na load: async trackers (GA, pixels) zetten hun
            // cookies pas nadat hun script volledig geladen en gedraaid is.
            if (document.readyState === 'complete') {
                setTimeout(collect, 3500);
            } else {
                window.addEventListener('load', function () { setTimeout(collect, 3500); });
            }
        })();
        </script>
        <?php
    }

    /**
     * REST-endpoint waar de collector zijn bevindingen naartoe stuurt.
     * Permission: alleen beheerders (het iframe draait in hun sessie).
     */
    public function register_browser_scan_rest() {
        register_rest_route( 'dpcc/v1', '/browser-scan', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rest_store_browser_results' ],
            'permission_callback' => function () {
                return current_user_can( 'manage_options' );
            },
        ] );
    }

    public function rest_store_browser_results( WP_REST_Request $request ) {
        $p = $request->get_json_params();

        // Reset + baseline: aan het begin van een scan-run legt de beheerder-
        // pagina vast welke cookies/storage er al in de browser stonden. Die
        // "voorraad" filteren we vervolgens per pagina weg (behalve echte
        // trackers), zodat oude restanten en builder-/admin-sleutels niet als
        // vondst gerapporteerd worden.
        if ( ! empty( $p['reset'] ) ) {
            $baseline = [
                'cookies' => $this->sanitize_key_list( $p['baseline']['cookies'] ?? [], 500 ),
                'storage' => $this->sanitize_key_list( $p['baseline']['storage'] ?? [], 500 ),
            ];
            update_option( 'dpcc_browser_results', [
                'time'      => time(),
                'cookies'   => [],
                'storage'   => [],
                'pages'     => [],
                '_baseline' => $baseline,
            ], false );
            return [ 'ok' => true, 'reset' => true ];
        }

        $cookies = $this->sanitize_key_list( $p['cookies'] ?? [], 200 );
        $storage = $this->sanitize_key_list( $p['storage'] ?? [], 200 );
        $url     = isset( $p['url'] ) ? esc_url_raw( $p['url'] ) : '';

        $results = get_option( 'dpcc_browser_results', null );
        if ( ! is_array( $results ) || ! isset( $results['cookies'], $results['storage'], $results['pages'] ) ) {
            $results = [ 'time' => time(), 'cookies' => [], 'storage' => [], 'pages' => [], '_baseline' => [ 'cookies' => [], 'storage' => [] ] ];
        }
        $base_cookies = $results['_baseline']['cookies'] ?? [];
        $base_storage = $results['_baseline']['storage'] ?? [];

        foreach ( $cookies as $name ) {
            if ( '' === $name || isset( $results['cookies'][ $name ] ) ) {
                continue;
            }
            // Stond al in de browser vóór de scan én is geen bekende tracker?
            // Dan is het voorraad (admin/builder/oud restant), niet iets wat
            // deze pagina zet — overslaan.
            if ( in_array( $name, $base_cookies, true ) && ! self::is_known_tracker( $name ) ) {
                continue;
            }
            $results['cookies'][ $name ] = $url;
        }
        foreach ( $storage as $key ) {
            if ( '' === $key || isset( $results['storage'][ $key ] ) ) {
                continue;
            }
            if ( in_array( $key, $base_storage, true ) && ! self::is_known_tracker( $key ) ) {
                continue;
            }
            $results['storage'][ $key ] = $url;
        }
        if ( $url && ! in_array( $url, $results['pages'], true ) ) {
            $results['pages'][] = $url;
        }
        $results['time'] = time();

        update_option( 'dpcc_browser_results', $results, false );

        return [ 'ok' => true ];
    }

    /** Maak een lijst cookie-/storage-namen schoon en begrens de lengte. */
    private function sanitize_key_list( $list, $max ) {
        if ( ! is_array( $list ) ) {
            return [];
        }
        return array_slice( array_values( array_filter( array_map( 'sanitize_text_field', $list ) ) ), 0, $max );
    }

    /**
     * Matcht een cookie-/storage-naam tegen de cookies van een bekende
     * tracking-dienst (met *-wildcards). True = het is een echte tracker en
     * moet altijd getoond worden, ook als hij al in de browser stond.
     */
    public static function is_known_tracker( $name ) {
        // Handmatige register-keuzes tellen mee: heeft de beheerder een cookie
        // ooit als statistiek/marketing geclassificeerd, dan is het een tracker
        // en moet hij altijd getoond worden (ook als hij al in de browser stond).
        $register = get_option( 'dpcc_cookie_register', [] );
        if ( is_array( $register ) && isset( $register[ $name ]['category'] )
            && ! in_array( $register[ $name ]['category'], [ 'negeren', 'noodzakelijk' ], true ) ) {
            return true;
        }

        foreach ( DPCC_Services::all() as $service ) {
            if ( 'noodzakelijk' === $service['category'] ) {
                continue;
            }
            foreach ( $service['cookies'] as $cookie ) {
                $pattern = $cookie[0];
                if ( false !== strpos( $pattern, '(' ) ) {
                    continue;
                }
                foreach ( explode( ',', $pattern ) as $single ) {
                    $single = trim( $single );
                    if ( '' === $single ) {
                        continue;
                    }
                    $rx = '#^' . str_replace( '\*', '.*', preg_quote( $single, '#' ) ) . '$#i';
                    if ( preg_match( $rx, $name ) ) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Herken een in de browser gevonden cookie: eerst tegen de cookies van
     * de bekende diensten (met *-wildcards), dan tegen een basislijst van
     * WordPress-/webshop-cookies. Null = onbekend.
     *
     * @return array{service:string,category:string}|null
     */
    public static function classify_client_cookie( $name ) {
        // Eigen cookie-register eerst: een handmatige keuze van de beheerder
        // wint van alles.
        $register = get_option( 'dpcc_cookie_register', [] );
        if ( is_array( $register ) && isset( $register[ $name ]['category'] ) ) {
            return [
                'service'  => '' !== (string) $register[ $name ]['label'] ? $register[ $name ]['label'] : 'Handmatig geclassificeerd',
                'category' => $register[ $name ]['category'],
            ];
        }

        foreach ( DPCC_Services::all() as $service ) {
            foreach ( $service['cookies'] as $cookie ) {
                $pattern = $cookie[0];
                // Beschrijvende regels ("(afhankelijk van...)") overslaan.
                if ( false !== strpos( $pattern, '(' ) ) {
                    continue;
                }
                foreach ( explode( ',', $pattern ) as $single ) {
                    $single = trim( $single );
                    if ( '' === $single ) {
                        continue;
                    }
                    $rx = '#^' . str_replace( '\*', '.*', preg_quote( $single, '#' ) ) . '$#i';
                    if ( preg_match( $rx, $name ) ) {
                        return [ 'service' => $service['label'], 'category' => $service['category'] ];
                    }
                }
            }
        }

        foreach ( self::base_cookies() as $pattern => $info ) {
            $rx = '#^' . str_replace( '\*', '.*', preg_quote( $pattern, '#' ) ) . '$#i';
            if ( preg_match( $rx, $name ) ) {
                return [ 'service' => $info[0], 'category' => $info[1] ];
            }
        }

        return null;
    }

    /**
     * Basislijst van bekende first-party cookies die niet aan een externe
     * dienst hangen (WordPress zelf, webshop, deze plugin).
     */
    private static function base_cookies() {
        return apply_filters( 'dpcc_base_cookies', [
            'dpcc_consent'              => [ 'DP Cookie Consent', 'noodzakelijk' ],
            'wordpress_test_cookie'     => [ 'WordPress', 'noodzakelijk' ],
            'wordpress_*'               => [ 'WordPress (ingelogd)', 'noodzakelijk' ],
            'wp-settings-*'             => [ 'WordPress (ingelogd)', 'noodzakelijk' ],
            'wp_lang'                   => [ 'WordPress', 'noodzakelijk' ],
            'wp-postpass_*'             => [ 'WordPress (beveiligde pagina)', 'noodzakelijk' ],
            'comment_author_*'          => [ 'WordPress (reacties)', 'noodzakelijk' ],
            'PHPSESSID'                 => [ 'PHP-sessie', 'noodzakelijk' ],
            'woocommerce_cart_hash'     => [ 'WooCommerce', 'noodzakelijk' ],
            'woocommerce_items_in_cart' => [ 'WooCommerce', 'noodzakelijk' ],
            'wp_woocommerce_session_*'  => [ 'WooCommerce', 'noodzakelijk' ],
            'woocommerce_recently_viewed' => [ 'WooCommerce', 'noodzakelijk' ],
            'sbjs_*'                    => [ 'WooCommerce (herkomst-tracking)', 'statistieken' ],
            'tk_ai'                     => [ 'Jetpack-statistieken', 'statistieken' ],
            'tk_qs'                     => [ 'Jetpack-statistieken', 'statistieken' ],
            'pll_language'              => [ 'Polylang (taalkeuze)', 'noodzakelijk' ],
            'wp-wpml_current_language'  => [ 'WPML (taalkeuze)', 'noodzakelijk' ],
            '_lscache_vary'             => [ 'LiteSpeed Cache', 'noodzakelijk' ],
            '__cf_bm'                   => [ 'Cloudflare (bot-beveiliging)', 'noodzakelijk' ],
            'cf_clearance'              => [ 'Cloudflare (beveiliging)', 'noodzakelijk' ],
            '__stripe_mid'              => [ 'Stripe (fraudepreventie betalingen)', 'noodzakelijk' ],
            '__stripe_sid'              => [ 'Stripe (fraudepreventie betalingen)', 'noodzakelijk' ],
            '_wpfuuid'                  => [ 'WPForms', 'noodzakelijk' ],
            'mailchimp_landing_site'    => [ 'Mailchimp (herkomst)', 'statistieken' ],
            'mailpoet_*'                => [ 'MailPoet', 'noodzakelijk' ],
            'cmplz_*'                   => [ 'Complianz (andere cookiebanner)', 'noodzakelijk' ],
            'moove_gdpr_popup'          => [ 'GDPR Cookie Compliance (andere cookiebanner)', 'noodzakelijk' ],
            'cookieyes-consent'         => [ 'CookieYes (andere cookiebanner)', 'noodzakelijk' ],
            'borlabs-cookie'            => [ 'Borlabs (andere cookiebanner)', 'noodzakelijk' ],
        ] );
    }
}
