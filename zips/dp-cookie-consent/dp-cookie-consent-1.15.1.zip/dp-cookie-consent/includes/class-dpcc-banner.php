<?php
/**
 * Front-end: banner-markup, assets en de shortcode [dpcc_cookies]
 * voor het cookie-overzicht op de cookieverklaring-pagina.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Banner {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );
        add_action( 'wp_footer', [ $this, 'render' ], 5 );
        add_shortcode( 'dpcc_cookies', [ $this, 'shortcode_overview' ] );
    }

    private function active() {
        return DPCC_Blocker::instance()->should_block();
    }

    /**
     * Accent-kleur voor de banner. Standaard volgt hij de ACSS-variabele
     * --primary van de site, met de ingestelde hex als fallback voor sites
     * zonder ACSS. Op 'custom' wordt de hex direct gebruikt.
     */
    public static function accent_css( $settings ) {
        $hex = isset( $settings['color_primary'] ) ? $settings['color_primary'] : '#9e86ff';
        if ( isset( $settings['accent_source'] ) && 'custom' === $settings['accent_source'] ) {
            return $hex;
        }
        return 'var(--primary, ' . $hex . ')';
    }

    public function enqueue() {
        if ( ! $this->active() ) {
            return;
        }

        wp_enqueue_style( 'dpcc', DPCC_URL . 'assets/css/dpcc.css', [], DPCC_VERSION );
        wp_enqueue_script( 'dpcc', DPCC_URL . 'assets/js/dpcc.js', [], DPCC_VERSION, true );

        $settings = DPCC_Settings::get();
        wp_localize_script( 'dpcc', 'dpccConfig', [
            'cookieName'     => DPCC_COOKIE,
            'expiryDays'     => (int) $settings['expiry_days'],
            'consentVersion' => (int) $settings['consent_version'],
            'categories'     => DPCC_Services::consent_categories(),
            'logConsent'     => (bool) $settings['log_consent'],
            'consentMode'    => (bool) $settings['consent_mode'],
            'honorGpc'       => (bool) $settings['honor_gpc'],
            'restUrl'        => rest_url( 'dpcc/v1/consent' ),
            'restNonce'      => wp_create_nonce( 'wp_rest' ),
            'labels'         => [
                'statistieken' => 'statistiek-cookies',
                'marketing'    => 'marketing-cookies',
                'placeholder'  => 'Deze ingesloten content van %s is geblokkeerd totdat je toestemming geeft.',
                'placeholderBtn' => 'Content laden en cookies accepteren',
            ],
        ] );
    }

    /**
     * Banner + voorkeuren-paneel + heropen-badge.
     */
    public function render() {
        if ( ! $this->active() ) {
            return;
        }

        $settings = DPCC_Settings::get();

        // Cookie-icoon: eigen kleuren als 'apart stylen' aan staat, anders
        // volgt het icoon de banner (cirkel = achtergrond, pictogram = accent).
        if ( ! empty( $settings['badge_custom'] ) ) {
            $badge_bg   = $settings['badge_bg'];
            $badge_icon = $settings['badge_icon'];
        } else {
            $badge_bg   = $settings['color_bg'];
            $badge_icon = self::accent_css( $settings );
        }

        $style = sprintf(
            '--dpcc-primary:%s;--dpcc-bg:%s;--dpcc-text:%s;--dpcc-badge-bg:%s;--dpcc-badge-icon:%s;',
            esc_attr( self::accent_css( $settings ) ),
            esc_attr( $settings['color_bg'] ),
            esc_attr( $settings['color_text'] ),
            esc_attr( $badge_bg ),
            esc_attr( $badge_icon )
        );
        $position = in_array( $settings['position'], [ 'left', 'right', 'center' ], true ) ? $settings['position'] : 'left';
        $reopen   = ( isset( $settings['reopen_style'] ) && 'bar' === $settings['reopen_style'] ) ? 'bar' : 'badge';
        // De strook kent geen midden-variant; de CSS laat 'm bij "midden" links plakken.

        // Strook-styling: instelbare rand en schaduw (CSS-vars met defaults in dpcc.css).
        if ( 'bar' === $reopen ) {
            if ( ! empty( $settings['reopen_border'] ) ) {
                $style .= '--dpcc-tab-border:' . esc_attr( $settings['reopen_border'] ) . ';';
            }
            if ( empty( $settings['reopen_shadow'] ) ) {
                $style .= '--dpcc-tab-shadow:none;';
            }
        }
        ?>
        <div id="dpcc-root" class="dpcc-pos-<?php echo esc_attr( $position ); ?> dpcc-reopen-<?php echo esc_attr( $reopen ); ?>" style="<?php echo $style; // phpcs:ignore ?>">

            <div id="dpcc-banner" role="dialog" aria-modal="true" aria-labelledby="dpcc-title" aria-describedby="dpcc-desc" tabindex="-1" hidden>
                <h2 id="dpcc-title"><?php echo esc_html( $settings['title'] ); ?></h2>
                <div class="dpcc-text" id="dpcc-desc">
                    <?php echo wp_kses_post( wpautop( $settings['text'] ) ); ?>
                    <?php if ( ! empty( $settings['policy_url'] ) ) : ?>
                        <p><a href="<?php echo esc_url( $settings['policy_url'] ); ?>">Lees meer in onze cookieverklaring</a></p>
                    <?php endif; ?>
                </div>

                <div id="dpcc-prefs" hidden>
                    <label class="dpcc-cat">
                        <input type="checkbox" checked disabled>
                        <span><strong>Noodzakelijk</strong> — vereist voor de basisfunctionaliteit van de site. Altijd actief.</span>
                    </label>
                    <label class="dpcc-cat">
                        <input type="checkbox" id="dpcc-cat-statistieken" value="statistieken">
                        <span><strong>Statistieken</strong> — anonieme statistieken over sitegebruik (bijv. Google Analytics).</span>
                    </label>
                    <label class="dpcc-cat">
                        <input type="checkbox" id="dpcc-cat-marketing" value="marketing">
                        <span><strong>Marketing &amp; embeds</strong> — advertentie-cookies en ingesloten content zoals YouTube-video's en Google Maps.</span>
                    </label>
                    <button type="button" id="dpcc-save" class="dpcc-btn dpcc-btn-primary" hidden><?php echo esc_html( $settings['save_label'] ); ?></button>
                </div>

                <div class="dpcc-buttons">
                    <button type="button" id="dpcc-accept" class="dpcc-btn dpcc-btn-primary"><?php echo esc_html( $settings['accept_label'] ); ?></button>
                    <button type="button" id="dpcc-reject" class="dpcc-btn"><?php echo esc_html( $settings['reject_label'] ); ?></button>
                    <button type="button" id="dpcc-open-prefs" class="dpcc-btn dpcc-btn-link" aria-expanded="false" aria-controls="dpcc-prefs"><?php echo esc_html( $settings['prefs_label'] ); ?></button>
                </div>
            </div>

            <?php if ( 'bar' === $reopen ) : ?>
                <button type="button" id="dpcc-tab" aria-label="Cookie-instellingen beheren" aria-haspopup="dialog" hidden>
                    <svg class="dpcc-tab__chevron" viewBox="0 0 12 12" width="10" height="10" aria-hidden="true" focusable="false"><path d="M2.2 7.6 6 3.8l3.8 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <span class="dpcc-tab__label"><?php echo esc_html( $settings['reopen_label'] ); ?></span>
                </button>
            <?php else : ?>
                <button type="button" id="dpcc-badge" aria-label="Cookie-instellingen aanpassen" aria-haspopup="dialog" hidden>
                    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a10 10 0 1 0 10 10c0-.5-.04-1-.11-1.47a3.5 3.5 0 0 1-4.54-3.24 3.5 3.5 0 0 1-3.72-4.9A10 10 0 0 0 12 2Zm-3.5 7a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm7 5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm-5.5 2a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"/></svg>
                </button>
            <?php endif; ?>

        </div>
        <?php
    }

    /**
     * [dpcc_cookies] — cookie-overzichtstabel op basis van de laatste scan.
     */
    public function shortcode_overview() {
        $results  = get_option( 'dpcc_scan_results', [] );
        $services = DPCC_Services::all();
        $labels   = DPCC_Services::categories();

        $detected = isset( $results['services'] ) && is_array( $results['services'] ) ? array_keys( $results['services'] ) : [];

        // Eigen consent-cookie + WP-basics horen altijd in het overzicht.
        $rows = [
            [ DPCC_COOKIE, (int) DPCC_Settings::val( 'expiry_days' ) . ' dagen', 'Onthoudt jouw cookie-voorkeuren.', $labels['noodzakelijk'], get_bloginfo( 'name' ) ],
            [ 'wordpress_*, wp-settings-*', 'Sessie / 1 jaar', 'Technische cookies voor ingelogde gebruikers.', $labels['noodzakelijk'], 'WordPress' ],
        ];

        foreach ( $detected as $id ) {
            if ( ! isset( $services[ $id ] ) ) {
                continue;
            }
            $service = $services[ $id ];
            foreach ( $service['cookies'] as $cookie ) {
                $rows[] = [ $cookie[0], $cookie[1], $cookie[2], $labels[ $service['category'] ], $service['label'] ];
            }
        }

        // Handmatig geclassificeerde cookies uit het cookie-register (browser-
        // scan). "Negeren" blijft buiten het overzicht.
        $register = get_option( 'dpcc_cookie_register', [] );
        if ( is_array( $register ) ) {
            foreach ( $register as $name => $info ) {
                if ( ! isset( $info['category'], $labels[ $info['category'] ] ) ) {
                    continue;
                }
                $rows[] = [
                    $name,
                    '-',
                    'Aangetroffen bij de cookie-scan en handmatig geclassificeerd.',
                    $labels[ $info['category'] ],
                    '' !== (string) ( $info['label'] ?? '' ) ? $info['label'] : get_bloginfo( 'name' ),
                ];
            }
        }

        ob_start();
        ?>
        <table class="dpcc-overview">
            <thead>
                <tr><th>Cookie</th><th>Bewaartermijn</th><th>Doel</th><th>Categorie</th><th>Dienst</th></tr>
            </thead>
            <tbody>
            <?php foreach ( $rows as $row ) : ?>
                <tr>
                    <td><code><?php echo esc_html( $row[0] ); ?></code></td>
                    <td><?php echo esc_html( $row[1] ); ?></td>
                    <td><?php echo esc_html( $row[2] ); ?></td>
                    <td><?php echo esc_html( $row[3] ); ?></td>
                    <td><?php echo esc_html( $row[4] ); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ( empty( $detected ) ) : ?>
            <p><em>Er is nog geen cookie-scan uitgevoerd. Voer eerst een scan uit via WP-Admin &rarr; Cookiebanner.</em></p>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }
}
