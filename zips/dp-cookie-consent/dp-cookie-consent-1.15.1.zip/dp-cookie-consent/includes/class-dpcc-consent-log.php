<?php
/**
 * Consent-logboek: bewijs van toestemming (AVG art. 7).
 *
 * Elke keuze van een bezoeker wordt server-side vastgelegd in een eigen tabel,
 * met een consent-ID dat ook in de consent-cookie zit (zodat record en bezoeker
 * te correleren zijn), tijdstip, de gemaakte keuzes, de consent-versie, de URL,
 * een gepseudonimiseerd IP (HMAC-hash, niet het IP zelf) en de user-agent.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Consent_Log {

    const DB_VERSION = 1;

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'rest_api_init', [ $this, 'register_route' ] );
        add_action( 'dpcc_prune_consent_log', [ $this, 'prune' ] );
        add_action( 'admin_post_dpcc_export_log', [ $this, 'export_csv' ] );

        if ( is_admin() ) {
            add_action( 'admin_init', [ $this, 'self_heal' ] );
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Tabel                                                              */
    /* ------------------------------------------------------------------ */

    public function table() {
        global $wpdb;
        return $wpdb->prefix . 'dpcc_consent_log';
    }

    /**
     * Maak/na-migreer de tabel via dbDelta.
     */
    public function create_table() {
        global $wpdb;
        $table           = $this->table();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  consent_id varchar(40) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  action varchar(20) NOT NULL DEFAULT '',
  categories text NOT NULL,
  consent_version int(11) NOT NULL DEFAULT 1,
  url varchar(255) NOT NULL DEFAULT '',
  ip_hash varchar(64) NOT NULL DEFAULT '',
  user_agent varchar(255) NOT NULL DEFAULT '',
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY consent_id (consent_id),
  KEY created_at (created_at)
) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'dpcc_log_db_version', self::DB_VERSION );
    }

    /**
     * Zorg dat de tabel bestaat en de prune-cron gepland staat (self-heal na
     * updates waarbij de activatie-hook niet fired).
     */
    public function self_heal() {
        if ( (int) get_option( 'dpcc_log_db_version' ) !== self::DB_VERSION ) {
            $this->create_table();
        }
        if ( ! wp_next_scheduled( 'dpcc_prune_consent_log' ) ) {
            wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'dpcc_prune_consent_log' );
        }
    }

    /* ------------------------------------------------------------------ */
    /*  REST-endpoint                                                      */
    /* ------------------------------------------------------------------ */

    public function register_route() {
        register_rest_route( 'dpcc/v1', '/consent', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rest_record' ],
            'permission_callback' => '__return_true', // publiek: ook anonieme bezoekers loggen
        ] );
    }

    public function rest_record( $request ) {
        if ( ! DPCC_Settings::val( 'log_consent' ) ) {
            return new WP_REST_Response( [ 'ok' => false, 'reason' => 'disabled' ], 200 );
        }

        $params = $request->get_json_params();
        if ( ! is_array( $params ) ) {
            $params = $request->get_params();
        }

        $incoming = isset( $params['categories'] ) && is_array( $params['categories'] ) ? $params['categories'] : [];
        $cats     = [];
        foreach ( DPCC_Services::consent_categories() as $c ) {
            $cats[ $c ] = ! empty( $incoming[ $c ] );
        }

        $this->insert( [
            'consent_id'      => isset( $params['cid'] ) ? sanitize_text_field( $params['cid'] ) : '',
            'categories'      => $cats,
            'consent_version' => isset( $params['sv'] ) ? (int) $params['sv'] : (int) DPCC_Settings::val( 'consent_version' ),
            'url'             => isset( $params['url'] ) ? esc_url_raw( $params['url'] ) : '',
        ] );

        return new WP_REST_Response( [ 'ok' => true ], 200 );
    }

    /* ------------------------------------------------------------------ */
    /*  Opslaan                                                            */
    /* ------------------------------------------------------------------ */

    public function insert( $data ) {
        global $wpdb;

        $cats = isset( $data['categories'] ) && is_array( $data['categories'] ) ? $data['categories'] : [];

        $wpdb->insert(
            $this->table(),
            [
                'consent_id'      => substr( (string) ( $data['consent_id'] ?? '' ), 0, 40 ),
                'created_at'      => current_time( 'mysql', true ), // GMT
                'action'          => self::action_for( $cats ),
                'categories'      => wp_json_encode( $cats ),
                'consent_version' => (int) ( $data['consent_version'] ?? 1 ),
                'url'             => substr( (string) ( $data['url'] ?? '' ), 0, 255 ),
                'ip_hash'         => self::hash_ip( self::parse_ip( $_SERVER ), (string) get_option( 'dpcc_scan_key' ) ),
                'user_agent'      => substr( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '', 0, 255 ),
                'user_id'         => get_current_user_id(),
            ],
            [ '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d' ]
        );
    }

    /**
     * Leid het actie-label af uit de gekozen categorieën.
     */
    public static function action_for( $cats ) {
        $vals = array_values( (array) $cats );
        if ( ! $vals ) {
            return 'custom';
        }
        $true = count( array_filter( $vals ) );
        if ( $true === count( $vals ) ) {
            return 'accept_all';
        }
        if ( 0 === $true ) {
            return 'reject_all';
        }
        return 'custom';
    }

    /**
     * Bepaal het client-IP (achter proxy's) uit de server-headers.
     */
    public static function parse_ip( $server ) {
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( empty( $server[ $key ] ) ) {
                continue;
            }
            $ip = trim( explode( ',', (string) $server[ $key ] )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return $ip;
            }
        }
        return '';
    }

    /**
     * Pseudonimiseer een IP: HMAC-SHA256 met site-specifieke sleutel, ingekort.
     * Het IP zelf wordt nooit opgeslagen; wel kun je later verifiëren of een
     * bekend IP overeenkomt (bewijskracht) zonder ruwe IP-opslag.
     */
    public static function hash_ip( $ip, $salt ) {
        if ( '' === $ip ) {
            return '';
        }
        return substr( hash_hmac( 'sha256', $ip, '' !== $salt ? $salt : 'dpcc' ), 0, 32 );
    }

    /* ------------------------------------------------------------------ */
    /*  Lezen / opruimen / export                                          */
    /* ------------------------------------------------------------------ */

    public function count() {
        global $wpdb;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table()}" ); // phpcs:ignore
    }

    public function get_recent( $limit = 50 ) {
        global $wpdb;
        $limit = max( 1, min( 500, (int) $limit ) );
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore
    }

    /**
     * Zoek records op (een deel van) het consent-ID. Prefix-match, zodat je
     * zowel de korte "Ref." (8 tekens) als het volledige ID kunt plakken.
     */
    public function find_by_consent_id( $cid ) {
        $cid = trim( (string) $cid );
        if ( '' === $cid ) {
            return [];
        }
        global $wpdb;
        $like = $wpdb->esc_like( $cid ) . '%';
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE consent_id LIKE %s ORDER BY id DESC LIMIT 100", $like ) ); // phpcs:ignore
    }

    /**
     * Verifieer een IP: hash het met de sitesleutel en zoek matchende records.
     * Retourneert null bij een ongeldig IP.
     */
    public function find_by_ip( $ip ) {
        $ip = trim( (string) $ip );
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            return null;
        }
        global $wpdb;
        $hash = self::hash_ip( $ip, (string) get_option( 'dpcc_scan_key' ) );
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE ip_hash = %s ORDER BY id DESC LIMIT 100", $hash ) ); // phpcs:ignore
    }

    /**
     * Verwijder records ouder dan de ingestelde bewaartermijn (0 = nooit).
     */
    public function prune() {
        $days = (int) DPCC_Settings::val( 'log_retention_days' );
        if ( $days <= 0 ) {
            return;
        }
        global $wpdb;
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$this->table()} WHERE created_at < %s", $cutoff ) ); // phpcs:ignore
    }

    public function export_csv() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_export_log' );

        global $wpdb;
        $rows = $wpdb->get_results( "SELECT * FROM {$this->table()} ORDER BY id DESC", ARRAY_A ); // phpcs:ignore

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=consent-log-' . gmdate( 'Y-m-d' ) . '.csv' );

        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, [ 'id', 'consent_id', 'created_at_gmt', 'action', 'categories', 'consent_version', 'url', 'ip_hash', 'user_agent', 'user_id' ] );
        foreach ( (array) $rows as $r ) {
            fputcsv( $out, [
                $r['id'], $r['consent_id'], $r['created_at'], $r['action'], $r['categories'],
                $r['consent_version'], $r['url'], $r['ip_hash'], $r['user_agent'], $r['user_id'],
            ] );
        }
        fclose( $out );
        exit;
    }
}
