<?php
/**
 * Databank van bekende diensten: detectie-patronen + bijbehorende cookies.
 *
 * Categorieën:
 *  - noodzakelijk : wordt nooit geblokkeerd, wel getoond in het cookie-overzicht
 *  - statistieken : geblokkeerd tot consent voor statistieken
 *  - marketing    : geblokkeerd tot consent voor marketing (incl. embeds)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Services {

    /**
     * Labels van de consent-categorieën.
     */
    public static function categories() {
        return [
            'noodzakelijk' => 'Noodzakelijk',
            'statistieken' => 'Statistieken',
            'marketing'    => 'Marketing & embeds',
        ];
    }

    /**
     * Categorieën waarvoor consent gevraagd wordt (alles behalve noodzakelijk).
     */
    public static function consent_categories() {
        return [ 'statistieken', 'marketing' ];
    }

    /**
     * Alle bekende diensten.
     *
     * Per dienst:
     *  - label    : leesbare naam
     *  - category : noodzakelijk | statistieken | marketing
     *  - src      : regex-patronen voor script-src URLs
     *  - inline   : regex-patronen voor inline script-inhoud
     *  - iframe   : regex-patronen voor iframe-src URLs
     *  - cookies  : [ [ naam, bewaartermijn, omschrijving ], ... ]
     */
    public static function all() {
        $services = [

            // Google Tag Manager kan élke soort tag laden — daarom standaard
            // in de zwaarste categorie. Override kan via de filter onderaan.
            'google-tag-manager' => [
                'label'    => 'Google Tag Manager',
                'category' => 'marketing',
                'src'      => [ 'googletagmanager\.com/gtm\.js' ],
                'inline'   => [ 'googletagmanager\.com/gtm\.js', 'GTM-[A-Z0-9]{4,}' ],
                'iframe'   => [ 'googletagmanager\.com/ns\.html' ],
                'cookies'  => [
                    [ '(afhankelijk van geladen tags)', '-', 'GTM plaatst zelf geen cookies, maar de tags die het laadt wel.' ],
                ],
            ],

            'google-analytics' => [
                'label'    => 'Google Analytics (GA4)',
                'category' => 'statistieken',
                'src'      => [ 'googletagmanager\.com/gtag/js', 'google-analytics\.com/(analytics|ga)\.js', 'google-analytics\.com/g/collect' ],
                'inline'   => [ 'gtag\s*\(', 'GoogleAnalyticsObject', "ga\s*\(\s*['\"]create" ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_ga', '2 jaar', 'Onderscheidt unieke bezoekers.' ],
                    [ '_ga_*', '2 jaar', 'Houdt de sessiestatus bij (GA4).' ],
                    [ '_gid', '24 uur', 'Onderscheidt bezoekers.' ],
                    [ '_gat', '1 minuut', 'Beperkt het aantal verzoeken.' ],
                ],
            ],

            'facebook-pixel' => [
                'label'    => 'Meta / Facebook Pixel',
                'category' => 'marketing',
                'src'      => [ 'connect\.facebook\.net' ],
                'inline'   => [ 'fbq\s*\(' ],
                'iframe'   => [ 'facebook\.com/plugins', 'facebook\.com/tr' ],
                'cookies'  => [
                    [ '_fbp', '3 maanden', 'Volgt bezoekers voor advertentiedoeleinden.' ],
                    [ 'fr', '3 maanden', 'Advertentie-targeting (derde partij, facebook.com).' ],
                ],
            ],

            'posthog' => [
                'label'    => 'PostHog',
                'category' => 'statistieken',
                'src'      => [ '[a-z0-9-]+\.posthog\.com', 'posthog\.com/static' ],
                'inline'   => [ 'posthog\.init', '\bposthog\b' ],
                'iframe'   => [],
                'cookies'  => [
                    [ 'ph_*_posthog', '1 jaar', 'Onderscheidt bezoekers en houdt sessie-/feature-flag-status bij (product-analytics).' ],
                ],
            ],

            'hotjar' => [
                'label'    => 'Hotjar',
                'category' => 'statistieken',
                'src'      => [ 'static\.hotjar\.com', 'script\.hotjar\.com' ],
                'inline'   => [ 'hjSettings', 'hotjar\.com' ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_hjSessionUser_*', '1 jaar', 'Onderscheidt unieke bezoekers.' ],
                    [ '_hjSession_*', '30 minuten', 'Houdt de huidige sessie bij.' ],
                ],
            ],

            'microsoft-clarity' => [
                'label'    => 'Microsoft Clarity',
                'category' => 'statistieken',
                'src'      => [ 'clarity\.ms' ],
                'inline'   => [ 'clarity\.ms', '["\']clarity["\']\s*,' ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_clck', '1 jaar', 'Onderscheidt unieke bezoekers.' ],
                    [ '_clsk', '1 dag', 'Koppelt paginaweergaven binnen een sessie.' ],
                ],
            ],

            'matomo' => [
                'label'    => 'Matomo',
                'category' => 'statistieken',
                'src'      => [ 'matomo\.js', 'piwik\.js' ],
                'inline'   => [ '_paq' ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_pk_id', '13 maanden', 'Onderscheidt unieke bezoekers.' ],
                    [ '_pk_ses', '30 minuten', 'Houdt de huidige sessie bij.' ],
                ],
            ],

            'linkedin-insight' => [
                'label'    => 'LinkedIn Insight Tag',
                'category' => 'marketing',
                'src'      => [ 'snap\.licdn\.com' ],
                'inline'   => [ '_linkedin_partner_id' ],
                'iframe'   => [],
                'cookies'  => [
                    [ 'li_sugr', '3 maanden', 'Browser-identificatie (derde partij).' ],
                    [ 'UserMatchHistory', '30 dagen', 'Advertentie-targeting (derde partij).' ],
                    [ 'bcookie', '1 jaar', 'Browser-identificatie (derde partij).' ],
                ],
            ],

            'tiktok-pixel' => [
                'label'    => 'TikTok Pixel',
                'category' => 'marketing',
                'src'      => [ 'analytics\.tiktok\.com' ],
                'inline'   => [ 'ttq\.load', 'analytics\.tiktok\.com' ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_ttp', '13 maanden', 'Volgt bezoekers voor advertentiedoeleinden.' ],
                ],
            ],

            'pinterest-tag' => [
                'label'    => 'Pinterest Tag',
                'category' => 'marketing',
                'src'      => [ 's\.pinimg\.com/ct' ],
                'inline'   => [ 'pintrk' ],
                'iframe'   => [],
                'cookies'  => [
                    [ '_pin_unauth', '1 jaar', 'Volgt bezoekers voor advertentiedoeleinden.' ],
                ],
            ],

            'google-ads' => [
                'label'    => 'Google Ads / DoubleClick',
                'category' => 'marketing',
                'src'      => [ 'googleadservices\.com', 'googlesyndication\.com', 'doubleclick\.net' ],
                'inline'   => [ 'googleadservices' ],
                'iframe'   => [ 'doubleclick\.net' ],
                'cookies'  => [
                    [ '_gcl_au', '3 maanden', 'Meet advertentie-conversies.' ],
                    [ 'IDE', '13 maanden', 'Advertentie-targeting (derde partij, doubleclick.net).' ],
                ],
            ],

            'hubspot' => [
                'label'    => 'HubSpot',
                'category' => 'marketing',
                'src'      => [ 'js\.hs-scripts\.com', 'js\.hs-analytics\.net', 'js\.hsforms\.net', 'js\.usemessages\.com' ],
                'inline'   => [],
                'iframe'   => [],
                'cookies'  => [
                    [ '__hstc', '6 maanden', 'Volgt bezoekers over sessies heen.' ],
                    [ 'hubspotutk', '6 maanden', 'Identificeert de bezoeker bij formulierinzendingen.' ],
                    [ '__hssc', '30 minuten', 'Houdt de huidige sessie bij.' ],
                ],
            ],

            'youtube' => [
                'label'    => 'YouTube (video-embed)',
                'category' => 'marketing',
                'src'      => [ 'youtube\.com/iframe_api', 'youtube\.com/player_api' ],
                'inline'   => [],
                'iframe'   => [ 'youtube(-nocookie)?\.com/embed', 'youtube\.com/watch' ],
                'cookies'  => [
                    [ 'VISITOR_INFO1_LIVE', '6 maanden', 'Bandbreedte-meting en advertentie-targeting (derde partij, youtube.com).' ],
                    [ 'YSC', 'Sessie', 'Houdt bekeken video\'s bij (derde partij).' ],
                ],
            ],

            'vimeo' => [
                'label'    => 'Vimeo (video-embed)',
                'category' => 'marketing',
                'src'      => [ 'player\.vimeo\.com/api' ],
                'inline'   => [],
                'iframe'   => [ 'player\.vimeo\.com' ],
                'cookies'  => [
                    [ 'vuid', '2 jaar', 'Verzamelt gebruiksstatistieken (derde partij, vimeo.com).' ],
                ],
            ],

            'google-maps' => [
                'label'    => 'Google Maps (kaart-embed)',
                'category' => 'marketing',
                'src'      => [ 'maps\.googleapis\.com/maps/api' ],
                'inline'   => [],
                'iframe'   => [ 'google\.[a-z.]{2,6}/maps/embed', 'maps\.google\.[a-z.]{2,6}' ],
                'cookies'  => [
                    [ 'NID', '6 maanden', 'Voorkeuren en advertentie-targeting (derde partij, google.com).' ],
                ],
            ],

            'recaptcha' => [
                'label'    => 'Google reCAPTCHA',
                'category' => 'noodzakelijk',
                'src'      => [ 'google\.com/recaptcha', 'gstatic\.com/recaptcha', 'recaptcha\.net' ],
                'inline'   => [],
                'iframe'   => [],
                'cookies'  => [
                    [ '_GRECAPTCHA', '6 maanden', 'Spam-beveiliging van formulieren (derde partij, google.com).' ],
                ],
            ],
        ];

        /**
         * Filter om diensten toe te voegen of van categorie te wisselen, bijv.
         * GTM naar 'statistieken' als er alleen GA in de container zit.
         */
        return apply_filters( 'dpcc_services', $services );
    }

    /**
     * Google-diensten die door Google Consent Mode gestuurd worden. Wanneer
     * Consent Mode aan staat blokkeren we deze niet hard, maar laten we ze in
     * 'denied'-modus laden zodat Google cookieloze modellering kan doen.
     */
    public static function consent_mode_service_ids() {
        return [ 'google-tag-manager', 'google-analytics', 'google-ads' ];
    }

    /**
     * Diensten die geblokkeerd moeten worden (alles behalve noodzakelijk),
     * inclusief custom patronen uit de instellingen.
     */
    public static function blockable() {
        $skip = DPCC_Settings::val( 'consent_mode' ) ? self::consent_mode_service_ids() : [];

        $out = [];
        foreach ( self::all() as $id => $service ) {
            if ( 'noodzakelijk' === $service['category'] ) {
                continue;
            }
            if ( in_array( $id, $skip, true ) ) {
                continue;
            }
            $out[ $id ] = $service;
        }

        foreach ( DPCC_Settings::custom_patterns() as $i => $row ) {
            $out[ 'custom-' . $i ] = [
                'label'    => 'Eigen patroon: ' . $row['pattern'],
                'category' => $row['category'],
                'src'      => [ $row['pattern'] ],
                'inline'   => [ $row['pattern'] ],
                'iframe'   => [ $row['pattern'] ],
                'cookies'  => [],
            ];
        }

        return $out;
    }

    /**
     * Match een script (src + inline body) tegen de blokkeerlijst.
     *
     * @return string|null categorie, of null als geen match.
     */
    public static function match_script( $src, $body ) {
        foreach ( self::blockable() as $service ) {
            if ( $src ) {
                foreach ( $service['src'] as $pattern ) {
                    if ( @preg_match( '#' . $pattern . '#i', $src ) ) {
                        return $service['category'];
                    }
                }
            }
            if ( '' !== trim( (string) $body ) ) {
                foreach ( $service['inline'] as $pattern ) {
                    if ( @preg_match( '#' . $pattern . '#i', $body ) ) {
                        return $service['category'];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Match een iframe-src tegen de blokkeerlijst.
     *
     * @return string|null categorie, of null als geen match.
     */
    public static function match_iframe( $src ) {
        foreach ( self::blockable() as $service ) {
            foreach ( $service['iframe'] as $pattern ) {
                if ( @preg_match( '#' . $pattern . '#i', $src ) ) {
                    return $service['category'];
                }
            }
        }
        return null;
    }
}
