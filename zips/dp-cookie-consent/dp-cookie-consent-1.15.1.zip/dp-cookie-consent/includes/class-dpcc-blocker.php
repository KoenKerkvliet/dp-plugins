<?php
/**
 * De blocking-engine: herschrijft tracking-scripts en embeds in de HTML-output
 * naar inactieve varianten (type="text/plain" / src verwijderd) vóór ze de
 * browser bereiken.
 *
 * Bewust cache-safe ontworpen: er wordt ALTIJD geblokkeerd, ongeacht de
 * consent-cookie. De banner-JS activeert toegestane categorieën client-side
 * bij elke paginaweergave. Zo kan een page-cache (LiteSpeed e.d.) nooit een
 * "ontblokkeerde" pagina aan een bezoeker zonder consent serveren.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Blocker {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'template_redirect', [ $this, 'maybe_start_buffer' ], 2 );
    }

    /**
     * Bepaal of er op dit request geblokkeerd moet worden.
     */
    public function should_block() {
        if ( ! DPCC_Settings::val( 'enabled' ) ) {
            return false;
        }
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return false;
        }
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return false;
        }
        if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
            return false;
        }
        if ( is_feed() || is_robots() ) {
            return false;
        }
        if ( is_customize_preview() ) {
            return false;
        }
        // Pagebuilder-editors (Bricks, Elementor) ongemoeid laten.
        if ( isset( $_GET['bricks'] ) || isset( $_GET['elementor-preview'] ) || isset( $_GET['etch'] ) ) {
            return false;
        }
        // Scanner-bypass: de scanner wil de ongefilterde output zien.
        if ( isset( $_GET['dpcc_scan'] ) && hash_equals( (string) get_option( 'dpcc_scan_key' ), (string) $_GET['dpcc_scan'] ) ) {
            return false;
        }
        return apply_filters( 'dpcc_should_block', true );
    }

    public function maybe_start_buffer() {
        if ( ! $this->should_block() ) {
            return;
        }
        ob_start( [ $this, 'filter_output' ] );
    }

    /**
     * Output-buffer callback: alleen volledige HTML-documenten filteren.
     */
    public function filter_output( $html ) {
        if ( ! is_string( $html ) || '' === $html ) {
            return $html;
        }
        if ( false === stripos( $html, '<html' ) ) {
            return $html;
        }

        $html = $this->block_scripts( $html );
        $html = $this->block_iframes( $html );

        return $html;
    }

    /**
     * Herschrijf tracking-<script>-tags naar type="text/plain".
     *
     * Een browser voert scripts met een onbekend type niet uit en haalt de
     * src ook niet op — de blokkade is dus echt, niet cosmetisch.
     */
    private function block_scripts( $html ) {
        return preg_replace_callback(
            '#<script\b([^>]*)>(.*?)</script>#is',
            function ( $m ) {
                $attrs = $m[1];
                $body  = $m[2];

                // Al door ons behandeld, of eigen banner-script.
                if ( false !== strpos( $attrs, 'data-dpcc' ) || false !== strpos( $attrs, 'dp-cookie-consent' ) ) {
                    return $m[0];
                }

                // Alleen uitvoerbare scripts; JSON-LD e.d. overslaan.
                $orig_type = '';
                if ( preg_match( '#\btype\s*=\s*["\']([^"\']*)["\']#i', $attrs, $tm ) ) {
                    $orig_type = strtolower( trim( $tm[1] ) );
                    $executable = [ '', 'text/javascript', 'application/javascript', 'module' ];
                    if ( ! in_array( $orig_type, $executable, true ) ) {
                        return $m[0];
                    }
                }

                $src = '';
                if ( preg_match( '#\bsrc\s*=\s*["\']([^"\']+)["\']#i', $attrs, $sm ) ) {
                    $src = html_entity_decode( $sm[1] );
                }

                $category = DPCC_Services::match_script( $src, $body );
                if ( ! $category ) {
                    return $m[0];
                }

                // Bestaand type-attribuut strippen, ons type + markering toevoegen.
                $attrs = preg_replace( '#\s*\btype\s*=\s*["\'][^"\']*["\']#i', '', $attrs );

                $extra = '';
                if ( 'module' === $orig_type ) {
                    $extra = ' data-dpcc-type="module"';
                }

                return '<script type="text/plain" data-dpcc="' . esc_attr( $category ) . '"' . $extra . $attrs . '>' . $body . '</script>';
            },
            $html
        );
    }

    /**
     * Neutraliseer embed-iframes: src wordt geparkeerd in data-dpcc-src.
     * De banner-JS plaatst een nette placeholder en herstelt de src na consent.
     */
    private function block_iframes( $html ) {
        return preg_replace_callback(
            '#<iframe\b[^>]*>#i',
            function ( $m ) {
                $tag = $m[0];

                if ( false !== strpos( $tag, 'data-dpcc' ) ) {
                    return $tag;
                }

                // Echte src (negative lookbehind zodat data-src niet meetelt).
                $src = '';
                if ( preg_match( '#(?<![\w-])src\s*=\s*("|\')([^"\']+)\1#i', $tag, $sm ) ) {
                    $src = html_entity_decode( $sm[2] );
                }

                // Lazy-load variant (data-src) apart uitlezen.
                $lazy = '';
                if ( preg_match( '#\bdata-src\s*=\s*("|\')([^"\']+)\1#i', $tag, $lm ) ) {
                    $lazy = html_entity_decode( $lm[2] );
                }

                if ( '' === $src && '' === $lazy ) {
                    return $tag;
                }

                $category = DPCC_Services::match_iframe( $src ?: $lazy );
                if ( ! $category && $src && $lazy ) {
                    $category = DPCC_Services::match_iframe( $lazy );
                }
                if ( ! $category ) {
                    return $tag;
                }

                $real = $src ?: $lazy;

                // Eerst data-src parkeren, dan pas de echte src vervangen.
                if ( $lazy ) {
                    $tag = preg_replace( '#\bdata-src(\s*=)#i', 'data-dpcc-lazy-src$1', $tag, 1 );
                }

                $replacement = 'src="about:blank" data-dpcc-src="' . esc_attr( $real ) . '" data-dpcc="' . esc_attr( $category ) . '"';
                if ( $src ) {
                    $tag = preg_replace( '#(?<![\w-])src\s*=\s*("|\')[^"\']*\1#i', $replacement, $tag, 1 );
                } else {
                    // Alleen een data-src aanwezig: blokkade-attributen toevoegen.
                    $tag = preg_replace( '#>$#', ' ' . $replacement . '>', $tag );
                }

                return $tag;
            },
            $html
        );
    }
}
