<?php
/**
 * Google Consent Mode v2.
 *
 * Wanneer ingeschakeld:
 *  - zet dit vroeg in de <head> alle Google-consent-signalen op 'denied'
 *    (default state), zodat Google-tags cookieloos in denied-modus draaien;
 *  - de Google-tags zelf worden dan NIET hard geblokkeerd (zie
 *    DPCC_Services::blockable);
 *  - bij toestemming stuurt de banner-JS een 'update' naar granted.
 *
 * Het default-snippet krijgt het attribuut data-dpcc zodat de blocker het met
 * rust laat (anders zou het 'gtag('-patroon zichzelf blokkeren).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Consent_Mode {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function enabled() {
        return (bool) DPCC_Settings::val( 'consent_mode' );
    }

    public function init() {
        if ( ! self::enabled() ) {
            return;
        }
        // Zo vroeg mogelijk in de <head>, vóór GTM/GA.
        add_action( 'wp_head', [ $this, 'print_default' ], 0 );
    }

    /**
     * Het Consent Mode default-snippet (alles denied, wacht kort op update).
     */
    public function print_default() {
        if ( ! DPCC_Blocker::instance()->should_block() ) {
            return;
        }
        ?>
<script data-dpcc="consent-mode">
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('consent', 'default', {
    'ad_storage': 'denied',
    'ad_user_data': 'denied',
    'ad_personalization': 'denied',
    'analytics_storage': 'denied',
    'functionality_storage': 'granted',
    'security_storage': 'granted',
    'wait_for_update': 500
});
</script>
        <?php
    }
}
