<?php
/**
 * Instellingen: defaults, ophalen en custom blokkeer-patronen.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Settings {

    public static function defaults() {
        return [
            'enabled'         => 1,
            'title'           => 'Wij gebruiken cookies',
            'text'            => 'We gebruiken cookies om de website goed te laten werken en om te begrijpen hoe bezoekers de site gebruiken. Statistiek- en marketing-cookies plaatsen we alleen met jouw toestemming.',
            'policy_url'      => '',
            'contact_email'   => self::default_contact_email(),
            'accept_label'    => 'Alles accepteren',
            'reject_label'    => 'Alles weigeren',
            'prefs_label'     => 'Voorkeuren',
            'save_label'      => 'Voorkeuren opslaan',
            'accent_source'   => 'acss',    // acss = volg ACSS --primary; custom = eigen hex
            'color_primary'   => '#9e86ff', // fallback-accent (sites zonder ACSS) of eigen kleur
            'color_bg'        => '#141414',
            'color_text'      => '#ffffff',
            'reopen_style'    => 'badge',   // badge = rond icoon | bar = smalle strook (Complianz-stijl)
            'reopen_label'    => 'Beheer toestemming', // tekst op de strook (alleen bij reopen_style = bar)
            'reopen_border'   => '',        // randkleur van de strook (leeg = geen rand)
            'reopen_shadow'   => 1,         // schaduw onder/achter de strook aan/uit
            'badge_custom'    => 0,         // cookie-icoon apart stylen (los van de banner)
            'badge_bg'        => '#141414', // cirkel-kleur van het icoon (bij badge_custom)
            'badge_icon'      => '#9e86ff', // pictogram-kleur van het icoon (bij badge_custom)
            'position'        => 'left',   // left | right | center
            'expiry_days'     => 180,
            'consent_version' => 1,
            'custom_patterns' => '',
            'auto_scan_interval' => 1, // maanden; 0 = uit
            'log_consent'        => 1,   // consent-logboek aan/uit
            'log_retention_days' => 365, // bewaartermijn logboek in dagen; 0 = nooit opruimen
            'consent_mode'       => 0,   // Google Consent Mode v2 aan/uit
            'honor_gpc'          => 1,   // Global Privacy Control / DNT respecteren

        ];
    }

    /**
     * Standaard contact-e-mailadres: info@<domein> (zonder www), of het
     * WordPress-beheerdersadres als de host niet te bepalen is.
     */
    private static function default_contact_email() {
        $host = wp_parse_url( home_url(), PHP_URL_HOST );
        $host = preg_replace( '/^www\./i', '', (string) $host );
        return $host ? 'info@' . $host : get_option( 'admin_email' );
    }

    /**
     * Volledige settings-array (defaults + opgeslagen waarden).
     */
    public static function get() {
        $saved = get_option( 'dpcc_settings', [] );
        if ( ! is_array( $saved ) ) {
            $saved = [];
        }
        return array_merge( self::defaults(), $saved );
    }

    /**
     * Eén instelling.
     */
    public static function val( $key ) {
        $settings = self::get();
        return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
    }

    /**
     * Custom blokkeer-patronen uit de instellingen.
     *
     * Formaat in de textarea: één per regel, "regex|categorie", bijv.:
     *   mijn-tracker\.example\.com|marketing
     *
     * @return array [ [ 'pattern' => ..., 'category' => ... ], ... ]
     */
    public static function custom_patterns() {
        $raw = (string) self::val( 'custom_patterns' );
        if ( '' === trim( $raw ) ) {
            return [];
        }

        $valid_categories = DPCC_Services::consent_categories();
        $out              = [];

        foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
            $line = trim( $line );
            if ( '' === $line || 0 === strpos( $line, '#' ) ) {
                continue;
            }
            $parts    = explode( '|', $line );
            $pattern  = trim( $parts[0] );
            $category = isset( $parts[1] ) ? trim( strtolower( $parts[1] ) ) : 'marketing';

            if ( '' === $pattern || false === @preg_match( '#' . $pattern . '#i', '' ) ) {
                continue; // ongeldig regex-patroon overslaan
            }
            if ( ! in_array( $category, $valid_categories, true ) ) {
                $category = 'marketing';
            }
            $out[] = [
                'pattern'  => $pattern,
                'category' => $category,
            ];
        }

        return $out;
    }
}
