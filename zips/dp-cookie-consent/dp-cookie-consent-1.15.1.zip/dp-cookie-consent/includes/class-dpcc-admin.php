<?php
/**
 * Admin: menupagina met tabbladen Instellingen en Scanner & overzicht.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DPCC_Admin {

    private static $instance = null;

    /** Hook-suffix van onze menupagina (voor gerichte asset-enqueue). */
    private $hook = '';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'admin_menu', [ $this, 'menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_post_dpcc_save_settings', [ $this, 'save_settings' ] );
        add_action( 'admin_post_dpcc_bump_version', [ $this, 'bump_version' ] );
        add_action( 'admin_post_dpcc_save_register', [ $this, 'save_register' ] );

        // Self-heal: cron-event terugzetten als het weg is (bijv. na update).
        add_action( 'admin_init', function () {
            DPCC_Scanner::instance()->ensure_scheduled();
        } );
    }

    public function menu() {
        // Badge met het aantal nog-nooit-gescande pagina's (zoals het
        // update-bolletje van WordPress zelf).
        $pending = DPCC_Scanner::instance()->pending_count();
        $title   = 'DP Consent';
        if ( $pending > 0 ) {
            $title .= sprintf( ' <span class="awaiting-mod">%d</span>', $pending );
        }

        $this->hook = add_menu_page(
            'DP Cookie Consent',
            $title,
            'manage_options',
            'dp-cookie-consent',
            [ $this, 'render_page' ],
            'dashicons-shield-alt',
            81
        );
    }

    /**
     * Laad WordPress' eigen kleurkiezer (Iris) op onze instellingenpagina.
     * Dit is een inline paletje — géén native OS-kleurdialoog die kan vastlopen.
     */
    public function enqueue_assets( $hook ) {
        if ( $hook !== $this->hook ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );

        $js = <<<'JS'
jQuery(function ($) {
    $('.dpcc-color').each(function () {
        var opts = {};
        if (this.id === 'dpcc-color-primary') {
            // Kies je bewust een accentkleur, dan die kleur ook gebruiken.
            opts.change = function () { $('#dpcc-accent-source').val('custom'); };
        }
        $(this).wpColorPicker(opts);
    });
});
JS;
        wp_add_inline_script( 'wp-color-picker', $js );
    }

    /* ------------------------------------------------------------------ */
    /*  Opslaan                                                            */
    /* ------------------------------------------------------------------ */

    public function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_save_settings' );

        $current = DPCC_Settings::get();
        $post    = wp_unslash( $_POST );

        $new = [
            'enabled'         => empty( $post['enabled'] ) ? 0 : 1,
            'title'           => sanitize_text_field( $post['title'] ?? $current['title'] ),
            'text'            => wp_kses_post( $post['text'] ?? $current['text'] ),
            'policy_url'      => esc_url_raw( $post['policy_url'] ?? '' ),
            'contact_email'   => sanitize_email( $post['contact_email'] ?? '' ) ?: $current['contact_email'],
            'accent_source'   => in_array( $post['accent_source'] ?? 'acss', [ 'acss', 'custom' ], true ) ? $post['accent_source'] : 'acss',
            'accept_label'    => sanitize_text_field( $post['accept_label'] ?? $current['accept_label'] ),
            'reject_label'    => sanitize_text_field( $post['reject_label'] ?? $current['reject_label'] ),
            'prefs_label'     => sanitize_text_field( $post['prefs_label'] ?? $current['prefs_label'] ),
            'save_label'      => sanitize_text_field( $post['save_label'] ?? $current['save_label'] ),
            'color_primary'   => sanitize_hex_color( $post['color_primary'] ?? '' ) ?: $current['color_primary'],
            'color_bg'        => sanitize_hex_color( $post['color_bg'] ?? '' ) ?: $current['color_bg'],
            'color_text'      => sanitize_hex_color( $post['color_text'] ?? '' ) ?: $current['color_text'],
            'reopen_style'    => in_array( $post['reopen_style'] ?? 'badge', [ 'badge', 'bar' ], true ) ? $post['reopen_style'] : 'badge',
            'reopen_label'    => sanitize_text_field( $post['reopen_label'] ?? $current['reopen_label'] ),
            'reopen_border'   => sanitize_hex_color( $post['reopen_border'] ?? '' ) ?: '', // leeg = geen rand
            'reopen_shadow'   => empty( $post['reopen_shadow'] ) ? 0 : 1,
            'badge_custom'    => empty( $post['badge_custom'] ) ? 0 : 1,
            'badge_bg'        => sanitize_hex_color( $post['badge_bg'] ?? '' ) ?: $current['badge_bg'],
            'badge_icon'      => sanitize_hex_color( $post['badge_icon'] ?? '' ) ?: $current['badge_icon'],
            'position'        => in_array( $post['position'] ?? '', [ 'left', 'right', 'center' ], true ) ? $post['position'] : 'left',
            'expiry_days'     => max( 1, min( 365, (int) ( $post['expiry_days'] ?? 180 ) ) ),
            'consent_version' => (int) $current['consent_version'],
            'custom_patterns' => sanitize_textarea_field( $post['custom_patterns'] ?? '' ),
            'auto_scan_interval' => in_array( (int) ( $post['auto_scan_interval'] ?? 1 ), [ 0, 1, 2, 3, 6, 12 ], true ) ? (int) $post['auto_scan_interval'] : 1,
            'log_consent'        => empty( $post['log_consent'] ) ? 0 : 1,
            'log_retention_days' => max( 0, min( 3650, (int) ( $post['log_retention_days'] ?? 365 ) ) ),
            'consent_mode'       => empty( $post['consent_mode'] ) ? 0 : 1,
            'honor_gpc'          => empty( $post['honor_gpc'] ) ? 0 : 1,
        ];

        update_option( 'dpcc_settings', $new );

        // Cron opnieuw inplannen met het (mogelijk gewijzigde) interval.
        DPCC_Scanner::instance()->reschedule();

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'dp-cookie-consent', 'dpcc_saved' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /**
     * Consent-versie ophogen: alle bezoekers krijgen de banner opnieuw te zien.
     */
    public function bump_version() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_bump_version' );

        $settings                    = DPCC_Settings::get();
        $settings['consent_version'] = (int) $settings['consent_version'] + 1;
        update_option( 'dpcc_settings', $settings );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'dp-cookie-consent', 'dpcc_bumped' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /**
     * Cookie-register: handmatige classificatie van onbekende cookies uit de
     * browser-scan. Eén keer kiezen = overal bekend (scanner-overzicht én de
     * [dpcc_cookies]-tabel op de beleidspagina).
     */
    public function save_register() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Geen toegang.' );
        }
        check_admin_referer( 'dpcc_save_register' );

        $register = get_option( 'dpcc_cookie_register', [] );
        if ( ! is_array( $register ) ) {
            $register = [];
        }

        $cats   = isset( $_POST['dpcc_reg_cat'] ) && is_array( $_POST['dpcc_reg_cat'] ) ? wp_unslash( $_POST['dpcc_reg_cat'] ) : [];
        $labels = isset( $_POST['dpcc_reg_label'] ) && is_array( $_POST['dpcc_reg_label'] ) ? wp_unslash( $_POST['dpcc_reg_label'] ) : [];
        $valid  = array_merge( array_keys( DPCC_Services::categories() ), [ 'negeren' ] );

        foreach ( $cats as $name => $cat ) {
            $name = sanitize_text_field( $name );
            $cat  = sanitize_text_field( $cat );
            if ( '' === $name || '' === $cat || ! in_array( $cat, $valid, true ) ) {
                continue; // "— kies —" of ongeldig: overslaan
            }
            $register[ $name ] = [
                'category' => $cat,
                'label'    => sanitize_text_field( $labels[ $name ] ?? '' ),
            ];
        }

        update_option( 'dpcc_cookie_register', $register, false );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'dp-cookie-consent', 'tab' => 'scanner', 'dpcc_registered' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /* ------------------------------------------------------------------ */
    /*  Weergave                                                           */
    /* ------------------------------------------------------------------ */

    public function render_page() {
        $allowed_tabs = [ 'settings', 'scanner', 'log' ];
        $tab          = isset( $_GET['tab'] ) && in_array( $_GET['tab'], $allowed_tabs, true ) ? $_GET['tab'] : 'settings';
        ?>
        <div class="wrap">
            <h1>DP Cookie Consent <small style="font-size:.55em;color:#888;">v<?php echo esc_html( DPCC_VERSION ); ?> &mdash; Design Pixels</small></h1>

            <?php if ( isset( $_GET['dpcc_saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Instellingen opgeslagen.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_scanned'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Scan afgerond.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_bscanned'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Browser-scan afgerond — zie de resultaten onder "Gevonden in de browser".</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_fullscan'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Volledige scan afgerond (server + browser) — zie de resultaten hieronder.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_registered'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Cookie-classificatie opgeslagen. Deze cookies worden voortaan herkend en staan automatisch in de cookie-tabel op de beleidspagina.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_bumped'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Consent-versie opgehoogd — alle bezoekers krijgen de banner opnieuw te zien.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_policy_created'] ) ) : ?>
                <?php if ( $_GET['dpcc_policy_created'] ) : ?>
                    <div class="notice notice-success is-dismissible"><p>Cookiebeleid-pagina aangemaakt en gekoppeld aan de banner. Controleer de tekst en pas 'm waar nodig aan.</p></div>
                <?php else : ?>
                    <div class="notice notice-error is-dismissible"><p>De cookiebeleid-pagina kon niet worden aangemaakt.</p></div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_policy_exists'] ) ) : ?>
                <div class="notice notice-warning is-dismissible"><p>Er bestaat al een door de plugin aangemaakte cookiebeleid-pagina.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['dpcc_policy_noscan'] ) ) : ?>
                <div class="notice notice-warning is-dismissible"><p>Voer eerst een cookie-scan uit (tabblad Scanner &amp; overzicht) voordat je de beleidspagina aanmaakt.</p></div>
            <?php endif; ?>
            <?php $this->maybe_changes_notice(); ?>

            <h2 class="nav-tab-wrapper">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent' ) ); ?>" class="nav-tab <?php echo 'settings' === $tab ? 'nav-tab-active' : ''; ?>">Instellingen</a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent&tab=scanner' ) ); ?>" class="nav-tab <?php echo 'scanner' === $tab ? 'nav-tab-active' : ''; ?>">Scanner &amp; overzicht</a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent&tab=log' ) ); ?>" class="nav-tab <?php echo 'log' === $tab ? 'nav-tab-active' : ''; ?>">Consent-log</a>
            </h2>

            <?php
            if ( 'scanner' === $tab ) {
                $this->render_scanner_tab();
            } elseif ( 'log' === $tab ) {
                $this->render_log_tab();
            } else {
                $this->render_settings_tab();
            }
            ?>
        </div>
        <?php
    }

    /**
     * Info-melding over de laatst gevonden wijzigingen in de dienstenlijst.
     */
    private function maybe_changes_notice() {
        $changes = get_option( 'dpcc_scan_changes', [] );
        if ( empty( $changes['time'] ) ) {
            return;
        }

        $services = DPCC_Services::all();
        $name     = function ( $id ) use ( $services ) {
            return isset( $services[ $id ] ) ? $services[ $id ]['label'] : $id;
        };

        $parts = [];
        if ( ! empty( $changes['added'] ) ) {
            $parts[] = 'nieuw gevonden: <strong>' . esc_html( implode( ', ', array_map( $name, $changes['added'] ) ) ) . '</strong>';
        }
        if ( ! empty( $changes['removed'] ) ) {
            $parts[] = 'niet meer aangetroffen: <strong>' . esc_html( implode( ', ', array_map( $name, $changes['removed'] ) ) ) . '</strong>';
        }
        if ( ! $parts ) {
            return;
        }
        ?>
        <div class="notice notice-info">
            <p>
                <strong>Wijzigingen bij de scan van <?php echo esc_html( wp_date( 'j F Y H:i', $changes['time'] ) ); ?>:</strong>
                <?php echo implode( ' &mdash; ', $parts ); // phpcs:ignore ?>.
                De beleidspagina is bijgewerkt<?php echo ! empty( $changes['bumped'] ) ? ' en de consent-versie is opgehoogd: alle bezoekers krijgen de banner opnieuw te zien' : ''; ?>.
            </p>
        </div>
        <?php
    }

    private function render_settings_tab() {
        $s = DPCC_Settings::get();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'dpcc_save_settings' ); ?>
            <input type="hidden" name="action" value="dpcc_save_settings">

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Banner actief</th>
                    <td><label><input type="checkbox" name="enabled" value="1" <?php checked( $s['enabled'] ); ?>> Banner tonen en scripts blokkeren</label></td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-title">Titel</label></th>
                    <td><input type="text" class="regular-text" id="dpcc-title" name="title" value="<?php echo esc_attr( $s['title'] ); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-text">Tekst</label></th>
                    <td><textarea class="large-text" rows="3" id="dpcc-text" name="text"><?php echo esc_textarea( $s['text'] ); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-policy">URL cookieverklaring</label></th>
                    <td>
                        <input type="url" class="regular-text" id="dpcc-policy" name="policy_url" value="<?php echo esc_attr( $s['policy_url'] ); ?>" placeholder="https://...">
                        <p class="description">Gebruik de shortcode <code>[dpcc_cookies]</code> op die pagina voor een automatische cookie-overzichtstabel.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-contact-email">Contact e-mailadres</label></th>
                    <td>
                        <input type="email" class="regular-text" id="dpcc-contact-email" name="contact_email" value="<?php echo esc_attr( $s['contact_email'] ); ?>" placeholder="info@voorbeeld.nl">
                        <p class="description">Getoond in het contactblok van de cookiebeleid-pagina. Standaard <code>info@</code> van je domein. Aanpassen werkt direct door op de bestaande pagina.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Knop-teksten</th>
                    <td>
                        <input type="text" name="accept_label" value="<?php echo esc_attr( $s['accept_label'] ); ?>" placeholder="Alles accepteren">
                        <input type="text" name="reject_label" value="<?php echo esc_attr( $s['reject_label'] ); ?>" placeholder="Alles weigeren">
                        <input type="text" name="prefs_label" value="<?php echo esc_attr( $s['prefs_label'] ); ?>" placeholder="Voorkeuren">
                        <input type="text" name="save_label" value="<?php echo esc_attr( $s['save_label'] ); ?>" placeholder="Voorkeuren opslaan">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-accent-source">Accent-kleur</label></th>
                    <td>
                        <select id="dpcc-accent-source" name="accent_source">
                            <option value="acss" <?php selected( $s['accent_source'], 'acss' ); ?>>Volg de ACSS-kleur (--primary) van de site</option>
                            <option value="custom" <?php selected( $s['accent_source'], 'custom' ); ?>>Eigen kleur (hieronder)</option>
                        </select>
                        <p class="description">Bij "Volg de ACSS-kleur" gebruikt de banner automatisch de <code>--primary</code> van de site — de kleur hieronder dient dan alleen als fallback voor sites zonder ACSS.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Banner-kleuren</th>
                    <td>
                        <p><label style="display:inline-block;min-width:110px;">Accent</label> <input type="text" class="dpcc-color" id="dpcc-color-primary" name="color_primary" value="<?php echo esc_attr( $s['color_primary'] ); ?>"></p>
                        <p><label style="display:inline-block;min-width:110px;">Achtergrond</label> <input type="text" class="dpcc-color" name="color_bg" value="<?php echo esc_attr( $s['color_bg'] ); ?>"></p>
                        <p><label style="display:inline-block;min-width:110px;">Tekst</label> <input type="text" class="dpcc-color" name="color_text" value="<?php echo esc_attr( $s['color_text'] ); ?>"></p>
                        <p class="description">De kleuren van de consent-banner zelf. De accentkleur telt alleen mee als "Accent-kleur" hierboven op "Eigen kleur" staat — anders wint de ACSS-kleur van de site.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-reopen-style">Heropen-knop</label></th>
                    <td>
                        <select id="dpcc-reopen-style" name="reopen_style">
                            <option value="badge" <?php selected( $s['reopen_style'], 'badge' ); ?>>Rond icoon (zwevende cookie-knop)</option>
                            <option value="bar" <?php selected( $s['reopen_style'], 'bar' ); ?>>Smalle strook onderin (klapt uit bij hover)</option>
                        </select>
                        <p style="margin-top:10px;">
                            <label for="dpcc-reopen-label" style="display:inline-block;min-width:110px;">Strook-tekst</label>
                            <input type="text" class="regular-text" id="dpcc-reopen-label" name="reopen_label" value="<?php echo esc_attr( $s['reopen_label'] ); ?>" placeholder="Beheer toestemming">
                        </p>
                        <p>
                            <label style="display:inline-block;min-width:110px;">Randkleur</label>
                            <input type="text" class="dpcc-color" name="reopen_border" value="<?php echo esc_attr( $s['reopen_border'] ); ?>">
                        </p>
                        <p><label><input type="checkbox" name="reopen_shadow" value="1" <?php checked( $s['reopen_shadow'] ); ?>> Schaduw achter de strook</label></p>
                        <p class="description">Nadat de bezoeker een keuze heeft gemaakt, kan hij zijn toestemming later opnieuw beheren via deze knop. <strong>Rond icoon</strong>: de zwevende cookie-knop (standaard). <strong>Smalle strook</strong>: een heel plat lipje tegen de onderrand met een pijltje-omhoog, dat bij hover uitklapt met de strook-tekst — botst niet met een chat- of "terug naar boven"-knop. Randkleur leeg = geen rand. De strook volgt de positie (links/rechts) hieronder; "midden onder" valt terug op links.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Cookie-icoon</th>
                    <td>
                        <label><input type="checkbox" id="dpcc-badge-custom" name="badge_custom" value="1" <?php checked( $s['badge_custom'] ); ?>> Het cookie-icoon (rond icoon én strook) apart stylen, los van de banner</label>
                        <p style="margin-top:10px;"><label style="display:inline-block;min-width:110px;">Pictogram</label> <input type="text" class="dpcc-color" name="badge_icon" value="<?php echo esc_attr( $s['badge_icon'] ); ?>"></p>
                        <p><label style="display:inline-block;min-width:110px;">Cirkel</label> <input type="text" class="dpcc-color" name="badge_bg" value="<?php echo esc_attr( $s['badge_bg'] ); ?>"></p>
                        <p class="description">De pictogram- en cirkel-kleuren gelden alleen als "apart stylen" hierboven aan staat. Anders volgt het icoon de banner (cirkel = Achtergrond, pictogram = Accent). Bij hover wisselen de twee kleuren.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-position">Positie</label></th>
                    <td>
                        <select id="dpcc-position" name="position">
                            <option value="left" <?php selected( $s['position'], 'left' ); ?>>Linksonder</option>
                            <option value="right" <?php selected( $s['position'], 'right' ); ?>>Rechtsonder</option>
                            <option value="center" <?php selected( $s['position'], 'center' ); ?>>Midden onder</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-expiry">Consent-bewaartermijn</label></th>
                    <td><input type="number" id="dpcc-expiry" name="expiry_days" value="<?php echo esc_attr( $s['expiry_days'] ); ?>" min="1" max="365" style="width:80px;"> dagen</td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-autoscan">Automatische scan</label></th>
                    <td>
                        <select id="dpcc-autoscan" name="auto_scan_interval">
                            <option value="0" <?php selected( (int) $s['auto_scan_interval'], 0 ); ?>>Uit</option>
                            <option value="1" <?php selected( (int) $s['auto_scan_interval'], 1 ); ?>>Elke maand</option>
                            <option value="2" <?php selected( (int) $s['auto_scan_interval'], 2 ); ?>>Elke 2 maanden</option>
                            <option value="3" <?php selected( (int) $s['auto_scan_interval'], 3 ); ?>>Elke 3 maanden</option>
                            <option value="6" <?php selected( (int) $s['auto_scan_interval'], 6 ); ?>>Elk half jaar</option>
                            <option value="12" <?php selected( (int) $s['auto_scan_interval'], 12 ); ?>>Elk jaar</option>
                        </select>
                        <?php $next = wp_next_scheduled( 'dpcc_auto_scan' ); ?>
                        <?php if ( $next ) : ?>
                            <p class="description">Volgende automatische scan: <?php echo esc_html( wp_date( 'j F Y H:i', $next ) ); ?>.</p>
                        <?php endif; ?>
                        <p class="description">Vindt de scan een nieuwe tracker, dan wordt de beleidspagina bijgewerkt en de consent-versie automatisch opgehoogd (banner verschijnt opnieuw). Verdwijnt er alleen een dienst, dan wordt alleen de beleidspagina bijgewerkt.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Privacy-signaal (GPC/DNT)</th>
                    <td>
                        <label><input type="checkbox" name="honor_gpc" value="1" <?php checked( $s['honor_gpc'] ); ?>> Global Privacy Control / Do-Not-Track respecteren</label>
                        <p class="description">Stuurt de browser van een bezoeker een opt-out-signaal (GPC of DNT), dan wordt automatisch "alles weigeren" toegepast en verschijnt de banner niet. De bezoeker kan het altijd nog aanpassen via het cookie-icoon. Een eerder gegeven expliciete keuze blijft leidend.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Google Consent Mode v2</th>
                    <td>
                        <label><input type="checkbox" name="consent_mode" value="1" <?php checked( $s['consent_mode'] ); ?>> Consent Mode-signalen sturen naar Google-tags</label>
                        <p class="description">
                            Aan: Google Tag Manager, Analytics en Ads worden <em>niet</em> hard geblokkeerd, maar draaien vóór toestemming in Google's cookieloze <code>denied</code>-modus (beter voor conversie-/remarketingmeting bij Google Ads). Bij toestemming volgt automatisch een <code>update</code>-signaal.
                            Uit (standaard): ook Google-tags worden volledig geblokkeerd tot toestemming (strengst). Overige trackers zoals Meta en Hotjar worden in beide gevallen geblokkeerd tot toestemming.
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Consent-logboek</th>
                    <td>
                        <label><input type="checkbox" name="log_consent" value="1" <?php checked( $s['log_consent'] ); ?>> Toestemmingen server-side vastleggen (bewijs van toestemming, AVG art. 7)</label>
                        <p style="margin-top:8px;">
                            <label for="dpcc-retention">Bewaartermijn</label>
                            <input type="number" id="dpcc-retention" name="log_retention_days" value="<?php echo esc_attr( $s['log_retention_days'] ); ?>" min="0" max="3650" style="width:90px;"> dagen
                            <span class="description">(0 = nooit automatisch opruimen)</span>
                        </p>
                        <p class="description">Bekijken en exporteren kan op het tabblad <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent&tab=log' ) ); ?>">Consent-log</a>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dpcc-patterns">Extra blokkeer-patronen</label></th>
                    <td>
                        <textarea class="large-text code" rows="4" id="dpcc-patterns" name="custom_patterns" placeholder="voorbeeld-tracker\.com|marketing"><?php echo esc_textarea( $s['custom_patterns'] ); ?></textarea>
                        <p class="description">Eén per regel: <code>regex-patroon|categorie</code> (categorie: <code>statistieken</code> of <code>marketing</code>). Matcht op script-src, inline scripts en iframes. Regels die beginnen met <code>#</code> worden genegeerd.</p>
                    </td>
                </tr>
            </table>

            <?php submit_button( 'Instellingen opslaan' ); ?>
        </form>

        <hr>
        <h2>Cookiebeleid-pagina</h2>
        <?php $policy_page = DPCC_Policy::instance()->existing_page(); ?>
        <?php if ( $policy_page ) : ?>
            <p>
                De plugin heeft de pagina <strong><?php echo esc_html( $policy_page->post_title ); ?></strong> aangemaakt
                (status: <?php echo esc_html( get_post_status_object( $policy_page->post_status )->label ?? $policy_page->post_status ); ?>).
                &nbsp;<a href="<?php echo esc_url( get_edit_post_link( $policy_page->ID ) ); ?>" class="button">Bewerken</a>
                &nbsp;<a href="<?php echo esc_url( get_permalink( $policy_page->ID ) ); ?>" class="button" target="_blank" rel="noopener">Bekijken</a>
            </p>
            <p class="description">De cookie-tabel op die pagina (<code>[dpcc_cookies]</code>) vult zichzelf op basis van de laatste scan — na een nieuwe scan is de tabel dus automatisch actueel.</p>
        <?php else : ?>
            <p>Laat de plugin een complete cookiebeleid-pagina genereren: uitleg over cookies, de gebruikte categorieën, hoe blokkeren werkt, de automatische cookie-tabel (<code>[dpcc_cookies]</code>), instructies om toestemming in te trekken en jouw AVG-rechten. De pagina wordt direct gepubliceerd en als beleids-URL aan de banner gekoppeld.</p>
            <?php
            $scan_results = get_option( 'dpcc_scan_results', [] );
            $has_scan     = ! empty( $scan_results['time'] );
            ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'dpcc_create_policy' ); ?>
                <input type="hidden" name="action" value="dpcc_create_policy">
                <?php submit_button( 'Maak cookiebeleid-pagina aan', 'secondary', 'submit', false, $has_scan ? [] : [ 'disabled' => 'disabled' ] ); ?>
            </form>
            <?php if ( ! $has_scan ) : ?>
                <p class="description">Deze knop wordt beschikbaar zodra je een cookie-scan hebt uitgevoerd (tabblad <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent&tab=scanner' ) ); ?>">Scanner &amp; overzicht</a>) — anders zou de cookie-tabel op de beleidspagina leeg zijn.</p>
            <?php endif; ?>
        <?php endif; ?>

        <hr>
        <h2>Opnieuw toestemming vragen</h2>
        <p>Na grote wijzigingen (nieuwe tracker, ander cookiebeleid) hoor je bezoekers opnieuw om toestemming te vragen. Huidige consent-versie: <strong><?php echo (int) $s['consent_version']; ?></strong></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'dpcc_bump_version' ); ?>
            <input type="hidden" name="action" value="dpcc_bump_version">
            <?php submit_button( 'Vraag alle bezoekers opnieuw om toestemming', 'secondary', 'submit', false ); ?>
        </form>
        <?php
    }

    private function render_scanner_tab() {
        $results  = get_option( 'dpcc_scan_results', [] );
        $services = DPCC_Services::all();
        $labels   = DPCC_Services::categories();
        ?>
        <?php
        $scanner    = DPCC_Scanner::instance();
        $bscan_urls = $scanner->browser_scan_urls();
        $pending    = $scanner->pending_count();
        ?>
        <p>De scan werkt in twee stappen: <strong>1)</strong> de server haalt de pagina's op en detecteert bekende diensten, onbekende externe scripts en server-cookies; <strong>2)</strong> dezelfde pagina's draaien daarna in een verborgen venster in déze browser, zodat ook cookies zichtbaar worden die puur via JavaScript gezet worden (zoals <code>_ga</code>).</p>

        <?php if ( $pending > 0 ) : ?>
            <p><strong><?php echo (int) $pending; ?> pagina('s) nog nooit gescand</strong> — die krijgen voorrang bij de volgende scan.</p>
        <?php endif; ?>

        <p>
            <button type="button" id="dpcc-scan-start" class="button button-primary">Scan de site nu (<?php echo count( $bscan_urls ); ?> pagina's)</button>
            <span id="dpcc-bscan-status" style="margin-left:8px;"></span>
        </p>
        <p class="description">Tip: zet een eventuele adblocker voor deze site even uit — anders blokkeert die de trackers en lijkt de site schoner dan hij is. De automatische periodieke scan draait alleen stap 1 (die heeft geen browser); stap 2 loopt mee wanneer je hier handmatig scant.</p>

        <noscript>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:1.5em;">
                <?php wp_nonce_field( 'dpcc_scan' ); ?>
                <input type="hidden" name="action" value="dpcc_scan">
                <?php submit_button( 'Scan de site nu (alleen server-scan)', 'primary', 'submit', false ); ?>
            </form>
        </noscript>

        <div id="dpcc-bscan-holder" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true"></div>
        <script>
        (function () {
            var btn = document.getElementById('dpcc-scan-start');
            if (!btn) { return; }
            var urls      = <?php echo wp_json_encode( $bscan_urls ); ?>;
            var doneUrl   = <?php echo wp_json_encode( admin_url( 'admin.php?page=dp-cookie-consent&tab=scanner&dpcc_fullscan=1' ) ); ?>;
            var adminPost = <?php echo wp_json_encode( admin_url( 'admin-post.php' ) ); ?>;
            var nonce     = <?php echo wp_json_encode( wp_create_nonce( 'dpcc_scan' ) ); ?>;
            var restUrl   = <?php echo wp_json_encode( esc_url_raw( rest_url( 'dpcc/v1/browser-scan' ) ) ); ?>;
            var restNonce = <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>;
            var holder    = document.getElementById('dpcc-bscan-holder');
            var status    = document.getElementById('dpcc-bscan-status');
            var i = 0, timer = null, running = false;

            // Momentopname van wat er NU al in de browser staat (cookies +
            // opslag). De server filtert deze "voorraad" straks weg, zodat
            // oude restanten en builder-/admin-sleutels niet als vondst tellen.
            function captureBaseline() {
                var cookies = [];
                if (document.cookie) {
                    document.cookie.split(';').forEach(function (c) {
                        var n = c.split('=')[0].trim();
                        if (n && cookies.indexOf(n) === -1) { cookies.push(n); }
                    });
                }
                var storage = [];
                try { for (var i = 0; i < localStorage.length; i++) { storage.push(localStorage.key(i)); } } catch (e) {}
                try { for (var j = 0; j < sessionStorage.length; j++) { storage.push(sessionStorage.key(j)); } } catch (e) {}
                return { cookies: cookies, storage: storage };
            }

            function next() {
                if (timer) { clearTimeout(timer); }
                holder.innerHTML = '';
                if (i >= urls.length) {
                    status.textContent = 'Klaar — resultaten laden…';
                    window.location = doneUrl;
                    return;
                }
                status.textContent = 'Stap 2/2 — browser-scan: pagina ' + (i + 1) + ' van ' + urls.length + '…';
                var f = document.createElement('iframe');
                f.src = urls[i];
                holder.appendChild(f);
                i++;
                // Vangnet: pagina's zonder wp_footer of met een JS-fout
                // mogen de scan niet blokkeren.
                timer = setTimeout(next, 20000);
            }

            window.addEventListener('message', function (e) {
                if (running && e.data === 'dpcc:page-done') { next(); }
            });

            function startBrowserScan() {
                // Reset + baseline vastleggen vóór de eerste pagina laadt.
                var body = JSON.stringify({ reset: true, baseline: captureBaseline() });
                fetch(restUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': restNonce },
                    credentials: 'same-origin',
                    body: body
                }).then(function () { i = 0; next(); }, function () { i = 0; next(); });
            }

            btn.addEventListener('click', function () {
                btn.disabled = true;
                running = true;
                status.textContent = 'Stap 1/2 — server-scan bezig…';

                var fd = new FormData();
                fd.append('action', 'dpcc_scan');
                fd.append('_wpnonce', nonce);
                fd.append('dpcc_ajax', '1');

                fetch(adminPost, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(startBrowserScan,
                          function () { status.textContent = 'Server-scan mislukt; browser-scan start toch…'; startBrowserScan(); });
            });
        })();
        </script>

        <?php $this->render_browser_scan_section(); ?>

        <?php if ( empty( $results['time'] ) ) : ?>
            <p><em>Nog geen scan uitgevoerd.</em></p>
            <?php return; ?>
        <?php endif; ?>

        <p><strong>Laatste scan:</strong> <?php echo esc_html( wp_date( 'j F Y H:i', $results['time'] ) ); ?> &mdash; <?php echo count( $results['scanned'] ); ?> pagina's gescand.</p>

        <?php if ( ! empty( $results['errors'] ) ) : ?>
            <div class="notice notice-warning"><p><strong>Niet alle pagina's konden gescand worden:</strong><br><?php echo esc_html( implode( ' / ', $results['errors'] ) ); ?></p></div>
        <?php endif; ?>

        <h2>Gedetecteerde diensten</h2>
        <?php if ( empty( $results['services'] ) ) : ?>
            <p>Geen bekende tracking-diensten gevonden. 🎉</p>
        <?php else : ?>
            <table class="widefat striped">
                <thead><tr><th>Dienst</th><th>Categorie</th><th>Cookies</th><th>Gevonden op</th></tr></thead>
                <tbody>
                <?php foreach ( $results['services'] as $id => $info ) :
                    if ( ! isset( $services[ $id ] ) ) {
                        continue;
                    }
                    $service = $services[ $id ];
                    $cookies = array_map( function ( $c ) {
                        return $c[0] . ' (' . $c[1] . ')';
                    }, $service['cookies'] );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $service['label'] ); ?></strong></td>
                        <td><?php echo esc_html( $labels[ $service['category'] ] ); ?><?php echo 'noodzakelijk' === $service['category'] ? '' : ' <span style="color:#46b450;">— wordt geblokkeerd tot consent</span>'; ?></td>
                        <td><?php echo esc_html( implode( ', ', $cookies ) ); ?></td>
                        <td><?php echo esc_html( implode( ', ', array_map( function ( $u ) {
                            return wp_parse_url( $u, PHP_URL_PATH ) ?: '/';
                        }, $info['pages'] ) ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if ( ! empty( $results['unknown'] ) ) : ?>
            <h2>Onbekende externe scripts</h2>
            <p>Deze scripts komen van externe domeinen die niet in de databank staan. Controleer of ze cookies plaatsen; zo ja, voeg ze toe via "Extra blokkeer-patronen" op het tabblad Instellingen.</p>
            <table class="widefat striped">
                <thead><tr><th>Domein</th><th>Gevonden op</th></tr></thead>
                <tbody>
                <?php foreach ( $results['unknown'] as $host => $url ) : ?>
                    <tr>
                        <td><code><?php echo esc_html( $host ); ?></code></td>
                        <td><?php echo esc_html( wp_parse_url( $url, PHP_URL_PATH ) ?: '/' ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if ( ! empty( $results['cookies'] ) ) : ?>
            <h2>First-party cookies (via HTTP-headers)</h2>
            <table class="widefat striped">
                <thead><tr><th>Cookie</th><th>Gezet op</th></tr></thead>
                <tbody>
                <?php foreach ( $results['cookies'] as $name => $url ) : ?>
                    <tr>
                        <td><code><?php echo esc_html( $name ); ?></code></td>
                        <td><?php echo esc_html( wp_parse_url( $url, PHP_URL_PATH ) ?: '/' ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <p class="description" style="margin-top:1em;">Let op: cookies die puur client-side via JavaScript gezet worden (zoals <code>_ga</code>) verschijnen niet in de first-party-lijst — die worden afgedekt via de dienst-detectie hierboven.</p>
        <?php
    }

    /**
     * Resultaten van de browser-scan + het cookie-register voor onbekende
     * cookies (één keer classificeren = overal bekend, incl. de
     * [dpcc_cookies]-tabel op de beleidspagina).
     */
    private function render_browser_scan_section() {
        $browser = get_option( 'dpcc_browser_results', [] );
        if ( empty( $browser['time'] ) ) {
            return;
        }

        $labels  = DPCC_Services::categories();
        $unknown = [];
        ?>
        <hr>
        <h2>Gevonden in de browser <small style="font-weight:normal;color:#888;">(laatste browser-scan: <?php echo esc_html( wp_date( 'j F Y H:i', $browser['time'] ) ); ?>, <?php echo count( (array) $browser['pages'] ); ?> pagina's)</small></h2>
        <table class="widefat striped">
            <thead><tr><th>Cookie</th><th>Herkomst</th><th>Categorie</th><th>Gezien op</th></tr></thead>
            <tbody>
            <?php foreach ( (array) $browser['cookies'] as $name => $url ) :
                $match = DPCC_Scanner::classify_client_cookie( $name );
                if ( ! $match ) {
                    $unknown[ $name ] = $url;
                }
                $cat_label = '';
                if ( $match ) {
                    $cat_label = 'negeren' === $match['category'] ? 'Genegeerd' : ( $labels[ $match['category'] ] ?? $match['category'] );
                }
                ?>
                <tr>
                    <td><code><?php echo esc_html( $name ); ?></code></td>
                    <td><?php echo $match ? esc_html( $match['service'] ) : '<span style="color:#d63638;font-weight:600;">Onbekend</span>'; ?></td>
                    <td><?php echo $match ? esc_html( $cat_label ) : '&mdash;'; ?></td>
                    <td><?php echo esc_html( wp_parse_url( $url, PHP_URL_PATH ) ?: '/' ); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ( $unknown ) : ?>
            <h3>Onbekende cookies classificeren</h3>
            <p class="description">Kies per cookie een categorie — dan wordt hij voortaan herkend én automatisch opgenomen in de cookie-tabel op de beleidspagina. Kies <em>Negeren</em> voor cookies die niets met bezoekers te maken hebben (bijv. iets van een test of een andere admin-tool). Let op: het blokkeren zelf gebeurt op script-niveau; hoort een cookie bij een tracker die nog niet herkend wordt, voeg het script dan ook toe via "Extra blokkeer-patronen" op het tabblad Instellingen.</p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'dpcc_save_register' ); ?>
                <input type="hidden" name="action" value="dpcc_save_register">
                <table class="widefat striped" style="max-width:760px;">
                    <thead><tr><th>Cookie</th><th>Categorie</th><th>Dienst / omschrijving (optioneel)</th></tr></thead>
                    <tbody>
                    <?php foreach ( $unknown as $name => $url ) : ?>
                        <tr>
                            <td><code><?php echo esc_html( $name ); ?></code></td>
                            <td>
                                <select name="dpcc_reg_cat[<?php echo esc_attr( $name ); ?>]">
                                    <option value="">— kies —</option>
                                    <?php foreach ( $labels as $key => $label ) : ?>
                                        <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                    <option value="negeren">Negeren (geen bezoekers-cookie)</option>
                                </select>
                            </td>
                            <td><input type="text" name="dpcc_reg_label[<?php echo esc_attr( $name ); ?>]" placeholder="bijv. naam van de dienst" class="regular-text"></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php submit_button( 'Classificatie opslaan', 'secondary', 'submit', true ); ?>
            </form>
        <?php endif; ?>
        <?php if ( ! empty( $browser['storage'] ) ) : ?>
            <details style="margin-top:12px;">
                <summary style="cursor:pointer;"><strong>Local/session storage-sleutels (<?php echo count( (array) $browser['storage'] ); ?>)</strong></summary>
                <p class="description">Opslag in de browser die geen cookie is maar wél onder de AVG/ePrivacy valt als er persoonsgegevens of identifiers in staan.</p>
                <ul style="columns:2;margin-top:8px;">
                    <?php foreach ( (array) $browser['storage'] as $key => $url ) : ?>
                        <li><code><?php echo esc_html( $key ); ?></code></li>
                    <?php endforeach; ?>
                </ul>
            </details>
        <?php endif; ?>
        <?php
    }

    private function render_log_tab() {
        $log       = DPCC_Consent_Log::instance();
        $enabled   = (bool) DPCC_Settings::val( 'log_consent' );
        $retention = (int) DPCC_Settings::val( 'log_retention_days' );
        $total     = $log->count();

        $search_cid = isset( $_GET['dpcc_cid'] ) ? sanitize_text_field( wp_unslash( $_GET['dpcc_cid'] ) ) : '';
        $search_ip  = isset( $_GET['dpcc_ip'] ) ? sanitize_text_field( wp_unslash( $_GET['dpcc_ip'] ) ) : '';
        ?>
        <p>Elke toestemming die een bezoeker geeft wordt hier vastgelegd als bewijs (AVG art. 7). Het IP wordt niet als zodanig opgeslagen, maar als onomkeerbare hash (pseudonimisering).</p>

        <?php if ( ! $enabled ) : ?>
            <div class="notice notice-warning inline"><p>Het consent-logboek staat <strong>uit</strong>. Zet het aan op het tabblad <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent' ) ); ?>">Instellingen</a>.</p></div>
        <?php endif; ?>

        <p>
            <strong>Totaal vastgelegd:</strong> <?php echo (int) $total; ?> &nbsp;|&nbsp;
            <strong>Bewaartermijn:</strong> <?php echo $retention > 0 ? (int) $retention . ' dagen' : 'onbeperkt'; ?>
        </p>

        <?php if ( $total > 0 ) : ?>

            <div style="display:flex;flex-wrap:wrap;gap:24px;align-items:flex-end;margin:1em 0 1.5em;">
                <form method="get" style="margin:0;">
                    <input type="hidden" name="page" value="dp-cookie-consent">
                    <input type="hidden" name="tab" value="log">
                    <label for="dpcc-search-cid"><strong>Zoek op consent-ID</strong></label><br>
                    <input type="text" id="dpcc-search-cid" name="dpcc_cid" value="<?php echo esc_attr( $search_cid ); ?>" placeholder="bv. a1b2c3d4 of volledig ID" size="34">
                    <?php submit_button( 'Zoeken', 'secondary', '', false ); ?>
                </form>

                <form method="get" style="margin:0;">
                    <input type="hidden" name="page" value="dp-cookie-consent">
                    <input type="hidden" name="tab" value="log">
                    <label for="dpcc-search-ip"><strong>Verifieer op IP-adres</strong></label><br>
                    <input type="text" id="dpcc-search-ip" name="dpcc_ip" value="<?php echo esc_attr( $search_ip ); ?>" placeholder="bv. 203.0.113.9" size="22">
                    <?php submit_button( 'Verifiëren', 'secondary', '', false ); ?>
                </form>
            </div>

            <?php
            // --- Zoekresultaat op consent-ID -----------------------------
            if ( '' !== $search_cid ) {
                $found = $log->find_by_consent_id( $search_cid );
                echo '<h2>Zoekresultaat consent-ID: <code>' . esc_html( $search_cid ) . '</code></h2>';
                if ( $found ) {
                    $this->render_log_table( $found, true );
                    echo '<p class="description">Vergelijk het volledige consent-ID hierboven met de <code>cid</code> in de cookie <code>dpcc_consent</code> op het apparaat van de bezoeker om de koppeling te bevestigen.</p>';
                } else {
                    echo '<p><em>Geen registraties gevonden voor dit consent-ID.</em></p>';
                }
                echo '<hr>';
            }

            // --- Verificatie op IP ---------------------------------------
            if ( '' !== $search_ip ) {
                $found = $log->find_by_ip( $search_ip );
                echo '<h2>Verificatie IP-adres: <code>' . esc_html( $search_ip ) . '</code></h2>';
                if ( null === $found ) {
                    echo '<div class="notice notice-error inline"><p>Dat is geen geldig IP-adres.</p></div>';
                } else {
                    $hash = DPCC_Consent_Log::hash_ip( $search_ip, (string) get_option( 'dpcc_scan_key' ) );
                    echo '<p class="description">Hash van dit IP met de sitesleutel: <code>' . esc_html( $hash ) . '</code></p>';
                    if ( $found ) {
                        echo '<p><strong>Match:</strong> dit IP-adres heeft ' . count( $found ) . ' keer een keuze vastgelegd.</p>';
                        $this->render_log_table( $found, true );
                    } else {
                        echo '<p><em>Geen registraties gevonden voor dit IP-adres.</em></p>';
                    }
                }
                echo '<hr>';
            }
            ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:1.5em;">
                <?php wp_nonce_field( 'dpcc_export_log' ); ?>
                <input type="hidden" name="action" value="dpcc_export_log">
                <?php submit_button( 'Exporteer alles als CSV', 'secondary', 'submit', false ); ?>
            </form>

            <h2>Laatste 50 registraties</h2>
            <?php $this->render_log_table( $log->get_recent( 50 ), false ); ?>
            <p class="description">Klik op een "Ref." om het volledige record en consent-ID te bekijken. De volledige gegevens (incl. IP-hash en user-agent) zitten in de CSV-export.</p>
        <?php else : ?>
            <p><em>Nog geen registraties. Zodra een bezoeker een keuze maakt in de banner verschijnt die hier.</em></p>
        <?php endif; ?>
        <?php
    }

    /**
     * Render een tabel met consent-records.
     *
     * @param array $rows    records uit het logboek
     * @param bool  $full_id toon het volledige consent-ID (i.p.v. klikbare Ref.)
     */
    private function render_log_table( $rows, $full_id = false ) {
        $labels        = DPCC_Services::categories();
        $action_labels = [ 'accept_all' => 'Alles geaccepteerd', 'reject_all' => 'Alles geweigerd', 'custom' => 'Aangepast' ];
        ?>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Tijdstip</th><th>Actie</th><th>Keuzes</th><th>Versie</th><th>Pagina</th><th><?php echo $full_id ? 'Consent-ID' : 'Ref.'; ?></th><th>Gebruiker</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $rows as $r ) :
                $cats   = json_decode( $r->categories, true );
                $cats   = is_array( $cats ) ? $cats : [];
                $chosen = [];
                foreach ( $cats as $key => $val ) {
                    $name     = isset( $labels[ $key ] ) ? $labels[ $key ] : $key;
                    $chosen[] = $name . ': ' . ( $val ? 'ja' : 'nee' );
                }
                $user = $r->user_id ? get_userdata( $r->user_id ) : null;
                ?>
                <tr>
                    <td><?php echo esc_html( get_date_from_gmt( $r->created_at, 'j-m-Y H:i' ) ); ?></td>
                    <td><?php echo esc_html( $action_labels[ $r->action ] ?? $r->action ); ?></td>
                    <td><?php echo esc_html( implode( ', ', $chosen ) ); ?></td>
                    <td><?php echo (int) $r->consent_version; ?></td>
                    <td><?php echo esc_html( wp_parse_url( $r->url, PHP_URL_PATH ) ?: '/' ); ?></td>
                    <td>
                        <?php if ( $full_id ) : ?>
                            <code><?php echo esc_html( $r->consent_id ); ?></code>
                        <?php else : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=dp-cookie-consent&tab=log&dpcc_cid=' . rawurlencode( $r->consent_id ) ) ); ?>"><code title="Volledig record bekijken"><?php echo esc_html( substr( $r->consent_id, 0, 8 ) ); ?></code></a>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $user ? esc_html( $user->user_login ) : '&mdash;'; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }
}
