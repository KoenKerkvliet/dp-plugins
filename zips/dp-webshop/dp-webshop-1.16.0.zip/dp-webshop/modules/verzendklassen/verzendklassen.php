<?php
/**
 * Module Name: Automatische verzendklasse
 * Description: Nieuwe producten krijgen vanzelf de juiste verzendklasse op basis van prijs en categorie, bijvoorbeeld "artikelen onder €50 → klein pakket". Alleen zolang er nog geen klasse gekozen is; wat de klant in FluentCart kiest blijft altijd staan. Werkt met de verzendklassen van FluentCart zelf.
 * Category: afrekenen
 * Vervalt zodra: FluentCart zelf regels heeft om nieuwe producten een verzendklasse te geven.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_VERZENDKLASSEN_VERSION', '1.0.0' );
define( 'DP_WVK_GEZET', 'dp_verzendklasse_gezet' ); // markering: dit product is afgehandeld

/** Regels: eerste die past wint. [ 'cat' => slug of '', 'max' => euro, 'klasse' => id ] */
function dp_wvk_regels() {
	$s = dp_webshop_instellingen( 'dp_webshop_verzendklassen', [ 'regels' => [] ] );
	return array_values( array_filter( (array) $s['regels'], fn( $r ) => ! empty( $r['klasse'] ) && (float) ( $r['max'] ?? 0 ) > 0 ) );
}

/** Welke klasse hoort volgens de regels bij dit product? 0 = geen (gratis/standaard). */
function dp_wvk_klasse_voor( $post_id, $euro ) {
	foreach ( dp_wvk_regels() as $r ) {
		if ( ! empty( $r['cat'] ) && ! has_term( $r['cat'], 'product-categories', $post_id ) ) {
			continue;
		}
		if ( $euro < (float) $r['max'] ) {
			return (int) $r['klasse'];
		}
	}
	return 0;
}

/**
 * Eén product afhandelen. Alleen als er nog geen klasse staat en er een prijs is; daarna
 * nooit meer (markering), zodat een latere keuze in FluentCart altijd blijft staan.
 *
 * @param bool $forceer ook producten met markering (niet gebruikt door de haken).
 */
function dp_wvk_toepassen( $post_id, $forceer = false ) {
	global $wpdb;
	$post_id = absint( $post_id );
	if ( ! $post_id || get_post_type( $post_id ) !== 'fluent-products' ) {
		return false;
	}
	if ( ! $forceer && get_post_meta( $post_id, DP_WVK_GEZET, true ) ) {
		return false;
	}
	if ( ! dp_wvk_regels() ) {
		return false; // nog geen regels: niets markeren, anders gelden latere regels niet
	}
	$tabel = $wpdb->prefix . 'fct_product_details';
	$rij   = $wpdb->get_row( $wpdb->prepare( "SELECT min_price, other_info FROM $tabel WHERE post_id = %d", $post_id ) );
	if ( ! $rij || (int) $rij->min_price <= 0 ) {
		return false; // nog geen prijs: later nog eens
	}
	$info     = json_decode( (string) $rij->other_info, true ) ?: [];
	$gewijzigd = false;
	if ( empty( $info['shipping_class'] ) ) {
		$klasse = dp_wvk_klasse_voor( $post_id, (int) $rij->min_price / 100 );
		if ( $klasse ) {
			$info['shipping_class'] = (string) $klasse;
			$wpdb->update( $tabel, [ 'other_info' => wp_json_encode( $info ) ], [ 'post_id' => $post_id ] );
			$gewijzigd = true;
		}
	}
	update_post_meta( $post_id, DP_WVK_GEZET, 1 );
	return $gewijzigd;
}

function dp_wvk_plan( $post_id ) {
	static $wachtrij = null;
	$post_id = absint( $post_id );
	if ( ! $post_id ) {
		return;
	}
	if ( null === $wachtrij ) {
		$wachtrij = [];
		add_action( 'shutdown', function () use ( &$wachtrij ) {
			foreach ( array_keys( $wachtrij ) as $id ) {
				dp_wvk_toepassen( $id );
			}
		} );
	}
	$wachtrij[ $post_id ] = true;
}

add_action( 'fluent_cart/product_updated', function ( $args ) {
	$product = $args['product'] ?? null;
	dp_wvk_plan( is_object( $product ) ? ( $product->ID ?? 0 ) : ( $product['ID'] ?? 0 ) );
} );
add_action( 'fluent_cart/product/variants_updated', function ( $args ) {
	dp_wvk_plan( $args['post_id'] ?? 0 );
} );
add_action( 'save_post_fluent-products', 'dp_wvk_plan', 99 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_verzendklassen', 'dp_webshop_verzendklassen', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$regels = [];
			foreach ( (array) ( $in['regels'] ?? [] ) as $r ) {
				$max    = (float) str_replace( ',', '.', (string) ( $r['max'] ?? '' ) );
				$klasse = absint( $r['klasse'] ?? 0 );
				if ( $max > 0 && $klasse ) {
					$regels[] = [ 'cat' => sanitize_title( (string) ( $r['cat'] ?? '' ) ), 'max' => $max, 'klasse' => $klasse ];
				}
			}
			return [ 'regels' => $regels ];
		},
	] );
	dp_webshop_register_module_settings( 'verzendklassen', 'dp_wvk_render', [
		'title'       => 'Automatische verzendklasse',
		'description' => 'Regels voor nieuwe producten.',
	] );
} );

/* Knoppen: bestaande producten afhandelen of juist overslaan. */
add_action( 'admin_post_dp_wvk_bulk', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dp_wvk_bulk' ) ) {
		wp_die( 'Geen toegang.' );
	}
	$wat = sanitize_key( $_POST['wat'] ?? '' );
	$ids = get_posts( [ 'post_type' => 'fluent-products', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_query' => [ [ 'key' => DP_WVK_GEZET, 'compare' => 'NOT EXISTS' ] ] ] );
	$n   = 0;
	foreach ( $ids as $id ) {
		if ( $wat === 'toepassen' ) {
			$n += dp_wvk_toepassen( $id ) ? 1 : 0;
		} else {
			update_post_meta( $id, DP_WVK_GEZET, 1 );
			$n++;
		}
	}
	wp_safe_redirect( add_query_arg( [ 'dp_wvk' => $wat, 'dp_wvk_n' => $n ], admin_url( 'admin.php?page=dp-webshop#settings-verzendklassen' ) ) );
	exit;
} );

function dp_wvk_render() {
	$regels  = dp_wvk_regels();
	$klassen = class_exists( '\FluentCart\App\Models\ShippingClass' ) ? \FluentCart\App\Models\ShippingClass::query()->get() : [];
	$cats    = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false ] );
	$open    = (int) ( new WP_Query( [ 'post_type' => 'fluent-products', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_query' => [ [ 'key' => DP_WVK_GEZET, 'compare' => 'NOT EXISTS' ] ] ] ) )->found_posts;
	$melding = sanitize_key( $_GET['dp_wvk'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
	$aantal  = (int) ( $_GET['dp_wvk_n'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
	$regels[] = [ 'cat' => '', 'max' => '', 'klasse' => 0 ]; // lege regel om toe te voegen
	?>
	<div class="dpw-kaart">
		<?php if ( $melding === 'toepassen' ) : ?>
			<p class="dpw-melding"><?php echo esc_html( sprintf( '%d producten kregen een verzendklasse.', $aantal ) ); ?></p>
		<?php elseif ( $melding === 'overslaan' ) : ?>
			<p class="dpw-melding"><?php echo esc_html( sprintf( '%d bestaande producten gemarkeerd; de regels gelden nu alleen voor nieuwe producten.', $aantal ) ); ?></p>
		<?php endif; ?>

		<?php if ( ! $klassen || ! count( $klassen ) ) : ?>
			<p class="dpw-melding">Er zijn nog geen verzendklassen. Maak ze eerst aan in FluentCart → Instellingen → Verzending.</p>
		<?php else : ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'dp_webshop_verzendklassen' ); ?>
				<table class="dpw-tabel">
					<thead><tr><th>Categorie</th><th>Prijs onder (€)</th><th>Verzendklasse</th></tr></thead>
					<tbody>
					<?php foreach ( $regels as $i => $r ) : ?>
						<tr>
							<td>
								<select name="dp_webshop_verzendklassen[regels][<?php echo (int) $i; ?>][cat]">
									<option value="">Alle categorieën</option>
									<?php foreach ( is_wp_error( $cats ) ? [] : $cats as $c ) : ?>
										<option value="<?php echo esc_attr( $c->slug ); ?>" <?php selected( $r['cat'], $c->slug ); ?>><?php echo esc_html( $c->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td><input type="text" inputmode="decimal" style="width:100px;" name="dp_webshop_verzendklassen[regels][<?php echo (int) $i; ?>][max]" value="<?php echo esc_attr( $r['max'] === '' ? '' : str_replace( '.', ',', (string) $r['max'] ) ); ?>"></td>
							<td>
								<select name="dp_webshop_verzendklassen[regels][<?php echo (int) $i; ?>][klasse]">
									<option value="0">(regel niet gebruiken)</option>
									<?php foreach ( $klassen as $k ) : ?>
										<option value="<?php echo (int) $k->id; ?>" <?php selected( (int) $r['klasse'], (int) $k->id ); ?>><?php echo esc_html( $k->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="dpw-hint" style="margin-bottom:14px;">De eerste regel die past wint. Zet de specifiekste regels (met categorie) bovenaan. Een product dat bij geen regel past, krijgt geen klasse: verzending volgens de verzendmethode zelf. Na opslaan verschijnt er weer een lege regel.</p>
				<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
			</form>
		<?php endif; ?>

		<div class="dpw-uitleg">
			<p><strong><?php echo esc_html( number_format_i18n( $open ) ); ?></strong> producten zijn nog niet door deze module bekeken. Kies wat daarmee moet:</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex; gap:10px; flex-wrap:wrap;">
				<input type="hidden" name="action" value="dp_wvk_bulk">
				<?php wp_nonce_field( 'dp_wvk_bulk' ); ?>
				<button type="submit" name="wat" value="toepassen" class="dpw-knop dpw-knop--licht">Regels toepassen op producten zonder klasse</button>
				<button type="submit" name="wat" value="overslaan" class="dpw-knop dpw-knop--licht">Bestaande producten overslaan</button>
			</form>
			<p class="dpw-hint">Overslaan is de veilige keuze na een import: dan houden bestaande producten precies de klasse die ze nu hebben.</p>
		</div>
	</div>
	<?php
}
