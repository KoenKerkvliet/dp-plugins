<?php
/**
 * Module Name: Winkelsnippets
 * Description: Eigen PHP-, CSS- en JS-snippets voor deze winkel, opgeslagen in de database: wat alleen voor deze ene site geldt en geen algemene module is (bijvoorbeeld eigen dynamic tags of landingspagina's). Zelfde werking als Code Snippets in DP Toolbox; ?dp_safe_mode=1 zet ze allemaal tijdelijk uit.
 * Category: other
 * Version: 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DP_WEBSHOP_SNIPPETS_VERSION', '1.2.0' );

/* ====================================================================== */
/*  DB-BASED SNIPPETS                                                      */
/* ====================================================================== */

/**
 * Safe-mode: bypass alle snippet-execution wanneer ?dp_safe_mode=1 in URL.
 * Geen cap-check (pluggable.php is bij plugins_loaded nog niet geladen);
 * de URL-flag uitschakelen van snippets is niet destructief, dus elk publiek
 * gebruik is acceptabel.
 */
function dp_webshop_snippets_safe_mode() {
    return ! empty( $_GET['dp_safe_mode'] );
}

/**
 * Haal alle DB-snippets op (option array).
 */
function dp_webshop_db_snippets_get_all() {
    return (array) get_option( 'dp_webshop_snippets', [] );
}

/**
 * Update één DB-snippet (merge in option array).
 */
function dp_webshop_db_snippet_update( $id, array $patch ) {
    $all = dp_webshop_db_snippets_get_all();
    if ( ! isset( $all[ $id ] ) ) return false;
    $all[ $id ] = array_merge( $all[ $id ], $patch );
    update_option( 'dp_webshop_snippets', $all, false );
    return true;
}

/**
 * Markeer een snippet als "broken" en deactiveer hem.
 */
function dp_webshop_db_snippet_mark_error( $id, $message ) {
    dp_webshop_db_snippet_update( $id, [
        'active'    => false,
        'has_error' => true,
        'error_msg' => substr( (string) $message, 0, 500 ),
        'error_at'  => current_time( 'mysql' ),
    ] );
}

/**
 * Check of een snippet op de huidige site/hostname mag draaien.
 */
function dp_webshop_db_snippet_site_match( $sites ) {
    $sites = trim( (string) $sites );
    if ( $sites === '' || $sites === '*' ) return true;
    $current = wp_parse_url( home_url(), PHP_URL_HOST );
    $allowed = array_filter( array_map( 'trim', explode( ',', $sites ) ) );
    return in_array( $current, $allowed, true );
}

/**
 * Voer een PHP-snippet veilig uit. Vangt parse-errors en runtime-throwables;
 * fatale errors worden via shutdown-handler opgevangen en de snippet wordt
 * automatisch gedeactiveerd.
 */
function dp_webshop_db_snippet_execute_php( $snippet ) {
    if ( ! empty( $snippet['has_error'] ) ) return;

    $code = (string) $snippet['code'];
    // Strip optionele <?php prefix, want eval wil dat niet.
    $code = preg_replace( '/^\s*<\?(php)?\s*/i', '', $code );

    $GLOBALS['dp_webshop_current_snippet_id'] = $snippet['id'];

    try {
        // phpcs:ignore Squiz.PHP.Eval.Discouraged
        eval( $code );
    } catch ( ParseError $e ) {
        dp_webshop_db_snippet_mark_error( $snippet['id'], 'Parse: ' . $e->getMessage() . ' (regel ' . $e->getLine() . ')' );
    } catch ( Throwable $e ) {
        dp_webshop_db_snippet_mark_error( $snippet['id'], get_class( $e ) . ': ' . $e->getMessage() );
    }

    unset( $GLOBALS['dp_webshop_current_snippet_id'] );
}

/**
 * Shutdown-handler: markeert de snippet als broken als de fatal pal tijdens
 * eval optrad. Voor latere fatals (in geregistreerde hooks) kunnen we de
 * specifieke snippet niet meer attribueren — dan rekent de gebruiker zelf
 * via ?dp_safe_mode=1 + de admin-pagina af.
 */
function dp_webshop_db_snippet_shutdown_handler() {
    if ( empty( $GLOBALS['dp_webshop_current_snippet_id'] ) ) return;
    $err = error_get_last();
    if ( ! $err ) return;
    $fatal_types = [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR ];
    if ( ! in_array( $err['type'], $fatal_types, true ) ) return;
    dp_webshop_db_snippet_mark_error( $GLOBALS['dp_webshop_current_snippet_id'], 'Fatal: ' . $err['message'] );
}
register_shutdown_function( 'dp_webshop_db_snippet_shutdown_handler' );

/**
 * Hoofdrunner — wordt aangeroepen op `plugins_loaded`.
 * Sorteert snippets op priority en dispatcht naar de juiste type-runner.
 */
function dp_webshop_db_snippets_run() {
    if ( dp_webshop_snippets_safe_mode() ) return;

    $snippets = dp_webshop_db_snippets_get_all();
    if ( empty( $snippets ) ) return;

    // Sort by priority asc (10 = default; lower = earlier)
    uasort( $snippets, function ( $a, $b ) {
        return ( (int) ( $a['priority'] ?? 10 ) ) <=> ( (int) ( $b['priority'] ?? 10 ) );
    } );

    foreach ( $snippets as $s ) {
        if ( empty( $s['active'] ) || ! empty( $s['has_error'] ) ) continue;
        if ( ! dp_webshop_db_snippet_site_match( $s['sites'] ?? '' ) ) continue;

        $type  = $s['type']  ?? 'php';
        $scope = $s['scope'] ?? 'everywhere';

        // Scope-check
        if ( $type === 'php' ) {
            if ( $scope === 'admin'    && ! is_admin() ) continue;
            if ( $scope === 'frontend' && is_admin() )   continue;
            dp_webshop_db_snippet_execute_php( $s );
        }
        elseif ( $type === 'css' ) {
            dp_webshop_db_snippet_register_css( $s );
        }
        elseif ( $type === 'js' ) {
            dp_webshop_db_snippet_register_js( $s );
        }
    }
}
dp_webshop_db_snippets_run(); // de moduleloader draait al op plugins_loaded 20

/**
 * Registreer een CSS-snippet voor inline-output.
 */
function dp_webshop_db_snippet_register_css( $snippet ) {
    $scope    = $snippet['scope'] ?? 'frontend';
    $is_admin = ( $scope === 'admin' );
    $hook     = $is_admin ? 'admin_head' : 'wp_head';

    if ( $is_admin && ! is_admin() ) return;
    if ( ! $is_admin && is_admin() ) return;

    add_action( $hook, function () use ( $snippet ) {
        $code = (string) $snippet['code'];
        // Strip evt. <style>-tags die de gebruiker per ongeluk plakt
        $code = preg_replace( '#</?style[^>]*>#i', '', $code );
        printf(
            "<style id=\"dp-webshop-snippet-%s\">\n%s\n</style>\n",
            esc_attr( $snippet['id'] ),
            $code
        );
    }, (int) ( $snippet['priority'] ?? 10 ) );
}

/**
 * Registreer een JS-snippet voor inline-output.
 */
function dp_webshop_db_snippet_register_js( $snippet ) {
    $scope = $snippet['scope'] ?? 'frontend_footer';

    if ( $scope === 'admin' ) {
        if ( ! is_admin() ) return;
        $hook = 'admin_footer';
    } else {
        if ( is_admin() ) return;
        $hook = ( $scope === 'frontend_head' ) ? 'wp_head' : 'wp_footer';
    }

    add_action( $hook, function () use ( $snippet ) {
        $code = (string) $snippet['code'];
        // Strip evt. <script>-tags
        $code = preg_replace( '#</?script[^>]*>#i', '', $code );
        printf(
            "<script id=\"dp-webshop-snippet-%s\">\n%s\n</script>\n",
            esc_attr( $snippet['id'] ),
            $code
        );
    }, (int) ( $snippet['priority'] ?? 10 ) );
}

/* ====================================================================== */
/*  AJAX handlers                                                          */
/* ====================================================================== */

add_action( 'wp_ajax_dp_webshop_snippet_save', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Geen toestemming.' );
    check_ajax_referer( 'dp_webshop_snippets', 'nonce' );

    $id          = sanitize_text_field( $_POST['id']          ?? '' );
    $title       = sanitize_text_field( $_POST['title']       ?? '' );
    $description = sanitize_textarea_field( $_POST['description'] ?? '' );
    $vervalt     = sanitize_text_field( wp_unslash( $_POST['vervalt'] ?? '' ) );
    $type        = in_array( $_POST['type'] ?? 'php', [ 'php', 'js', 'css' ], true ) ? $_POST['type'] : 'php';
    // Code: NIET sanitizen — dat zou de syntax breken. Wel slashen ongedaan maken.
    $code        = wp_unslash( $_POST['code'] ?? '' );
    $priority    = max( 1, min( 999, (int) ( $_POST['priority'] ?? 10 ) ) );
    $sites       = sanitize_text_field( $_POST['sites']  ?? '' );
    $active      = ! empty( $_POST['active'] );

    // Geldige scope per type
    $scope_options = [
        'php' => [ 'everywhere', 'admin', 'frontend' ],
        'js'  => [ 'frontend_head', 'frontend_footer', 'admin' ],
        'css' => [ 'frontend', 'admin' ],
    ];
    $scope_default = [ 'php' => 'everywhere', 'js' => 'frontend_footer', 'css' => 'frontend' ];
    $scope = sanitize_text_field( $_POST['scope'] ?? '' );
    if ( ! in_array( $scope, $scope_options[ $type ], true ) ) {
        $scope = $scope_default[ $type ];
    }

    if ( $title === '' ) wp_send_json_error( 'Titel is verplicht.' );
    if ( trim( $code ) === '' ) wp_send_json_error( 'Code mag niet leeg zijn.' );

    // PHP-syntax check vóór opslaan, zodat we geen onbruikbare snippet activeren
    if ( $type === 'php' && $active ) {
        $check = dp_webshop_php_syntax_check( $code );
        if ( $check !== true ) {
            wp_send_json_error( 'PHP-syntaxfout: ' . $check );
        }
    }

    $all = dp_webshop_db_snippets_get_all();
    $now = current_time( 'mysql' );

    if ( $id !== '' && isset( $all[ $id ] ) ) {
        // Bewerken
        $all[ $id ] = array_merge( $all[ $id ], [
            'title'       => $title,
            'description' => $description,
            'vervalt'     => $vervalt,
            'type'        => $type,
            'code'        => $code,
            'scope'       => $scope,
            'priority'    => $priority,
            'sites'       => $sites,
            'active'      => $active,
            'updated'     => $now,
            // reset error-state on save
            'has_error'   => false,
            'error_msg'   => '',
        ] );
    } else {
        // Nieuw
        $id = 's_' . uniqid();
        $all[ $id ] = [
            'id'          => $id,
            'title'       => $title,
            'description' => $description,
            'vervalt'     => $vervalt,
            'type'        => $type,
            'code'        => $code,
            'scope'       => $scope,
            'priority'    => $priority,
            'sites'       => $sites,
            'active'      => $active,
            'created'     => $now,
            'updated'     => $now,
            'has_error'   => false,
            'error_msg'   => '',
        ];
    }

    update_option( 'dp_webshop_snippets', $all, false );
    wp_send_json_success( [ 'id' => $id, 'message' => 'Snippet opgeslagen.' ] );
} );

add_action( 'wp_ajax_dp_webshop_snippet_delete', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Geen toestemming.' );
    check_ajax_referer( 'dp_webshop_snippets', 'nonce' );

    $id  = sanitize_text_field( $_POST['id'] ?? '' );
    $all = dp_webshop_db_snippets_get_all();
    if ( ! isset( $all[ $id ] ) ) wp_send_json_error( 'Snippet niet gevonden.' );

    unset( $all[ $id ] );
    update_option( 'dp_webshop_snippets', $all, false );
    wp_send_json_success();
} );

add_action( 'wp_ajax_dp_webshop_snippet_toggle', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Geen toestemming.' );
    check_ajax_referer( 'dp_webshop_snippets', 'nonce' );

    $id  = sanitize_text_field( $_POST['id'] ?? '' );
    $all = dp_webshop_db_snippets_get_all();
    if ( ! isset( $all[ $id ] ) ) wp_send_json_error( 'Snippet niet gevonden.' );

    $next_state = empty( $all[ $id ]['active'] );

    // Bij heractiveren: PHP-syntax opnieuw checken
    if ( $next_state && ( $all[ $id ]['type'] ?? 'php' ) === 'php' ) {
        $check = dp_webshop_php_syntax_check( $all[ $id ]['code'] ?? '' );
        if ( $check !== true ) {
            wp_send_json_error( 'PHP-syntaxfout: ' . $check );
        }
    }

    $all[ $id ]['active']    = $next_state;
    $all[ $id ]['has_error'] = false;
    $all[ $id ]['error_msg'] = '';
    update_option( 'dp_webshop_snippets', $all, false );
    wp_send_json_success( [ 'active' => $next_state ] );
} );

/* ====================================================================== */
/*  Overnemen uit DP Toolbox                                               */
/* ====================================================================== */

/**
 * Verplaats DB-snippets van DP Toolbox naar hier, met id, status en al. Eerst hier
 * opslaan, dan daar weghalen: gaat er onderweg iets mis, dan staat de snippet in het
 * ergste geval dubbel (en zet de foutafhandeling er één uit), maar raakt hij nooit kwijt.
 * Een snippet die al bestaat met dezelfde id wordt niet overschreven.
 *
 * @return int aantal verplaatste snippets
 */
function dp_webshop_snippets_overnemen( array $ids ) {
    $toolbox = (array) get_option( 'dp_toolbox_snippets', [] );
    $eigen   = dp_webshop_db_snippets_get_all();
    $weg     = [];
    foreach ( $ids as $id ) {
        $id = sanitize_text_field( (string) $id );
        if ( ! isset( $toolbox[ $id ] ) || isset( $eigen[ $id ] ) ) {
            continue;
        }
        $eigen[ $id ] = $toolbox[ $id ];
        $weg[]        = $id;
    }
    if ( ! $weg ) {
        return 0;
    }
    update_option( 'dp_webshop_snippets', $eigen, false );
    foreach ( $weg as $id ) {
        unset( $toolbox[ $id ] );
    }
    update_option( 'dp_toolbox_snippets', $toolbox, false );
    return count( $weg );
}

add_action( 'admin_post_dp_webshop_snippets_overnemen', function () {
    if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dp_webshop_snippets_overnemen' ) ) {
        wp_die( 'Geen toegang.' );
    }
    $n = dp_webshop_snippets_overnemen( (array) wp_unslash( $_POST['ids'] ?? [] ) );
    wp_safe_redirect( add_query_arg( 'dp_sn_over', $n, admin_url( 'admin.php?page=dp-webshop-snippets' ) ) );
    exit;
} );

/** Blok onder de lijst: snippets die nog in DP Toolbox staan. */
function dp_webshop_snippets_overname_blok() {
    $toolbox = (array) get_option( 'dp_toolbox_snippets', [] );
    $n       = isset( $_GET['dp_sn_over'] ) ? (int) $_GET['dp_sn_over'] : null; // phpcs:ignore WordPress.Security.NonceVerification
    if ( null !== $n ) {
        printf( '<div class="dpw-melding" style="margin-top:16px;">%s</div>', esc_html( sprintf( '%d snippet(s) overgenomen uit DP Toolbox.', $n ) ) );
    }
    if ( ! $toolbox ) {
        return;
    }
    ?>
    <div class="dp-sn-section-h">Nog in DP Toolbox <span style="font-weight:400;color:#888;">— vink de winkelsnippets aan en neem ze over; ze verdwijnen dan uit DP Toolbox</span></div>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:12px 16px;">
        <input type="hidden" name="action" value="dp_webshop_snippets_overnemen">
        <?php wp_nonce_field( 'dp_webshop_snippets_overnemen' ); ?>
        <?php foreach ( $toolbox as $id => $s ) :
            $winkel = (bool) preg_match( '/fluent|fct[_-]|winkel|product|kassa|webshop/i', ( $s['title'] ?? '' ) . ' ' . ( $s['code'] ?? '' ) );
        ?>
            <label style="display:block;padding:4px 0;">
                <input type="checkbox" name="ids[]" value="<?php echo esc_attr( $id ); ?>">
                <strong><?php echo esc_html( $s['title'] ?? $id ); ?></strong>
                <span style="color:#888;"><?php echo esc_html( strtoupper( $s['type'] ?? 'php' ) . ( empty( $s['active'] ) ? ' · uit' : '' ) ); ?></span>
                <?php if ( $winkel ) : ?><span style="color:#281E5D;font-size:11px;"> · lijkt winkelcode</span><?php endif; ?>
            </label>
        <?php endforeach; ?>
        <p style="margin:10px 0 0;"><button type="submit" class="dp-sn-btn">Aangevinkte overnemen</button></p>
    </form>
    <?php
}

/* ====================================================================== */
/*  PHP syntax-check helper                                                */
/* ====================================================================== */

/**
 * Lichte PHP-syntax-check via tokens. Vangt onbalansed { }, missing
 * semicolons aan einde van block, en evident parse-onzin. Echte parse-check
 * gebeurt sowieso in de eval; dit voorkomt vooral evidente fouten vooraf.
 *
 * Returns true bij geldige syntax of een foutbericht.
 */
function dp_webshop_php_syntax_check( $code ) {
    $code = (string) $code;
    if ( trim( $code ) === '' ) return 'Lege code.';

    $code = preg_replace( '/^\s*<\?(php)?\s*/i', '', $code );

    // Probeer compile via eval-with-return-false in een sandbox.
    // De truc: voeg "return;" toe en eval — dat compiled de code zonder side-effects
    // (althans niet bij top-level statements; maar functions/classes worden wel
    // gedeclareerd). Beter: gebruik token_get_all en check op T_OPEN_TAG / parsefout.
    $tokens = @token_get_all( '<?php ' . $code );
    if ( ! is_array( $tokens ) || count( $tokens ) === 0 ) {
        return 'Kan code niet tokeniseren.';
    }

    // Brace-/bracket-/paren-balans check
    $stack = [];
    $pairs = [ '{' => '}', '[' => ']', '(' => ')' ];
    foreach ( $tokens as $tok ) {
        $char = is_array( $tok ) ? null : $tok;
        if ( $char && isset( $pairs[ $char ] ) ) {
            $stack[] = $pairs[ $char ];
        } elseif ( $char && in_array( $char, $pairs, true ) ) {
            $expected = array_pop( $stack );
            if ( $expected !== $char ) {
                return "Onbalans: '{$char}' op verkeerde plek.";
            }
        }
    }
    if ( ! empty( $stack ) ) {
        return "Niet-gesloten haakje: '" . implode( ',', $stack ) . "' verwacht.";
    }

    return true;
}

/* ====================================================================== */
/*  Admin-page                                                             */
/* ====================================================================== */

if ( is_admin() ) {
    require_once __DIR__ . '/admin-page.php';
}
