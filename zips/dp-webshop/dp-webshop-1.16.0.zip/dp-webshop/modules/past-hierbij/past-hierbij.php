<?php
/**
 * Module Name: Past hierbij
 * Description: Accessoires en extra's handmatig aan een product koppelen, en ze op de productpagina tonen. FluentCart toont gerelateerde producten alleen op categorie; hier kies je zelf. Invullen op het productgegevens-scherm; tonen met een Bricks-loop die de klasse uit de instellingen krijgt, plus de tag {dp_past_bij_aantal} om de sectie te verbergen als er niets gekoppeld is.
 * Category: catalogus
 * Vervalt zodra: FluentCart zelf handmatig gekoppelde "past hierbij"-producten (upsells) op de productpagina heeft.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_PASTBIJ_VERSION', '1.0.0' );

function dp_wph_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_past_bij', [
		'meta'    => 'dp_past_bij',
		'metabox' => 1,
		'klasse'  => 'dp-pastbij',
		'aantal'  => 12,
	] );
}

function dp_wph_meta() {
	$m = sanitize_key( (string) dp_wph_instellingen()['meta'] );
	return $m !== '' ? $m : 'dp_past_bij';
}

/** Gekoppelde product-ID's van een product (bestaande, gepubliceerde producten). */
function dp_wph_ids( $product_id ) {
	$ids = array_filter( array_map( 'absint', (array) get_post_meta( $product_id, dp_wph_meta(), true ) ) );
	return array_values( array_filter( $ids, fn( $id ) => get_post_status( $id ) === 'publish' ) );
}

/* ------------------------------------------------------------------ */
/*  Invoer: metabox op het productgegevens-scherm                       */
/* ------------------------------------------------------------------ */

add_action( 'add_meta_boxes_fluent-products', function () {
	if ( empty( dp_wph_instellingen()['metabox'] ) ) {
		return;
	}
	add_meta_box( 'dp-past-bij', 'Past hierbij', 'dp_wph_metabox', 'fluent-products', 'normal', 'default' );
} );

function dp_wph_metabox( $post ) {
	$gekozen   = array_map( 'intval', (array) get_post_meta( $post->ID, dp_wph_meta(), true ) );
	$producten = get_posts( [ 'post_type' => 'fluent-products', 'post_status' => [ 'publish', 'draft' ], 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'exclude' => [ $post->ID ] ] );
	usort( $producten, fn( $a, $b ) => (int) in_array( $b->ID, $gekozen, true ) - (int) in_array( $a->ID, $gekozen, true ) );
	wp_nonce_field( 'dp_wph_opslaan', 'dp_wph_nonce' );
	?>
	<p style="margin-top:0;">Kies de accessoires en extra's die op de productpagina onder "Past hierbij" staan. Gekozen producten staan bovenaan.</p>
	<input type="search" id="dp-wph-zoek" placeholder="Zoek een product…" style="width:100%; margin-bottom:8px;">
	<input type="hidden" name="dp_wph_ids[]" value="">
	<div id="dp-wph-lijst" style="max-height:280px; overflow:auto; border:1px solid #dcdcde; border-radius:4px; padding:6px 10px;">
		<?php foreach ( $producten as $p ) : ?>
			<label style="display:block; padding:3px 0;" data-titel="<?php echo esc_attr( mb_strtolower( $p->post_title ) ); ?>">
				<input type="checkbox" name="dp_wph_ids[]" value="<?php echo (int) $p->ID; ?>" <?php checked( in_array( $p->ID, $gekozen, true ) ); ?>>
				<?php echo esc_html( $p->post_title ); ?><?php echo $p->post_status !== 'publish' ? ' <em style="color:#999;">(concept)</em>' : ''; ?>
			</label>
		<?php endforeach; ?>
	</div>
	<script>
	(function () {
		var zoek = document.getElementById('dp-wph-zoek');
		zoek.addEventListener('input', function () {
			var t = this.value.trim().toLowerCase();
			document.querySelectorAll('#dp-wph-lijst label').forEach(function (l) {
				l.style.display = !t || l.dataset.titel.indexOf(t) !== -1 ? 'block' : 'none';
			});
		});
		zoek.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
	})();
	</script>
	<?php
}

add_action( 'save_post_fluent-products', function ( $post_id ) {
	if ( ! isset( $_POST['dp_wph_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['dp_wph_nonce'] ), 'dp_wph_opslaan' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$ids = array_values( array_filter( array_map( 'absint', (array) ( $_POST['dp_wph_ids'] ?? [] ) ) ) );
	if ( $ids ) {
		// Als tekst, zoals een JetEngine-postsveld het ook opslaat: dan kunnen beide hetzelfde veld delen.
		update_post_meta( $post_id, dp_wph_meta(), array_map( 'strval', $ids ) );
	} else {
		delete_post_meta( $post_id, dp_wph_meta() );
	}
} );

/* ------------------------------------------------------------------ */
/*  Tonen in Bricks                                                     */
/* ------------------------------------------------------------------ */

/**
 * Heeft dit Bricks-element de ingestelde klasse? Globale klassen staan in het element
 * onder hun ID (vaak een willekeurige code), dus die vertalen we naar de naam; een
 * gewone CSS-klasse in het veld "CSS classes" telt ook.
 */
function dp_wph_heeft_klasse( $settings ) {
	$klasse = sanitize_html_class( (string) dp_wph_instellingen()['klasse'] );
	if ( $klasse === '' ) {
		return false;
	}
	$ids = (array) ( $settings['_cssGlobalClasses'] ?? [] );
	if ( in_array( $klasse, $ids, true ) ) {
		return true;
	}
	if ( $ids ) {
		static $namen = null;
		if ( null === $namen ) {
			$namen = [];
			foreach ( (array) get_option( 'bricks_global_classes', [] ) as $g ) {
				if ( isset( $g['id'], $g['name'] ) ) {
					$namen[ $g['id'] ] = $g['name'];
				}
			}
		}
		foreach ( $ids as $id ) {
			if ( ( $namen[ $id ] ?? '' ) === $klasse ) {
				return true;
			}
		}
	}
	return in_array( $klasse, preg_split( '/\s+/', (string) ( $settings['_cssClasses'] ?? '' ) ), true );
}

/** Het product waar de loop op staat (ook in de Bricks-editor). */
function dp_wph_huidig_product() {
	if ( is_singular( 'fluent-products' ) ) {
		return get_queried_object_id();
	}
	if ( function_exists( 'bricks_is_builder_call' ) && bricks_is_builder_call() ) {
		return (int) ( $_REQUEST['postId'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	return (int) get_the_ID();
}

add_filter( 'bricks/posts/query_vars', function ( $query_vars, $settings, $element_id, $element_name = null ) {
	if ( ! dp_wph_heeft_klasse( $settings ) ) {
		return $query_vars;
	}
	$product = dp_wph_huidig_product();
	$ids     = $product ? dp_wph_ids( $product ) : [];

	$query_vars['post_type']      = 'fluent-products';
	$query_vars['post__in']       = $ids ?: [ 0 ];
	$query_vars['orderby']        = 'post__in';
	$query_vars['posts_per_page'] = max( 1, (int) dp_wph_instellingen()['aantal'] );
	unset( $query_vars['tax_query'], $query_vars['meta_query'] );
	return $query_vars;
}, 10, 4 );

/* {dp_past_bij_aantal}: aantal gekoppelde producten, leeg bij nul (voor een sectievoorwaarde). */
add_filter( 'bricks/dynamic_tags_list', function ( $tags ) {
	$tags[] = [ 'name' => '{dp_past_bij_aantal}', 'label' => 'Past hierbij: aantal', 'group' => 'DP Webshop' ];
	return $tags;
} );
add_filter( 'bricks/dynamic_data/render_tag', function ( $tag, $post, $context = 'text' ) {
	if ( ! is_string( $tag ) || trim( $tag, '{}' ) !== 'dp_past_bij_aantal' ) {
		return $tag;
	}
	$id = is_object( $post ) ? $post->ID : absint( $post );
	$n  = $id ? count( dp_wph_ids( $id ) ) : 0;
	return $n ? (string) $n : '';
}, 10, 3 );
add_filter( 'bricks/dynamic_data/render_content', function ( $content, $post, $context = 'text' ) {
	if ( ! is_string( $content ) || strpos( $content, '{dp_past_bij_aantal}' ) === false ) {
		return $content;
	}
	$id = is_object( $post ) ? $post->ID : absint( $post );
	$n  = $id ? count( dp_wph_ids( $id ) ) : 0;
	return str_replace( '{dp_past_bij_aantal}', $n ? (string) $n : '', $content );
}, 10, 3 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_past_bij', 'dp_webshop_past_bij', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : [];
			return [
				'meta'    => sanitize_key( (string) ( $in['meta'] ?? 'dp_past_bij' ) ) ?: 'dp_past_bij',
				'metabox' => empty( $in['metabox'] ) ? 0 : 1,
				'klasse'  => sanitize_html_class( (string) ( $in['klasse'] ?? 'dp-pastbij' ) ) ?: 'dp-pastbij',
				'aantal'  => max( 1, min( 48, (int) ( $in['aantal'] ?? 12 ) ) ),
			];
		},
	] );
	dp_webshop_register_module_settings( 'past-hierbij', 'dp_wph_render', [
		'title'       => 'Past hierbij',
		'description' => 'Gekoppelde accessoires per product.',
	] );
} );

function dp_wph_render() {
	global $wpdb;
	$s   = dp_wph_instellingen();
	$met = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value NOT IN ('', 'a:0:{}')", dp_wph_meta() ) );
	?>
	<div class="dpw-kaart">
		<div class="dpw-stats">
			<div class="dpw-stat"><strong><?php echo esc_html( number_format_i18n( $met ) ); ?></strong><span>producten met koppelingen</span></div>
		</div>
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_past_bij' ); ?>
			<div class="dpw-veld">
				<strong>Naam van het veld</strong>
				<input type="text" class="regular-text" name="dp_webshop_past_bij[meta]" value="<?php echo esc_attr( $s['meta'] ); ?>">
				<p class="dpw-hint">Bestaat er al een veld (bijvoorbeeld een JetEngine-postsveld), vul die naam in; de opslag is gelijk (een lijst product-ID's).</p>
			</div>
			<div class="dpw-veld">
				<label>
					<input type="hidden" name="dp_webshop_past_bij[metabox]" value="0">
					<input type="checkbox" name="dp_webshop_past_bij[metabox]" value="1" <?php checked( ! empty( $s['metabox'] ) ); ?>>
					Eigen invoervak op het productgegevens-scherm
				</label>
				<p class="dpw-hint">Uit als JetEngine (of iets anders) het veld al laat invullen.</p>
			</div>
			<div class="dpw-veld">
				<strong>Klasse van de Bricks-loop</strong>
				<input type="text" class="regular-text" name="dp_webshop_past_bij[klasse]" value="<?php echo esc_attr( $s['klasse'] ); ?>">
				<p class="dpw-hint">Geef het herhalende element (de kaart met Query loop) deze klasse. Een globale klasse of een gewone CSS-klasse werkt allebei.</p>
			</div>
			<div class="dpw-veld">
				<strong>Maximaal aantal</strong>
				<input type="number" min="1" max="48" name="dp_webshop_past_bij[aantal]" value="<?php echo esc_attr( (int) $s['aantal'] ); ?>" style="width:90px;">
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<p>Verberg de hele sectie als er niets gekoppeld is: sectievoorwaarde <em>Dynamic data</em> <code class="dpw-code">{dp_past_bij_aantal}</code> is niet leeg.</p>
		</div>
	</div>
	<?php
}
