<?php
/**
 * Module Name: Afrekenen verbeterd
 * Description: Verbeteringen aan winkelwagen, kassa en account, elk apart aan of uit: alleen landen tonen waar een verzendzone voor bestaat, de winkelwagenpagina in twee kolommen en zonder de ACSS-centrering die elke section krijgt, grote leesbare velden en knoppen, de FluentCart-kleuren uit de huisstijl, en een nette inlogkaart op "Mijn account".
 * Category: afrekenen
 * Vervalt zodra: FluentCart de landenlijst op de verzendzones afstemt en de kassa goed leesbaar is zonder eigen opmaak.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_AFREKENEN_VERSION', '1.0.0' );

function dp_wak_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_afrekenen', [
		'landen'      => 1,
		'layout'      => 1,
		'grote_velden'=> 0,
		'kleuren'     => 1,
		'inlogkaart'  => 1,
		'knopkleur'   => 'var(--primary, #253241)',
		'knopkleur_hover' => 'var(--primary-dark, #151d26)',
		'tekstkleur'  => 'var(--text-dark, #2f3448)',
		'randkleur'   => 'var(--base-light, #d6dae1)',
		'vlakkleur'   => 'var(--base-ultra-light, #f5f6f7)',
		'afronding'   => 'var(--radius, 6px)',
	] );
}

/* ------------------------------------------------------------------ */
/*  Landen: alleen waar een verzendzone voor bestaat                    */
/*  Zo kan niemand een adres kiezen waarvoor geen verzendmethode is.    */
/*  Volgt de zones: voegt de klant er een toe, dan verschijnt dat land. */
/*  Beheer (wp-admin, REST als beheerder) ziet altijd alle landen.      */
/* ------------------------------------------------------------------ */

add_filter( 'fluent_cart/util/countries', function ( $opties ) {
	if ( empty( dp_wak_instellingen()['landen'] ) ) {
		return $opties;
	}
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST && current_user_can( 'manage_options' ) ) ) {
		return $opties;
	}
	static $landen = null;
	if ( null === $landen ) {
		$landen = [];
		if ( class_exists( '\FluentCart\App\Models\ShippingZone' ) ) {
			foreach ( \FluentCart\App\Models\ShippingZone::query()->get() as $zone ) {
				$meta = (array) $zone->meta;
				if ( $zone->region === 'all' || ( $zone->region === 'selection' && ( $meta['selection_type'] ?? 'included' ) === 'excluded' ) ) {
					$landen = [];
					break; // hele wereld: niet beperken
				}
				if ( $zone->region === 'selection' ) {
					$landen = array_merge( $landen, (array) ( $meta['countries'] ?? [] ) );
				} elseif ( $zone->region ) {
					$landen[] = $zone->region;
				}
			}
		}
	}
	if ( ! $landen ) {
		return $opties;
	}
	return array_values( array_filter( (array) $opties, fn( $o ) => in_array( $o['value'] ?? '', $landen, true ) ) );
} );

/* ------------------------------------------------------------------ */
/*  Opmaak                                                              */
/* ------------------------------------------------------------------ */

/** CSS-waarde uit de instellingen: alleen tekens die in een kleur/var() horen. */
function dp_wak_waarde( $v ) {
	return preg_replace( '/[^a-zA-Z0-9#%(),.\s\-]/', '', (string) $v );
}

function dp_wak_css() {
	$s   = dp_wak_instellingen();
	$k   = dp_wak_waarde( $s['knopkleur'] );
	$kh  = dp_wak_waarde( $s['knopkleur_hover'] );
	$t   = dp_wak_waarde( $s['tekstkleur'] );
	$r   = dp_wak_waarde( $s['randkleur'] );
	$v   = dp_wak_waarde( $s['vlakkleur'] );
	$a   = dp_wak_waarde( $s['afronding'] );
	$css = '';

	if ( ! empty( $s['kleuren'] ) ) {
		$css .= ":root{--fct-primary-bg-color:$k;--fct-btn-bg-color:$k;--fct-btn-border-color:$k;--fct-active-border-color:$k;--fct-primary-text-color:$t;--fct-border-color:$r;--fct-divider-color:$r;--fct-secondary-bg-color:$v;}";
		// De bestelknop heeft een eigen verloop; die en de winkelwagenknop effen in de huisstijl.
		$css .= ".fct_checkout .fct_place_order_btn.fct_place_order_btn,.fct-cart-page .checkout-button{background:$k;background-image:none;border:0;border-radius:$a;color:#fff;text-align:center;box-shadow:none;}";
		$css .= ".fct_checkout .fct_place_order_btn.fct_place_order_btn:hover,.fct-cart-page .checkout-button:hover{background:$kh;}";
	}

	if ( ! empty( $s['layout'] ) ) {
		// ACSS geeft elke <section> flex met alles gecentreerd; FluentCart gebruikt <section> als wrapper.
		$css .= "section.fct-cart-page{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,360px);grid-template-areas:'items totaal' 'items knop';gap:16px 56px;align-items:start;padding:0;}";
		$css .= ".fct-cart-page>.fct-cart-drawer-content-wrapper{grid-area:items;display:block;width:100%;height:auto;max-height:none;overflow:visible;}";
		// De lijst komt uit de winkelwagenlade en heeft daar een maximale hoogte met eigen scrollbalk.
		$css .= ".fct-cart-page .fct-cart-drawer-list,.fct-cart-page .fct-cart-drawer-list-content{height:auto;max-height:none;overflow:visible;}";
		$css .= ".fct-cart-page>.fct-cart-total-wrapper{grid-area:totaal;display:flex;flex-direction:row;justify-content:space-between;align-items:baseline;gap:16px;padding:24px;border:1px solid $r;border-radius:$a;background:$v;font-size:20px;font-weight:700;}";
		$css .= ".fct-cart-page>.fluent-cart-cart-cart-button-wrap{grid-area:knop;}.fct-cart-page .checkout-button{display:block;width:100%;}";
		$css .= ".fct-cart-page .fct-cart-item{gap:20px;padding:24px 0;border-bottom:1px solid $r;}.fct-cart-page .fct-cart-item:first-child{padding-top:0;}";
		$css .= ".fct-cart-page .fct-cart-item-image img{width:96px;height:96px;object-fit:contain;border-radius:$a;background:$v;}";
		$css .= "@media (max-width:767px){section.fct-cart-page{grid-template-columns:minmax(0,1fr);grid-template-areas:'items' 'totaal' 'knop';}}";
	}

	if ( ! empty( $s['grote_velden'] ) ) {
		// FluentCart zet de basis op 13-15px. De velden blijven aaneengesloten zoals FluentCart ze tekent.
		$css .= ".fct_checkout,.fct-cart-page{font-size:16px;}";
		$css .= ".fct_checkout input.fct-input:not([type='checkbox']):not([type='radio']),.fct_checkout .fct-nice-select{min-height:52px;font-size:17px;}";
		$css .= ".fct_checkout textarea.fct-input{min-height:120px;font-size:17px;}";
		$css .= ".fct_checkout .fct_form_section_header_label,.fct_checkout .fct_summary h4{font-size:18px;}";
		$css .= ".fct_checkout .fct_input_label,.fct_checkout .fct_shipping_methods_item label,.fct_checkout .fct_order_note_toggle,.fct_checkout .fct_coupon_toggle{font-size:16px;}";
		$css .= ".fct_checkout .fct_place_order_btn.fct_place_order_btn,.fct-cart-page .checkout-button{min-height:58px;padding:16px 24px;line-height:1.4;font-size:18px;font-weight:700;}";
		$css .= ".fct-cart-page .fct-cart-item-title{font-size:18px;}";
	}

	if ( ! empty( $s['inlogkaart'] ) ) {
		$css .= ".fct_auth_wrap{max-width:600px;padding:40px;border:1px solid $r;border-radius:$a;background:$v;}";
		$css .= ".fct_auth_message h2{margin:0 0 8px;}.fct_auth_message p{margin:0 0 24px;}";
		$css .= ".fct_auth_message a.button{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 32px;border-radius:$a;background:$k;color:#fff;font-weight:700;text-decoration:none;}";
		$css .= ".fct_auth_message a.button:hover{background:$kh;color:#fff;}";
	}

	return $css;
}

add_action( 'wp_head', function () {
	$css = dp_wak_css();
	if ( $css !== '' ) {
		echo "<style id=\"dp-webshop-afrekenen\">\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- waarden gefilterd in dp_wak_waarde()
	}
}, 30 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_afrekenen', 'dp_webshop_afrekenen', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : [];
			$uit = [];
			foreach ( [ 'landen', 'layout', 'grote_velden', 'kleuren', 'inlogkaart' ] as $k ) {
				$uit[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
			foreach ( [ 'knopkleur', 'knopkleur_hover', 'tekstkleur', 'randkleur', 'vlakkleur', 'afronding' ] as $k ) {
				$uit[ $k ] = trim( dp_wak_waarde( $in[ $k ] ?? '' ) );
			}
			return array_filter( $uit, fn( $v ) => $v !== '' );
		},
	] );
	dp_webshop_register_module_settings( 'afrekenen', 'dp_wak_render', [
		'title'       => 'Afrekenen verbeterd',
		'description' => 'Winkelwagen, kassa en account.',
	] );
} );

function dp_wak_render() {
	$s      = dp_wak_instellingen();
	$vinkje = function ( $sleutel, $tekst, $hint = '' ) use ( $s ) {
		printf(
			'<label><input type="hidden" name="dp_webshop_afrekenen[%1$s]" value="0"><input type="checkbox" name="dp_webshop_afrekenen[%1$s]" value="1" %2$s> %3$s</label>%4$s',
			esc_attr( $sleutel ),
			checked( ! empty( $s[ $sleutel ] ), true, false ),
			esc_html( $tekst ),
			$hint ? '<p class="dpw-hint" style="margin:-2px 0 10px 24px;">' . esc_html( $hint ) . '</p>' : ''
		);
	};
	$kleur = function ( $sleutel, $tekst ) use ( $s ) {
		printf(
			'<tr><td style="width:190px;">%s</td><td><input type="text" class="regular-text" name="dp_webshop_afrekenen[%s]" value="%s"></td></tr>',
			esc_html( $tekst ),
			esc_attr( $sleutel ),
			esc_attr( $s[ $sleutel ] )
		);
	};
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_afrekenen' ); ?>
			<div class="dpw-veld">
				<strong>Onderdelen</strong>
				<?php
				$vinkje( 'landen', 'Alleen landen met een verzendzone', 'De landenlijst bij afrekenen volgt de verzendzones van FluentCart.' );
				$vinkje( 'layout', 'Winkelwagenpagina in twee kolommen', 'Artikelen links, totaal en knop rechts. Heft ook de ACSS-centrering op die FluentCart\'s <section> anders krijgt.' );
				$vinkje( 'grote_velden', 'Grote, goed leesbare velden en knoppen', '16-18px tekst, velden van 52px. Voor een oudere doelgroep.' );
				$vinkje( 'kleuren', 'Kleuren uit de huisstijl', 'Knoppen, randen en vlakken van FluentCart in de kleuren hieronder.' );
				$vinkje( 'inlogkaart', 'Nette inlogkaart op "Mijn account"', 'In plaats van een kaal linkje "Inloggen".' );
				?>
			</div>
			<div class="dpw-veld">
				<strong>Kleuren en afronding</strong>
				<table class="dpw-tabel">
					<?php
					$kleur( 'knopkleur', 'Knop' );
					$kleur( 'knopkleur_hover', 'Knop bij aanwijzen' );
					$kleur( 'tekstkleur', 'Tekst' );
					$kleur( 'randkleur', 'Randen' );
					$kleur( 'vlakkleur', 'Vlakken' );
					$kleur( 'afronding', 'Afronding' );
					?>
				</table>
				<p class="dpw-hint">Een kleurcode (#0b5fd0) of een variabele van de site, zoals <code class="dpw-code">var(--primary)</code>. Met ACSS kloppen de standaardwaarden meestal direct.</p>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
	</div>
	<?php
}
