<?php
/**
 * Module Name: WooCommerce-URL's behouden
 * Description: Voor een overstap van WooCommerce naar FluentCart zonder SEO-dip: productcategorieën op hetzelfde adres als in WooCommerce (/product-category/hoofd/sub/ in plaats van FluentCart's /product-categories/sub/), en filterlinks op categoriepagina's zonder extra doorverwijzing. Toont ook of het productadres (/product/...) al gelijk is.
 * Category: taal-seo
 * Vervalt zodra: de oude WooCommerce-adressen geen bezoekers meer krijgen (na zo'n jaar nagaan in Search Console).
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_WCURLS_VERSION', '1.0.0' );

function dp_wwu_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_wc_urls', [
		'categorie_basis' => 'product-category',
		'hierarchisch'    => 1,
		'filterlinks'     => 1,
	] );
}

/* Categorie-adres zoals WooCommerce het had. Draait vóór FluentCart de taxonomie registreert. */
add_filter( 'register_taxonomy_args', function ( $args, $taxonomy ) {
	if ( $taxonomy !== 'product-categories' ) {
		return $args;
	}
	$s     = dp_wwu_instellingen();
	$basis = trim( (string) $s['categorie_basis'], '/' );
	if ( $basis !== '' ) {
		$args['rewrite'] = [ 'slug' => $basis, 'with_front' => false, 'hierarchical' => ! empty( $s['hierarchisch'] ) ];
	}
	return $args;
}, 10, 2 );

/*
 * Herschrijfregels verversen zodra de instelling verandert (één keer, niet bij elke request).
 * Laat op init, zodat eigen regels van andere code (bv. landingspagina's in een snippet)
 * al zijn toegevoegd en mee worden opgeslagen.
 */
add_action( 'init', function () {
	$s      = dp_wwu_instellingen();
	$versie = md5( $s['categorie_basis'] . '|' . (int) $s['hierarchisch'] );
	if ( get_option( 'dp_webshop_wc_urls_versie' ) !== $versie ) {
		flush_rewrite_rules( false );
		update_option( 'dp_webshop_wc_urls_versie', $versie, false );
	}
}, 999 );

/*
 * Filterlinks (?merk[]=pride) op een categoriepagina niet laten herschrijven tot
 * ?merk[0]=pride: WordPress' canonieke omleiding bouwt de querystring opnieuw op, wat bij
 * elke gedeelde filterlink een extra 301 geeft. Alleen als het pad gelijk blijft.
 */
add_filter( 'redirect_canonical', function ( $doel, $gevraagd ) {
	if ( empty( dp_wwu_instellingen()['filterlinks'] ) ) {
		return $doel;
	}
	if ( $doel && is_tax( 'product-categories' ) && wp_parse_url( $doel, PHP_URL_PATH ) === wp_parse_url( $gevraagd, PHP_URL_PATH ) ) {
		return false;
	}
	return $doel;
}, 10, 2 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_wc_urls', 'dp_webshop_wc_urls', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in    = is_array( $in ) ? $in : [];
			$basis = trim( sanitize_title_with_dashes( (string) ( $in['categorie_basis'] ?? 'product-category' ) ), '/' );
			return [
				'categorie_basis' => $basis !== '' ? $basis : 'product-category',
				'hierarchisch'    => empty( $in['hierarchisch'] ) ? 0 : 1,
				'filterlinks'     => empty( $in['filterlinks'] ) ? 0 : 1,
			];
		},
	] );
	dp_webshop_register_module_settings( 'woocommerce-urls', 'dp_wwu_render', [
		'title'       => "WooCommerce-URL's behouden",
		'description' => 'Adressen gelijk aan de oude WooCommerce-winkel.',
	] );
} );

function dp_wwu_render() {
	$s        = dp_wwu_instellingen();
	$winkel   = (array) get_option( 'fluent_cart_store_settings', [] );
	$product  = $winkel['product_slug'] ?? '';
	$voorbeeld = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false, 'number' => 1, 'childless' => true ] );
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_wc_urls' ); ?>
			<div class="dpw-veld">
				<strong>Basis van categorie-adressen</strong>
				<input type="text" class="regular-text" name="dp_webshop_wc_urls[categorie_basis]" value="<?php echo esc_attr( $s['categorie_basis'] ); ?>">
				<p class="dpw-hint">WooCommerce gebruikt standaard <code class="dpw-code">product-category</code>. Stond de oude winkel anders ingesteld (WooCommerce → Instellingen → Permalinks), neem die waarde over.</p>
			</div>
			<div class="dpw-veld">
				<label>
					<input type="hidden" name="dp_webshop_wc_urls[hierarchisch]" value="0">
					<input type="checkbox" name="dp_webshop_wc_urls[hierarchisch]" value="1" <?php checked( ! empty( $s['hierarchisch'] ) ); ?>>
					Hoofdcategorie in het adres van een subcategorie (/product-category/hoofd/sub/)
				</label>
				<label>
					<input type="hidden" name="dp_webshop_wc_urls[filterlinks]" value="0">
					<input type="checkbox" name="dp_webshop_wc_urls[filterlinks]" value="1" <?php checked( ! empty( $s['filterlinks'] ) ); ?>>
					Filterlinks op categoriepagina's zonder extra doorverwijzing
				</label>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<?php if ( ! is_wp_error( $voorbeeld ) && $voorbeeld ) : ?>
				<p>Voorbeeld: <code class="dpw-code"><?php echo esc_html( wp_parse_url( get_term_link( $voorbeeld[0] ), PHP_URL_PATH ) ); ?></code></p>
			<?php endif; ?>
			<p>Productadres in FluentCart: <code class="dpw-code">/<?php echo esc_html( $product ?: '?' ); ?>/…</code>
				<?php echo $product === 'product' ? ' — gelijk aan WooCommerce.' : ' — WooCommerce gebruikt <code class="dpw-code">/product/…</code>; stel dat in bij FluentCart → Instellingen.'; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</p>
			<p>Oude subcategorieën die nu een filter zijn (bijvoorbeeld "3-wielers"), en losse oude adressen, regel je met doorverwijzingen of een landingspagina per site.</p>
		</div>
	</div>
	<?php
}
