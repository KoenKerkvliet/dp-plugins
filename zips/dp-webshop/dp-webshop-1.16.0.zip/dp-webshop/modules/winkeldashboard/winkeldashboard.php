<?php
/**
 * Module Name: Winkeldashboard
 * Description: Winkelkaarten op het WordPress-dashboard: omzet vandaag en deze maand, bestellingen die nog verwerkt moeten worden, de laatste bestellingen met status, snel een product aanmaken (naam, prijs, categorie → verder in FluentCart) en artikelen waarvan de voorraad bijna op is. Komt in het Design Pixels-dashboard van DP Toolbox; zonder dat dashboard als eigen widget.
 * Category: verkoop
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_DASHBOARD_VERSION', '1.0.0' );

function dp_wdb_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_dashboard', [
		'cijfers'    => 1,
		'bestellingen' => 1,
		'aantal'     => 5,
		'toevoegen'  => 1,
		'voorraad'   => 1,
		'drempel'    => 3,
	] );
}

/** Wie ziet de winkelkaarten. */
function dp_wdb_mag() {
	return (bool) apply_filters( 'dp_webshop_dashboard_zichtbaar', current_user_can( 'manage_options' ) );
}

/* ------------------------------------------------------------------ */
/*  Gegevens                                                            */
/* ------------------------------------------------------------------ */

/**
 * Welke bestellingen tellen: echte (live). Zolang er nog geen enkele echte bestelling is,
 * tonen we de testbestellingen, zodat je vóór de livegang ziet hoe het eruitziet.
 */
function dp_wdb_modus() {
	global $wpdb;
	static $modus = null;
	if ( null === $modus ) {
		$live  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}fct_orders WHERE mode = 'live' LIMIT 1" );
		$modus = $live ? 'live' : 'test';
	}
	return $modus;
}

function dp_wdb_euro( $centen, $valuta = 'EUR' ) {
	$teken = [ 'EUR' => '€', 'USD' => '$', 'GBP' => '£' ][ strtoupper( (string) $valuta ) ] ?? strtoupper( (string) $valuta ) . ' ';
	return $teken . number_format_i18n( (int) $centen / 100, 2 );
}

/** Begin van vandaag en van deze maand in de tijd van de site, als GMT (zo slaat FluentCart op). */
function dp_wdb_grenzen() {
	return [
		'vandaag' => get_gmt_from_date( wp_date( 'Y-m-d 00:00:00' ) ),
		'maand'   => get_gmt_from_date( wp_date( 'Y-m-01 00:00:00' ) ),
	];
}

function dp_wdb_cijfers() {
	global $wpdb;
	$t      = $wpdb->prefix . 'fct_orders';
	$g      = dp_wdb_grenzen();
	$betaald = "payment_status IN ('paid','partially_paid','partially_refunded') AND status NOT IN ('canceled','failed')";
	$modus  = $wpdb->prepare( 'mode = %s', dp_wdb_modus() );
	$omzet  = function ( $vanaf ) use ( $wpdb, $t, $betaald, $modus ) {
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total_paid - total_refund), 0) FROM $t WHERE $betaald AND $modus AND created_at >= %s", $vanaf ) );
	};
	return [
		'vandaag'      => $omzet( $g['vandaag'] ),
		'maand'        => $omzet( $g['maand'] ),
		'aantal_maand' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $betaald AND $modus AND created_at >= %s", $g['maand'] ) ),
		'te_doen'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status IN ('processing','on-hold') AND payment_status IN ('paid','partially_paid') AND $modus" ),
		'valuta'       => (string) ( $wpdb->get_var( "SELECT currency FROM $t ORDER BY id DESC LIMIT 1" ) ?: 'EUR' ),
	];
}

function dp_wdb_laatste( $aantal ) {
	global $wpdb;
	return $wpdb->get_results( $wpdb->prepare(
		"SELECT o.id, o.invoice_no, o.receipt_number, o.status, o.payment_status, o.shipping_status, o.fulfillment_type,
		        o.total_amount, o.currency, o.mode, o.created_at, c.first_name, c.last_name, c.email,
		        (SELECT COALESCE(SUM(i.quantity), 0) FROM {$wpdb->prefix}fct_order_items i WHERE i.order_id = o.id) AS artikelen
		 FROM {$wpdb->prefix}fct_orders o
		 LEFT JOIN {$wpdb->prefix}fct_customers c ON c.id = o.customer_id
		 WHERE o.mode = %s
		 ORDER BY o.id DESC LIMIT %d",
		dp_wdb_modus(), max( 1, (int) $aantal )
	) );
}

/** Status in gewone taal, met een kleur. */
function dp_wdb_status( $o ) {
	if ( in_array( $o->payment_status, [ 'refunded' ], true ) ) {
		return [ 'Terugbetaald', 'grijs' ];
	}
	switch ( $o->status ) {
		case 'completed':
			return [ 'Afgerond', 'groen' ];
		case 'canceled':
			return [ 'Geannuleerd', 'grijs' ];
		case 'failed':
			return [ 'Mislukt', 'rood' ];
		case 'on-hold':
			return [ 'In de wacht', 'oranje' ];
	}
	if ( ! in_array( $o->payment_status, [ 'paid', 'partially_paid' ], true ) ) {
		return [ 'Wacht op betaling', 'oranje' ];
	}
	if ( $o->shipping_status === 'shipped' ) {
		return [ 'Verzonden', 'blauw' ];
	}
	return [ $o->fulfillment_type === 'digital' ? 'Betaald' : 'Te verzenden', 'paars' ];
}

function dp_wdb_voorraad( $drempel ) {
	global $wpdb;
	return $wpdb->get_results( $wpdb->prepare(
		"SELECT v.post_id, v.variation_title, v.available, p.post_title
		 FROM {$wpdb->prefix}fct_product_variations v
		 JOIN {$wpdb->posts} p ON p.ID = v.post_id AND p.post_status = 'publish'
		 WHERE v.manage_stock = 1 AND v.item_status = 'active' AND v.available <= %d
		 ORDER BY v.available ASC, p.post_title ASC LIMIT 6",
		max( 0, (int) $drempel )
	) );
}

function dp_wdb_url( $pad ) {
	if ( class_exists( '\FluentCart\App\Services\URL' ) && method_exists( '\FluentCart\App\Services\URL', 'getDashboardUrl' ) ) {
		return \FluentCart\App\Services\URL::getDashboardUrl( $pad );
	}
	return admin_url( 'admin.php?page=fluent-cart#/' . $pad );
}

/* ------------------------------------------------------------------ */
/*  Product snel aanmaken                                               */
/*  Zelfde stappen als FluentCart's eigen "Product toevoegen": bericht, */
/*  productgegevens en één standaardvariant. Als concept; foto's,       */
/*  omschrijving en publiceren gaan daarna in de FluentCart-editor.     */
/* ------------------------------------------------------------------ */

function dp_wdb_prijs_centen( $invoer ) {
	$p = preg_replace( '/[^\d,.]/', '', (string) $invoer );
	if ( $p === '' ) {
		return 0;
	}
	$komma = strrpos( $p, ',' );
	$punt  = strrpos( $p, '.' );
	if ( false !== $komma && false !== $punt ) {
		// Allebei: het laatste teken is het decimaalteken (1.234,50 of 1,234.50).
		$decimaal = $komma > $punt ? ',' : '.';
		$p        = str_replace( $decimaal === ',' ? '.' : ',', '', $p );
		$p        = str_replace( $decimaal, '.', $p );
	} elseif ( false !== $komma ) {
		$p = str_replace( ',', '.', $p ); // Nederlands: 12,50
	} elseif ( preg_match( '/^\d{1,3}(\.\d{3})+$/', $p ) ) {
		$p = str_replace( '.', '', $p );  // 1.299 = 1299 euro
	}
	return max( 0, (int) round( (float) $p * 100 ) );
}

/**
 * Maak een concept-product aan. Geeft het product-ID terug, of een WP_Error.
 *
 * @param string $titel
 * @param int    $centen prijs in centen (0 = nog geen prijs)
 * @param string $soort  physical|digital
 * @param int    $cat    term-ID van product-categories (0 = geen)
 */
function dp_wdb_product_aanmaken( $titel, $centen = 0, $soort = 'physical', $cat = 0 ) {
	$titel = sanitize_text_field( (string) $titel );
	if ( $titel === '' ) {
		return new WP_Error( 'dp_wdb_titel', 'Geen naam.' );
	}
	if ( ! class_exists( '\FluentCart\App\Models\ProductDetail' ) || ! class_exists( '\FluentCart\App\Models\ProductVariation' ) ) {
		return new WP_Error( 'dp_wdb_fluentcart', 'FluentCart ontbreekt.' );
	}
	$centen = max( 0, (int) $centen );
	$soort  = $soort === 'digital' ? 'digital' : 'physical';

	$post_id = wp_insert_post( [
		'post_title'  => $titel,
		'post_name'   => sanitize_title( $titel ),
		'post_type'   => 'fluent-products',
		'post_status' => 'draft',
	], true );
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}

	$detail  = \FluentCart\App\Models\ProductDetail::query()->create( [
		'post_id'            => $post_id,
		'fulfillment_type'   => $soort,
		'variation_type'     => 'simple',
		'min_price'          => $centen,
		'max_price'          => $centen,
		'stock_availability' => 'in-stock',
		'manage_stock'       => 0,
	] );
	$variant = \FluentCart\App\Models\ProductVariation::query()->create( [
		'post_id'          => $post_id,
		'serial_index'     => 1,
		'variation_title'  => $titel,
		'stock_status'     => 'in-stock',
		'payment_type'     => 'onetime',
		'total_stock'      => 1,
		'available'        => 1,
		'fulfillment_type' => $soort,
		'item_price'       => $centen,
		'other_info'       => [
			'description'        => '',
			'payment_type'       => 'onetime',
			'tax_class'          => 'standard',
			'tax_exempt'         => 'no',
			'times'              => '',
			'repeat_interval'    => '',
			'trial_days'         => '',
			'billing_summary'    => '',
			'manage_setup_fee'   => 'no',
			'signup_fee_name'    => '',
			'signup_fee'         => '',
			'setup_fee_per_item' => 'no',
			'is_bundle_product'  => 'no',
		],
	] );
	if ( $detail && $variant ) {
		\FluentCart\App\Models\ProductDetail::query()->where( 'id', $detail->id )->update( [ 'default_variation_id' => $variant->id ] );
	}
	$cat = absint( $cat );
	if ( $cat && term_exists( $cat, 'product-categories' ) ) {
		wp_set_object_terms( $post_id, [ $cat ], 'product-categories' );
	}
	return $post_id;
}

add_action( 'admin_post_dp_wdb_product', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dp_wdb_product' ) ) {
		wp_die( 'Geen toegang.' );
	}
	$post_id = dp_wdb_product_aanmaken(
		wp_unslash( $_POST['titel'] ?? '' ),
		dp_wdb_prijs_centen( wp_unslash( $_POST['prijs'] ?? '' ) ),
		sanitize_key( $_POST['soort'] ?? '' ),
		absint( $_POST['categorie'] ?? 0 )
	);
	if ( is_wp_error( $post_id ) ) {
		wp_safe_redirect( add_query_arg( 'dp_wdb', 'fout', admin_url( 'index.php' ) ) );
		exit;
	}
	wp_safe_redirect( dp_webshop_fluentcart_product_url( $post_id ) );
	exit;
} );

/* ------------------------------------------------------------------ */
/*  Weergave                                                            */
/* ------------------------------------------------------------------ */

function dp_wdb_render() {
	if ( ! dp_wdb_mag() ) {
		return;
	}
	$s     = dp_wdb_instellingen();
	$test  = dp_wdb_modus() === 'test';
	$fout  = ( $_GET['dp_wdb'] ?? '' ) === 'fout'; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="dpw-dash">
		<div class="dpw-dash-kop">
			<div class="dpw-dash-titel">
				<span class="dashicons dashicons-cart"></span> Winkel
				<?php if ( $test ) : ?><span class="dpw-dash-testlabel" title="Er zijn nog geen echte bestellingen; je ziet de testbestellingen.">testbestellingen</span><?php endif; ?>
			</div>
			<div class="dpw-dash-links">
				<a href="<?php echo esc_url( dp_wdb_url( 'orders' ) ); ?>">Bestellingen</a>
				<a href="<?php echo esc_url( dp_wdb_url( 'products' ) ); ?>">Producten</a>
				<a href="<?php echo esc_url( dp_wdb_url( 'customers' ) ); ?>">Klanten</a>
			</div>
		</div>

		<?php if ( ! empty( $s['cijfers'] ) ) :
			$c = dp_wdb_cijfers();
		?>
			<div class="dpw-dash-cijfers">
				<div class="dpw-dash-cijfer">
					<span class="dpw-dash-getal"><?php echo esc_html( dp_wdb_euro( $c['vandaag'], $c['valuta'] ) ); ?></span>
					<span class="dpw-dash-label">Omzet vandaag</span>
				</div>
				<div class="dpw-dash-cijfer">
					<span class="dpw-dash-getal"><?php echo esc_html( dp_wdb_euro( $c['maand'], $c['valuta'] ) ); ?></span>
					<span class="dpw-dash-label">Omzet <?php echo esc_html( wp_date( 'F' ) ); ?></span>
				</div>
				<div class="dpw-dash-cijfer">
					<span class="dpw-dash-getal"><?php echo esc_html( number_format_i18n( $c['aantal_maand'] ) ); ?></span>
					<span class="dpw-dash-label">Bestellingen <?php echo esc_html( wp_date( 'F' ) ); ?></span>
				</div>
				<a class="dpw-dash-cijfer<?php echo $c['te_doen'] ? ' is-actie' : ''; ?>" href="<?php echo esc_url( dp_wdb_url( 'orders' ) ); ?>">
					<span class="dpw-dash-getal"><?php echo esc_html( number_format_i18n( $c['te_doen'] ) ); ?></span>
					<span class="dpw-dash-label">Te verwerken</span>
				</a>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $s['bestellingen'] ) || ! empty( $s['toevoegen'] ) ) : ?>
			<div class="dpw-dash-rij<?php echo ( empty( $s['bestellingen'] ) || empty( $s['toevoegen'] ) ) ? ' is-enkel' : ''; ?>">
				<?php if ( ! empty( $s['bestellingen'] ) ) :
					$lijst = dp_wdb_laatste( (int) $s['aantal'] );
				?>
					<div class="dpw-dash-kaart">
						<div class="dpw-dash-kaart-titel">
							<span>Laatste bestellingen</span>
							<a href="<?php echo esc_url( dp_wdb_url( 'orders' ) ); ?>">Alle bestellingen →</a>
						</div>
						<?php if ( ! $lijst ) : ?>
							<p class="dpw-dash-leeg">Nog geen bestellingen. Zodra iemand iets koopt, zie je het hier.</p>
						<?php else : ?>
							<ul class="dpw-dash-orders">
								<?php foreach ( $lijst as $o ) :
									$naam     = trim( $o->first_name . ' ' . $o->last_name ) ?: ( $o->email ?: 'Gast' );
									$letters  = strtoupper( mb_substr( $o->first_name ?: $naam, 0, 1 ) . mb_substr( (string) $o->last_name, 0, 1 ) );
									[ $label, $kleur ] = dp_wdb_status( $o );
									$nummer   = $o->invoice_no ?: ( '#' . ( $o->receipt_number ?: $o->id ) );
									$wanneer  = human_time_diff( strtotime( $o->created_at . ' UTC' ), time() );
								?>
									<li>
										<a href="<?php echo esc_url( dp_wdb_url( 'orders/' . (int) $o->id . '/view' ) ); ?>">
											<span class="dpw-dash-avatar"><?php echo esc_html( $letters ); ?></span>
											<span class="dpw-dash-order-info">
												<span class="dpw-dash-order-naam"><?php echo esc_html( $naam ); ?></span>
												<span class="dpw-dash-order-meta"><?php echo esc_html( sprintf( '%s · %s · %s geleden', $nummer, sprintf( _n( '%d artikel', '%d artikelen', (int) $o->artikelen ), (int) $o->artikelen ), $wanneer ) ); ?></span>
											</span>
											<span class="dpw-dash-order-rechts">
												<span class="dpw-dash-bedrag"><?php echo esc_html( dp_wdb_euro( $o->total_amount, $o->currency ) ); ?></span>
												<span class="dpw-dash-status is-<?php echo esc_attr( $kleur ); ?>"><?php echo esc_html( $label ); ?></span>
											</span>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $s['toevoegen'] ) ) :
					$cats = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false, 'orderby' => 'name' ] );
				?>
					<div class="dpw-dash-kaart dpw-dash-nieuw">
						<div class="dpw-dash-kaart-titel"><span>Product toevoegen</span></div>
						<?php if ( $fout ) : ?><p class="dpw-dash-fout">Dat lukte niet. Vul in elk geval een naam in.</p><?php endif; ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="dp_wdb_product">
							<?php wp_nonce_field( 'dp_wdb_product' ); ?>
							<label>Naam<input type="text" name="titel" required placeholder="Bijvoorbeeld: Rollator Lichtgewicht"></label>
							<div class="dpw-dash-twee">
								<label>Prijs<span class="dpw-dash-prijs"><em>€</em><input type="text" name="prijs" inputmode="decimal" placeholder="0,00"></span></label>
								<label>Soort
									<select name="soort">
										<option value="physical">Fysiek product</option>
										<option value="digital">Digitaal product</option>
									</select>
								</label>
							</div>
							<?php if ( ! is_wp_error( $cats ) && $cats ) : ?>
								<label>Categorie
									<select name="categorie">
										<option value="0">Geen categorie</option>
										<?php foreach ( $cats as $cat ) : ?>
											<option value="<?php echo (int) $cat->term_id; ?>"><?php echo esc_html( ( $cat->parent ? '— ' : '' ) . $cat->name ); ?></option>
										<?php endforeach; ?>
									</select>
								</label>
							<?php endif; ?>
							<button type="submit" class="dpw-dash-knop">Aanmaken en verder in FluentCart</button>
							<p class="dpw-dash-uitleg">Het product wordt als concept aangemaakt. Foto's, omschrijving en publiceren doe je daarna in FluentCart.</p>
						</form>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $s['voorraad'] ) ) :
			$bijna = dp_wdb_voorraad( (int) $s['drempel'] );
			if ( $bijna ) :
		?>
			<div class="dpw-dash-kaart dpw-dash-voorraad">
				<div class="dpw-dash-kaart-titel"><span>Voorraad bijna op</span></div>
				<ul>
					<?php foreach ( $bijna as $v ) :
						$titel = $v->variation_title && $v->variation_title !== $v->post_title ? $v->post_title . ' – ' . $v->variation_title : $v->post_title;
					?>
						<li>
							<a href="<?php echo esc_url( dp_webshop_fluentcart_product_url( $v->post_id ) ); ?>">
								<span><?php echo esc_html( $titel ); ?></span>
								<strong class="<?php echo (int) $v->available <= 0 ? 'is-op' : ''; ?>"><?php echo (int) $v->available <= 0 ? 'Op' : esc_html( sprintf( 'nog %d', (int) $v->available ) ); ?></strong>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; endif; ?>
	</div>
	<?php
}

/*
 * Plek: in het Design Pixels-dashboard van DP Toolbox (haak dp_toolbox_dashboard_sections),
 * en anders als eigen widget bovenaan het dashboard.
 */
add_action( 'wp_dashboard_setup', function () {
	if ( ! dp_wdb_mag() ) {
		return;
	}
	if ( function_exists( 'dp_toolbox_dashboard_render' ) ) {
		add_action( 'dp_toolbox_dashboard_sections', 'dp_wdb_render' );
		return;
	}
	wp_add_dashboard_widget( 'dp_webshop_dashboard', 'Winkel', 'dp_wdb_render', null, null, 'normal', 'high' );
}, 20 );

add_action( 'admin_head-index.php', function () {
	if ( ! dp_wdb_mag() ) {
		return;
	}
	?>
	<style id="dp-webshop-dashboard">
		.dpw-dash { padding: 4px 28px 24px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #1d2327; }
		#dp_webshop_dashboard .inside { margin: 0; padding: 0; }
		#dp_webshop_dashboard .dpw-dash { padding: 16px 18px 18px; }
		.dpw-dash-kop { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin: 0 0 14px; padding-bottom: 10px; border-bottom: 1px solid #e8e5f0; }
		.dpw-dash-titel { display: flex; align-items: center; gap: 7px; font-size: 11px; font-weight: 700; color: #281E5D; text-transform: uppercase; letter-spacing: .8px; }
		.dpw-dash-titel .dashicons { font-size: 16px; width: 16px; height: 16px; }
		.dpw-dash-testlabel { padding: 2px 8px; border-radius: 10px; background: #fef3c7; color: #92400e; font-size: 10px; font-weight: 600; letter-spacing: 0; text-transform: none; }
		.dpw-dash-links { display: flex; gap: 16px; }
		.dpw-dash-links a { color: #281E5D; font-size: 12px; font-weight: 600; text-decoration: none; }
		.dpw-dash-links a:hover { text-decoration: underline; }

		.dpw-dash-cijfers { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px; }
		.dpw-dash-cijfer { display: block; padding: 16px 18px; border: 1px solid #e4e0ef; border-radius: 10px; background: #fff; text-decoration: none; }
		.dpw-dash-getal { display: block; font-size: 24px; font-weight: 700; line-height: 1.15; color: #281E5D; }
		.dpw-dash-label { display: block; margin-top: 6px; font-size: 11px; color: #777; text-transform: uppercase; letter-spacing: .6px; }
		a.dpw-dash-cijfer { transition: border-color .2s, box-shadow .2s; }
		a.dpw-dash-cijfer:hover { border-color: #c4b5fd; box-shadow: 0 2px 8px rgba(40, 30, 93, .06); }
		.dpw-dash-cijfer.is-actie { border-color: transparent; background: linear-gradient(135deg, #281E5D 0%, #3d2d7a 100%); }
		.dpw-dash-cijfer.is-actie .dpw-dash-getal { color: #fff; }
		.dpw-dash-cijfer.is-actie .dpw-dash-label { color: rgba(255, 255, 255, .75); }

		.dpw-dash-rij { display: grid; grid-template-columns: minmax(0, 1.7fr) minmax(0, 1fr); gap: 16px; }
		.dpw-dash-rij.is-enkel { grid-template-columns: minmax(0, 1fr); }
		.dpw-dash-kaart { padding: 20px 22px; border: 1px solid #e4e0ef; border-radius: 10px; background: #f9f8fc; transition: border-color .2s, box-shadow .2s; }
		.dpw-dash-kaart:hover { border-color: #c4b5fd; box-shadow: 0 2px 8px rgba(40, 30, 93, .06); }
		.dpw-dash-kaart-titel { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 12px; padding-bottom: 10px; border-bottom: 1px solid #e8e5f0; font-size: 11px; font-weight: 700; color: #281E5D; text-transform: uppercase; letter-spacing: .8px; }
		.dpw-dash-kaart-titel a { font-size: 12px; font-weight: 600; letter-spacing: 0; text-transform: none; color: #281E5D; text-decoration: none; }
		.dpw-dash-leeg { margin: 6px 0 0; color: #888; font-size: 13px; }

		.dpw-dash-orders { margin: 0; padding: 0; list-style: none; }
		.dpw-dash-orders li { margin: 0; border-bottom: 1px solid #eee; }
		.dpw-dash-orders li:last-child { border-bottom: 0; }
		.dpw-dash-orders a { display: flex; align-items: center; gap: 12px; padding: 10px 6px; margin: 0 -6px; border-radius: 6px; color: inherit; text-decoration: none; }
		.dpw-dash-orders a:hover { background: #f0edf8; }
		.dpw-dash-avatar { display: inline-flex; flex-shrink: 0; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 50%; background: #eee8ff; color: #281E5D; font-size: 12px; font-weight: 700; }
		.dpw-dash-order-info { flex: 1; min-width: 0; }
		.dpw-dash-order-naam { display: block; overflow: hidden; font-size: 13px; font-weight: 600; white-space: nowrap; text-overflow: ellipsis; }
		.dpw-dash-order-meta { display: block; overflow: hidden; margin-top: 1px; font-size: 11px; color: #999; white-space: nowrap; text-overflow: ellipsis; }
		.dpw-dash-order-rechts { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
		.dpw-dash-bedrag { font-size: 13px; font-weight: 700; color: #1d2327; }
		.dpw-dash-status { padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 700; letter-spacing: .2px; }
		.dpw-dash-status.is-paars { background: #eee8ff; color: #281E5D; }
		.dpw-dash-status.is-groen { background: #dcfce7; color: #166534; }
		.dpw-dash-status.is-blauw { background: #dbeafe; color: #1e40af; }
		.dpw-dash-status.is-oranje { background: #fef3c7; color: #92400e; }
		.dpw-dash-status.is-rood { background: #fee2e2; color: #991b1b; }
		.dpw-dash-status.is-grijs { background: #f1f1f1; color: #666; }

		.dpw-dash-nieuw form { display: flex; flex-direction: column; gap: 10px; }
		.dpw-dash-nieuw label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; font-weight: 600; color: #50575e; }
		.dpw-dash-nieuw label, .dpw-dash-twee > * { min-width: 0; }
		.dpw-dash-nieuw input[type="text"], .dpw-dash-nieuw select { box-sizing: border-box; width: 100%; max-width: none; min-height: 36px; padding: 0 10px; border: 1px solid #d9d4ea; border-radius: 6px; background: #fff; font-size: 13px; font-weight: 400; }
		.dpw-dash-nieuw input[type="text"]:focus, .dpw-dash-nieuw select:focus { border-color: #281E5D; box-shadow: 0 0 0 1px #281E5D; outline: none; }
		.dpw-dash-twee { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
		.dpw-dash-prijs { position: relative; display: block; }
		.dpw-dash-prijs em { position: absolute; top: 50%; left: 10px; transform: translateY(-50%); font-style: normal; font-weight: 600; color: #888; }
		.dpw-dash-prijs input[type="text"] { padding-left: 24px; }
		.dpw-dash-knop { margin-top: 4px; min-height: 38px; border: 0; border-radius: 6px; background: #281E5D; color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; transition: background .2s; }
		.dpw-dash-knop:hover { background: #4a3a8a; }
		.dpw-dash-uitleg { margin: 0; font-size: 11px; line-height: 1.5; color: #888; }
		.dpw-dash-fout { margin: 0 0 8px; padding: 8px 10px; border-radius: 6px; background: #fee2e2; color: #991b1b; font-size: 12px; }

		.dpw-dash-voorraad { margin-top: 16px; }
		.dpw-dash-voorraad ul { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 8px; margin: 0; padding: 0; list-style: none; }
		.dpw-dash-voorraad li { margin: 0; }
		.dpw-dash-voorraad a { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 9px 12px; border: 1px solid #eee; border-radius: 8px; background: #fff; color: inherit; font-size: 12px; text-decoration: none; }
		.dpw-dash-voorraad a:hover { border-color: #c4b5fd; }
		.dpw-dash-voorraad a span { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
		.dpw-dash-voorraad strong { flex-shrink: 0; color: #92400e; }
		.dpw-dash-voorraad strong.is-op { color: #991b1b; }

		@media (max-width: 1100px) {
			.dpw-dash-cijfers { grid-template-columns: repeat(2, minmax(0, 1fr)); }
			.dpw-dash-rij { grid-template-columns: minmax(0, 1fr); }
		}
		@media (max-width: 600px) {
			.dpw-dash { padding: 4px 16px 18px; }
			.dpw-dash-twee { grid-template-columns: 1fr; }
		}
	</style>
	<?php
} );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_dashboard', 'dp_webshop_dashboard', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : [];
			$uit = [];
			foreach ( [ 'cijfers', 'bestellingen', 'toevoegen', 'voorraad' ] as $k ) {
				$uit[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
			$uit['aantal']  = max( 3, min( 10, (int) ( $in['aantal'] ?? 5 ) ) );
			$uit['drempel'] = max( 0, min( 100, (int) ( $in['drempel'] ?? 3 ) ) );
			return $uit;
		},
	] );
	dp_webshop_register_module_settings( 'winkeldashboard', 'dp_wdb_instellingen_render', [
		'title'       => 'Winkeldashboard',
		'description' => 'Welke winkelkaarten op het dashboard staan.',
	] );
} );

function dp_wdb_instellingen_render() {
	$s = dp_wdb_instellingen();
	$vink = function ( $k, $tekst ) use ( $s ) {
		printf(
			'<label><input type="hidden" name="dp_webshop_dashboard[%1$s]" value="0"><input type="checkbox" name="dp_webshop_dashboard[%1$s]" value="1" %2$s> %3$s</label>',
			esc_attr( $k ), checked( ! empty( $s[ $k ] ), true, false ), esc_html( $tekst )
		);
	};
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_dashboard' ); ?>
			<div class="dpw-veld">
				<strong>Kaarten</strong>
				<?php $vink( 'cijfers', 'Cijfers: omzet vandaag en deze maand, bestellingen, te verwerken' ); ?>
				<?php $vink( 'bestellingen', 'Laatste bestellingen' ); ?>
				<?php $vink( 'toevoegen', 'Product toevoegen' ); ?>
				<?php $vink( 'voorraad', 'Voorraad bijna op (alleen producten met voorraadbeheer)' ); ?>
			</div>
			<div class="dpw-veld">
				<strong>Aantal laatste bestellingen</strong>
				<input type="number" min="3" max="10" name="dp_webshop_dashboard[aantal]" value="<?php echo esc_attr( (int) $s['aantal'] ); ?>" style="width:90px;">
			</div>
			<div class="dpw-veld">
				<strong>"Bijna op" vanaf</strong>
				<input type="number" min="0" max="100" name="dp_webshop_dashboard[drempel]" value="<?php echo esc_attr( (int) $s['drempel'] ); ?>" style="width:90px;"> stuks
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<p>De kaarten staan in het Design Pixels-dashboard van DP Toolbox (module Dashboard). Staat die niet aan, dan krijgen ze een eigen widget "Winkel". Alleen beheerders zien ze. Zolang er nog geen echte bestelling is, tonen de kaarten de testbestellingen, met een label erbij.</p>
		</div>
	</div>
	<?php
}
