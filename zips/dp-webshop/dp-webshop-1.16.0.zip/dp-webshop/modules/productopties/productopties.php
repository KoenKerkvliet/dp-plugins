<?php
/**
 * Module Name: Productopties met meerprijs
 * Description: Opties bij een product die de prijs verhogen, zoals "Opvoeren naar 25 km/u (+€60)" als vinkje, "Accu: 20Ah / 40Ah (+€200)" als keuzelijst, of "Extra's: Inpakken (+€3,50) en Kaartje (+€1,50)" als meerdere vinkjes die de klant elk los aanvinkt. Instellen per product op het productgegevens-scherm, of één keer in de optiebibliotheek (Productgegevens → Opties) en dan per product aanvinken met de standaardprijs of een eigen bedrag. Bewerken kan ook direct in de FluentCart-producteditor (kaartje onder Prijzen). Het productscherm opent in de klassieke editor. Op de productpagina staan de opties boven de koopknop met een live totaalprijs; in winkelwagen, kassa, bestelling, mail en bon staat de gekozen optie bij het artikel. De meerprijs rekent de server zelf uit, nooit de browser.
 * Category: catalogus
 * Vervalt zodra: FluentCart zelf opties met een meerprijs per product heeft.
 * Version: 1.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_OPTIES_VERSION', '1.6.0' );
define( 'DP_WPO_META', 'dp_productopties' );

// Het productgegevens-scherm (klassiek bewerkscherm) is waar de opties worden ingesteld.
add_filter( 'fluent_cart/show_standalone_product_menu', '__return_true', 20 );

function dp_wpo_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_productopties', [
		'auto'             => 1, // blok vanzelf boven de koopknoppen
		'direct_verbergen' => 1, // "Direct kopen" verbergen bij producten met opties
		'totaal'           => 1, // live totaalprijs tonen
		'vinkjes_titel'    => 'Extra opties', // kop boven losse vinkjes (leeg = geen kop)
	] );
}

/* ------------------------------------------------------------------ */
/*  Configuratie                                                        */
/*  Per product (post-meta dp_productopties) een lijst groepen:         */
/*  [ id, label, uitleg, type vinkje|keuze, prijs (centen, vinkje),     */
/*    keuzes [ [ id, label, prijs ] ] (keuze; de eerste is standaard) ] */
/* ------------------------------------------------------------------ */

/** Centen uit een ingevoerd bedrag ("60", "60,00", "1.299", "1,234.50"). */
function dp_wpo_centen( $invoer ) {
	if ( is_int( $invoer ) ) {
		return max( 0, $invoer );
	}
	if ( str_contains( (string) $invoer, '-' ) ) {
		return 0; // een optie verhoogt de prijs; korting hoort hier niet
	}
	$p = preg_replace( '/[^\d,.]/', '', (string) $invoer );
	if ( $p === '' ) {
		return 0;
	}
	$komma = strrpos( $p, ',' );
	$punt  = strrpos( $p, '.' );
	if ( false !== $komma && false !== $punt ) {
		$decimaal = $komma > $punt ? ',' : '.';
		$p        = str_replace( $decimaal === ',' ? '.' : ',', '', $p );
		$p        = str_replace( $decimaal, '.', $p );
	} elseif ( false !== $komma ) {
		$p = str_replace( ',', '.', $p );
	} elseif ( preg_match( '/^\d{1,3}(\.\d{3})+$/', $p ) ) {
		$p = str_replace( '.', '', $p );
	}
	return max( 0, (int) round( (float) $p * 100 ) );
}

function dp_wpo_bedrag( $centen ) {
	return '€' . number_format_i18n( (int) $centen / 100, 2 );
}

/**
 * Soorten opties:
 *   vinkje   één vinkje met een prijs ("Opvoeren naar 25 km/u")
 *   keuze    keuzelijst: precies één van meerdere, de eerste is standaard ("Accu: 20Ah / 40Ah")
 *   meerdere meerdere vinkjes onder één kop, elk los aan te vinken ("Extra's: Inpakken, Kaartje")
 */
function dp_wpo_soort( $type ) {
	return in_array( $type, [ 'vinkje', 'keuze', 'meerdere' ], true ) ? $type : 'vinkje';
}

function dp_wpo_soort_naam( $type ) {
	return [ 'vinkje' => 'Vinkje', 'keuze' => 'Keuzelijst', 'meerdere' => 'Meerdere vinkjes' ][ dp_wpo_soort( $type ) ];
}

function dp_wpo_sleutel( $s ) {
	return substr( preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $s ) ), 0, 20 );
}

/**
 * Schoon een configuratie op. $uit_formulier: prijzen zijn dan ingevoerde bedragen in euro's.
 */
function dp_wpo_schoon( $groepen, $uit_formulier = false ) {
	$prijs = fn( $v ) => $uit_formulier ? dp_wpo_centen( (string) $v ) : max( 0, (int) $v );
	$uit   = [];
	$ids   = [];
	foreach ( (array) $groepen as $g ) {
		if ( ! is_array( $g ) ) {
			continue;
		}
		$id    = dp_wpo_sleutel( $g['id'] ?? '' );
		$label = sanitize_text_field( (string) ( $g['label'] ?? '' ) );
		if ( $id === '' || $label === '' || isset( $ids[ $id ] ) ) {
			continue;
		}
		$ids[ $id ] = true;
		$groep      = [
			'id'     => $id,
			'label'  => $label,
			'uitleg' => sanitize_text_field( (string) ( $g['uitleg'] ?? '' ) ),
			'type'   => dp_wpo_soort( $g['type'] ?? '' ),
			'prijs'  => 0,
			'keuzes' => [],
		];
		if ( $groep['type'] === 'vinkje' ) {
			$groep['prijs'] = $prijs( $g['prijs'] ?? 0 );
		} else {
			$kids = [];
			foreach ( (array) ( $g['keuzes'] ?? [] ) as $k ) {
				$kid    = dp_wpo_sleutel( $k['id'] ?? '' );
				$klabel = sanitize_text_field( (string) ( $k['label'] ?? '' ) );
				if ( $kid === '' || $klabel === '' || isset( $kids[ $kid ] ) ) {
					continue;
				}
				$kids[ $kid ]      = true;
				$groep['keuzes'][] = [ 'id' => $kid, 'label' => $klabel, 'prijs' => $prijs( $k['prijs'] ?? 0 ) ];
			}
			if ( ! $groep['keuzes'] ) {
				continue;
			}
		}
		$uit[] = $groep;
	}
	return $uit;
}

/** Opties die alleen bij dit product horen. */
function dp_wpo_eigen( $post_id ) {
	$cfg = get_post_meta( (int) $post_id, DP_WPO_META, true );
	return is_array( $cfg ) ? dp_wpo_schoon( $cfg ) : [];
}

/** Alle opties van een product: eerst die uit de bibliotheek, dan de eigen. */
function dp_wpo_config( $post_id ) {
	static $cache = [];
	$post_id = (int) $post_id;
	if ( ! $post_id ) {
		return [];
	}
	if ( ! isset( $cache[ $post_id ] ) ) {
		$cache[ $post_id ] = array_merge( dp_wpo_bieb_voor_product( $post_id ), dp_wpo_eigen( $post_id ) );
	}
	return $cache[ $post_id ];
}

/* ------------------------------------------------------------------ */
/*  Optiebibliotheek                                                    */
/*  Opties die bij veel producten terugkomen, één keer aangemaakt       */
/*  (berichttype dp_productoptie, onder Productgegevens → Opties, of   */
/*  FluentCart → Productopties zonder het Productgegevens-scherm).     */
/*  Per product (meta dp_productopties_bieb) staat welke aan staan,     */
/*  met eventueel een eigen prijs: [ [ id, prijs|null, keuzes          */
/*  [ keuze-id => prijs|null ] ] ]. Leeg (null) = de standaardprijs,    */
/*  zodat een nieuwe standaardprijs bij al die producten meegaat.       */
/* ------------------------------------------------------------------ */

define( 'DP_WPO_BIEB_TYPE', 'dp_productoptie' );
define( 'DP_WPO_BIEB_META', 'dp_productopties_bieb' );

add_action( 'init', function () {
	register_post_type( DP_WPO_BIEB_TYPE, [
		'labels'          => [
			'name'               => 'Opties',
			'singular_name'      => 'Optie',
			'menu_name'          => 'Opties',
			'all_items'          => 'Opties',
			'add_new'            => 'Nieuwe optie',
			'add_new_item'       => 'Nieuwe optie',
			'edit_item'          => 'Optie bewerken',
			'new_item'           => 'Nieuwe optie',
			'search_items'       => 'Opties zoeken',
			'not_found'          => 'Nog geen opties in de bibliotheek.',
			'not_found_in_trash' => 'Geen opties in de prullenbak.',
		],
		'description'     => 'Optiebibliotheek van DP Webshop: opties met meerprijs voor meerdere producten.',
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => dp_wpo_onder_productgegevens() ? 'edit.php?post_type=fluent-products' : false,
		'show_in_rest'    => false, // daarmee altijd de klassieke editor
		'supports'        => [ 'title' ],
		'capability_type' => 'post',
		'map_meta_cap'    => true,
		'rewrite'         => false,
		'query_var'       => false,
	] );
}, 20 );

/*
 * Het menu Productgegevens bestaat alleen met de module Productgegevens-scherm. Zonder die
 * module staat de bibliotheek onder FluentCart, als laatste item (vooraan zou het de link van
 * het FluentCart-menu zelf overnemen).
 */
function dp_wpo_onder_productgegevens() {
	return function_exists( 'dp_wpb_aan' ) && dp_wpb_aan( 'menu_tonen' );
}

add_action( 'admin_menu', function () {
	if ( ! dp_wpo_onder_productgegevens() ) {
		add_submenu_page( 'fluent-cart', 'Productopties', 'Productopties', 'edit_posts', 'edit.php?post_type=' . DP_WPO_BIEB_TYPE );
	}
}, 99 );

add_filter( 'parent_file', function ( $parent_file ) {
	global $submenu_file;
	$scherm = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $scherm && $scherm->post_type === DP_WPO_BIEB_TYPE && ! dp_wpo_onder_productgegevens() ) {
		$submenu_file = 'edit.php?post_type=' . DP_WPO_BIEB_TYPE; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		return 'fluent-cart';
	}
	return $parent_file;
} );

/*
 * Klassieke editor op het productscherm: de opties staan daar in een eigen blok, en dat werkt
 * in de smalle Gutenberg-balk onderaan slecht. Staat de module Productgegevens-scherm aan, dan
 * beslist zijn eigen instelling (die staat standaard ook op klassiek).
 */
add_filter( 'use_block_editor_for_post_type', function ( $gebruik, $post_type ) {
	return ( $post_type === 'fluent-products' && ! function_exists( 'dp_wpb_aan' ) ) ? false : $gebruik;
}, 20, 2 );

/** Definitie van een bibliotheekoptie als groep (zelfde vorm als eigen opties), of null. */
function dp_wpo_bieb_def( $optie_id ) {
	static $cache = [];
	$optie_id = (int) $optie_id;
	if ( ! array_key_exists( $optie_id, $cache ) ) {
		$p = $optie_id ? get_post( $optie_id ) : null;
		if ( ! $p || $p->post_type !== DP_WPO_BIEB_TYPE || $p->post_status !== 'publish' ) {
			$cache[ $optie_id ] = null;
		} else {
			$d                  = (array) get_post_meta( $optie_id, 'dp_po_def', true );
			$groep              = dp_wpo_schoon( [ [
				'id'     => 'b' . $optie_id,
				'label'  => $p->post_title,
				'uitleg' => $d['uitleg'] ?? '',
				'type'   => $d['type'] ?? 'vinkje',
				'prijs'  => (int) ( $d['prijs'] ?? 0 ),
				'keuzes' => $d['keuzes'] ?? [],
			] ] );
			$cache[ $optie_id ] = $groep ? $groep[0] + [ 'bieb' => $optie_id ] : null;
		}
	}
	return $cache[ $optie_id ];
}

/** Alle gepubliceerde bibliotheekopties. */
function dp_wpo_bieb_alle() {
	$uit = [];
	foreach ( get_posts( [ 'post_type' => DP_WPO_BIEB_TYPE, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'fields' => 'ids' ] ) as $id ) {
		$def = dp_wpo_bieb_def( $id );
		if ( $def ) {
			$uit[] = $def;
		}
	}
	return $uit;
}

/** Keuze van een product uit de bibliotheek (opgeschoond). */
function dp_wpo_bieb_keuze( $post_id ) {
	$lijst = get_post_meta( (int) $post_id, DP_WPO_BIEB_META, true );
	return is_array( $lijst ) ? $lijst : [];
}

/**
 * Schoon een bibliotheekkeuze op. $uit_formulier: prijzen zijn ingevoerde bedragen; leeg = standaardprijs.
 */
function dp_wpo_bieb_schoon( $lijst, $uit_formulier = false ) {
	$bedrag = function ( $v ) use ( $uit_formulier ) {
		if ( $v === null || $v === '' ) {
			return null;
		}
		return $uit_formulier ? dp_wpo_centen( (string) $v ) : max( 0, (int) $v );
	};
	$uit = [];
	$ids = [];
	foreach ( (array) $lijst as $k ) {
		$id = (int) ( is_array( $k ) ? ( $k['id'] ?? 0 ) : $k );
		$p  = $id ? get_post( $id ) : null;
		// Alleen echt verwijderde opties vallen weg. Staat een optie tijdelijk op concept,
		// dan blijft hij bij het product bewaard (maar wordt pas weer getoond als hij gepubliceerd is).
		if ( ! $p || $p->post_type !== DP_WPO_BIEB_TYPE || $p->post_status === 'trash' || isset( $ids[ $id ] ) ) {
			continue;
		}
		$ids[ $id ] = true;
		$def        = dp_wpo_bieb_def( $id );
		$rij        = [ 'id' => $id, 'prijs' => $bedrag( is_array( $k ) ? ( $k['prijs'] ?? null ) : null ), 'keuzes' => [] ];
		$opgegeven  = is_array( $k ) ? (array) ( $k['keuzes'] ?? [] ) : [];
		$bekend     = $def ? array_column( $def['keuzes'], 'id' ) : array_keys( $opgegeven );
		foreach ( $bekend as $kid ) {
			$o = $bedrag( $opgegeven[ $kid ] ?? null );
			if ( null !== $o ) {
				$rij['keuzes'][ dp_wpo_sleutel( $kid ) ] = $o;
			}
		}
		if ( $def && $def['type'] !== 'vinkje' ) {
			$rij['prijs'] = null; // keuzelijst of meerdere vinkjes: prijs per keuze
		}
		$uit[] = $rij;
	}
	return $uit;
}

/** De bibliotheekopties van een product als groepen, met de prijs voor dit product. */
function dp_wpo_bieb_voor_product( $post_id ) {
	$uit = [];
	foreach ( dp_wpo_bieb_keuze( $post_id ) as $k ) {
		$def = dp_wpo_bieb_def( (int) ( $k['id'] ?? 0 ) );
		if ( ! $def ) {
			continue; // uit de bibliotheek gehaald of nog concept
		}
		if ( $def['type'] === 'vinkje' && isset( $k['prijs'] ) && null !== $k['prijs'] ) {
			$def['prijs'] = max( 0, (int) $k['prijs'] );
		}
		if ( $def['type'] !== 'vinkje' ) {
			foreach ( $def['keuzes'] as $i => $kz ) {
				if ( isset( $k['keuzes'][ $kz['id'] ] ) && null !== $k['keuzes'][ $kz['id'] ] ) {
					$def['keuzes'][ $i ]['prijs'] = max( 0, (int) $k['keuzes'][ $kz['id'] ] );
				}
			}
		}
		$uit[] = $def;
	}
	return $uit;
}

/** Producten die een bibliotheekoptie gebruiken: [ optie-id => [ product-id, ... ] ]. */
function dp_wpo_bieb_gebruik() {
	global $wpdb;
	static $kaart = null;
	if ( null === $kaart ) {
		$kaart = [];
		$rijen = $wpdb->get_results( $wpdb->prepare(
			"SELECT m.post_id, m.meta_value FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id AND p.post_status <> 'trash' WHERE m.meta_key = %s",
			DP_WPO_BIEB_META
		) );
		foreach ( (array) $rijen as $r ) {
			foreach ( (array) maybe_unserialize( $r->meta_value ) as $k ) {
				$kaart[ (int) ( $k['id'] ?? 0 ) ][] = (int) $r->post_id;
			}
		}
	}
	return $kaart;
}

/** Bibliotheekoptie toevoegen aan of weghalen bij producten. Geeft het aantal gewijzigde producten. */
function dp_wpo_bieb_toewijzen( $optie_id, array $product_ids, $toevoegen = true ) {
	$optie_id = (int) $optie_id;
	if ( ! dp_wpo_bieb_def( $optie_id ) ) {
		return 0;
	}
	$n = 0;
	foreach ( array_unique( array_map( 'intval', $product_ids ) ) as $pid ) {
		if ( get_post_type( $pid ) !== 'fluent-products' || ! current_user_can( 'edit_post', $pid ) ) {
			continue;
		}
		$lijst = dp_wpo_bieb_keuze( $pid );
		$heeft = in_array( $optie_id, array_map( fn( $k ) => (int) ( $k['id'] ?? 0 ), $lijst ), true );
		if ( $toevoegen && ! $heeft ) {
			$lijst[] = [ 'id' => $optie_id, 'prijs' => null, 'keuzes' => [] ];
		} elseif ( ! $toevoegen && $heeft ) {
			$lijst = array_values( array_filter( $lijst, fn( $k ) => (int) ( $k['id'] ?? 0 ) !== $optie_id ) );
		} else {
			continue;
		}
		$lijst ? update_post_meta( $pid, DP_WPO_BIEB_META, dp_wpo_bieb_schoon( $lijst ) ) : delete_post_meta( $pid, DP_WPO_BIEB_META );
		$n++;
	}
	return $n;
}

/**
 * Keuze → [ meerprijs in centen, attributen voor FluentCart ].
 * $keuze = [ groep-id => '1' (vinkje aan) | keuze-id | [ keuze-id, ... ] (meerdere vinkjes) ].
 * Onbekende of ontbrekende keuzes: vinkje uit, keuzelijst de eerste (standaard) keuze,
 * meerdere vinkjes alle uit.
 */
function dp_wpo_bereken( $post_id, $keuze ) {
	$keuze = is_array( $keuze ) ? $keuze : [];
	$meer  = 0;
	$attrs = [];
	foreach ( dp_wpo_config( $post_id ) as $g ) {
		$gekozen = $keuze[ $g['id'] ] ?? null;
		if ( $g['type'] === 'vinkje' ) {
			if ( empty( $gekozen ) ) {
				continue;
			}
			$prijs  = $g['prijs'];
			$waarde = 'Ja';
			$slug   = '1';
		} elseif ( $g['type'] === 'meerdere' ) {
			// Uit de browser een lijst, uit het mandje een tekst "a,b".
			$ids   = is_array( $gekozen ) ? array_map( 'strval', $gekozen ) : array_filter( explode( ',', (string) $gekozen ) );
			$aan   = array_values( array_filter( $g['keuzes'], fn( $kk ) => in_array( $kk['id'], $ids, true ) ) );
			if ( ! $aan ) {
				continue;
			}
			$prijs = array_sum( array_column( $aan, 'prijs' ) );
			$meer += $prijs;
			$attrs[ 'dp_po_' . $g['id'] ] = [
				'value' => implode( ', ', array_map( fn( $kk ) => $kk['label'] . ( $kk['prijs'] ? ' (+' . dp_wpo_bedrag( $kk['prijs'] ) . ')' : '' ), $aan ) ),
				'slug'  => implode( ',', array_column( $aan, 'id' ) ),
				'title' => $g['label'],
				'prijs' => $prijs,
			];
			continue;
		} else {
			$k = $g['keuzes'][0];
			foreach ( $g['keuzes'] as $kk ) {
				if ( $kk['id'] === (string) $gekozen ) {
					$k = $kk;
				}
			}
			$prijs  = $k['prijs'];
			$waarde = $k['label'];
			$slug   = $k['id'];
		}
		$meer += $prijs;
		// Sleutel zonder pa_: FluentCart behandelt dit als eigenschap van een andere plugin
		// en toont hem in winkelwagen, kassa, bestelling, mail en bon.
		$attrs[ 'dp_po_' . $g['id'] ] = [
			'value' => $waarde . ( $prijs ? ' (+' . dp_wpo_bedrag( $prijs ) . ')' : '' ),
			'slug'  => $slug,
			'title' => $g['label'],
			'prijs' => $prijs,
		];
	}
	return [ $meer, $attrs ];
}

/* ------------------------------------------------------------------ */
/*  Winkelwagen                                                         */
/*  De browser zet de keuze in een koekje (dp_po_<product>) zodra de    */
/*  klant iets kiest; dat gaat vanzelf mee met "In winkelwagen", hoe    */
/*  FluentCart dat verzoek ook verstuurt. Bij een latere wijziging (bv. */
/*  aantal) nemen we de keuze over van het artikel dat al in het mandje */
/*  zit, anders zou de meerprijs wegvallen.                             */
/* ------------------------------------------------------------------ */

function dp_wpo_keuze_uit_koekje( $post_id ) {
	$naam = 'dp_po_' . (int) $post_id;
	if ( ! isset( $_COOKIE[ $naam ] ) ) {
		return null;
	}
	$data = json_decode( wp_unslash( (string) $_COOKIE[ $naam ] ), true );
	return is_array( $data ) ? $data : null;
}

function dp_wpo_koekje_wissen( $post_id ) {
	$naam = 'dp_po_' . (int) $post_id;
	unset( $_COOKIE[ $naam ] );
	if ( ! headers_sent() ) {
		setcookie( $naam, '', [ 'expires' => time() - 3600, 'path' => '/', 'samesite' => 'Lax', 'secure' => is_ssl() ] );
	}
}

function dp_wpo_keuze_uit_mandje( $variant_id ) {
	if ( ! class_exists( '\FluentCart\App\Helpers\CartHelper' ) ) {
		return null;
	}
	$cart = \FluentCart\App\Helpers\CartHelper::getCart();
	foreach ( (array) ( $cart ? $cart->cart_data : [] ) as $item ) {
		if ( (int) ( $item['object_id'] ?? 0 ) !== (int) $variant_id ) {
			continue;
		}
		$keuze = [];
		foreach ( (array) ( $item['other_info']['item_attributes'] ?? [] ) as $sleutel => $attr ) {
			if ( strpos( (string) $sleutel, 'dp_po_' ) === 0 ) {
				$keuze[ substr( $sleutel, 6 ) ] = (string) ( $attr['slug'] ?? '' );
			}
		}
		return $keuze;
	}
	return null;
}

add_filter( 'fluent_cart/cart/item_modify', function ( $variation, $args ) {
	if ( ! $variation || empty( $variation->post_id ) ) {
		return $variation;
	}
	$post_id = (int) $variation->post_id;
	if ( ! dp_wpo_config( $post_id ) ) {
		return $variation;
	}
	$keuze = dp_wpo_keuze_uit_koekje( $post_id );
	if ( null !== $keuze ) {
		dp_wpo_koekje_wissen( $post_id ); // eenmalig: daarna geldt wat in het mandje staat
	} else {
		$keuze = dp_wpo_keuze_uit_mandje( (int) $variation->id );
	}
	[ $meer, $attrs ] = dp_wpo_bereken( $post_id, $keuze );

	$GLOBALS['dp_wpo_wacht'][ (int) $variation->id ] = $attrs;
	if ( ! $meer ) {
		return $variation;
	}
	$v             = clone $variation;
	$v->item_price = (int) $variation->item_price + $meer;
	return $v;
}, 10, 2 );

// FluentCart legt bij het toevoegen de eigenschappen van het artikel vast; hier komen de opties erbij.
add_filter( 'fluent_cart/item_attributes', function ( $atts, $ctx ) {
	$vid = (int) ( $ctx['variation_id'] ?? 0 );
	if ( $vid && ! empty( $GLOBALS['dp_wpo_wacht'][ $vid ] ) ) {
		$atts = array_merge( (array) $atts, $GLOBALS['dp_wpo_wacht'][ $vid ] );
	}
	return $atts;
}, 10, 2 );

/** Opgeslagen eigenschappen van een artikel (winkelwagen-array of bestelregel). */
function dp_wpo_item_attrs( $item ) {
	$other = is_object( $item ) ? ( $item->other_info ?? [] ) : ( $item['other_info'] ?? [] );
	if ( is_string( $other ) ) {
		$other = json_decode( $other, true );
	}
	return (array) ( $other['item_attributes'] ?? [] );
}

// Weergave: de naam van de optiegroep in plaats van de sleutel.
add_filter( 'fluent_cart/item_display_attr', function ( $rijen, $ctx ) {
	$attrs = null;
	foreach ( (array) $rijen as $sleutel => $rij ) {
		if ( strpos( (string) $sleutel, 'dp_po_' ) !== 0 ) {
			continue;
		}
		$attrs = $attrs ?? dp_wpo_item_attrs( $ctx['item'] ?? null );
		$rijen[ $sleutel ]['display_title'] = (string) ( $attrs[ $sleutel ]['title'] ?? ucfirst( substr( $sleutel, 6 ) ) );
	}
	return $rijen;
}, 10, 2 );

function dp_wpo_regels( $item ) {
	$regels = [];
	foreach ( dp_wpo_item_attrs( $item ) as $sleutel => $attr ) {
		if ( strpos( (string) $sleutel, 'dp_po_' ) === 0 && ! empty( $attr['value'] ) ) {
			$regels[] = ( $attr['title'] ?? '' ) !== '' ? $attr['title'] . ': ' . $attr['value'] : $attr['value'];
		}
	}
	return $regels;
}

// Bij een product zonder varianten verbergt FluentCart de variantregel in de winkelwagen; zet de opties er dan zelf onder.
add_action( 'fluent_cart/cart/line_item/line_meta', function ( $info ) {
	$item = (array) ( $info['item'] ?? [] );
	if ( ( $item['variation_type'] ?? '' ) !== 'simple' ) {
		return;
	}
	$regels = dp_wpo_regels( $item );
	if ( ! $regels ) {
		return;
	}
	static $stijl = false;
	if ( ! $stijl ) {
		$stijl = true;
		// Op de kassa toont FluentCart de opties zelf al in de (zichtbare) variantregel: dan de onze niet.
		echo '<style>.dp-po-regel{margin:2px 0 0;font-size:.85em;opacity:.8}.fct_item_content:has(.fct_item_variant_title)>.dp-po-regel{display:none}</style>';
	}
	echo '<p class="dp-po-regel">' . esc_html( implode( ' · ', $regels ) ) . '</p>';
} );

/* ------------------------------------------------------------------ */
/*  Productpagina                                                       */
/* ------------------------------------------------------------------ */

function dp_wpo_varianten( $post_id ) {
	global $wpdb;
	$rijen = $wpdb->get_results( $wpdb->prepare(
		"SELECT id, item_price FROM {$wpdb->prefix}fct_product_variations WHERE post_id = %d ORDER BY serial_index, id",
		(int) $post_id
	) );
	$uit = [];
	foreach ( (array) $rijen as $r ) {
		$uit[ (int) $r->id ] = (int) $r->item_price;
	}
	return $uit;
}

function dp_wpo_blok( $post_id ) {
	static $gedaan = [];
	/*
	 * Soms bouwt iets in de <head> een samenvatting van de productpagina (bv. voor een
	 * SEO-omschrijving): wp_head → get_the_excerpt → the_content, en dan rendert FluentCart
	 * daarin ook de koopsectie. Die uitvoer wordt weggegooid. Daar niets tonen en vooral niet
	 * als "al getoond" tellen, anders ontbreekt het blok bij de echte weergave.
	 */
	if ( doing_action( 'wp_head' ) || doing_filter( 'get_the_excerpt' ) ) {
		return '';
	}
	$post_id = (int) $post_id;
	$cfg     = dp_wpo_config( $post_id );
	if ( ! $cfg || isset( $gedaan[ $post_id ] ) ) {
		return '';
	}
	$gedaan[ $post_id ]      = true;
	$GLOBALS['dp_wpo_script'] = true;
	$s                       = dp_wpo_instellingen();
	$varianten               = dp_wpo_varianten( $post_id );

	ob_start();
	?>
	<div class="dp-po" data-dp-po data-product="<?php echo (int) $post_id; ?>" data-varianten="<?php echo esc_attr( wp_json_encode( (object) $varianten ) ); ?>">
		<?php
		$i = 0;
		$n = count( $cfg );
		while ( $i < $n ) :
			$g    = $cfg[ $i ];
			$veld = 'dp-po-' . $post_id . '-' . $g['id'];
			if ( $g['type'] === 'vinkje' ) :
				// Losse vinkjes na elkaar vormen samen één lijst, met een kop zoals de keuzegroepen hebben.
				$kop = trim( (string) ( $s['vinkjes_titel'] ?? '' ) );
				if ( $kop !== '' ) {
					$kop_id = 'dp-po-' . $post_id . '-extra-' . $i;
					echo '<div class="dp-po-groep dp-po-groep--vinkje"><span class="dp-po-label" id="' . esc_attr( $kop_id ) . '">' . esc_html( $kop ) . '</span><div class="dp-po-lijst" role="group" aria-labelledby="' . esc_attr( $kop_id ) . '">';
				} else {
					echo '<div class="dp-po-groep dp-po-groep--vinkje"><div class="dp-po-lijst">';
				}
				while ( $i < $n && $cfg[ $i ]['type'] === 'vinkje' ) {
					$v = $cfg[ $i ];
					echo dp_wpo_rij( 'checkbox', 'dp-po-' . $post_id . '-' . $v['id'], '', '1', [ 'data-groep' => $v['id'], 'data-prijs' => (int) $v['prijs'] ], $v['label'], $v['prijs'], $v['uitleg'] ); // phpcs:ignore WordPress.Security.EscapeOutput
					$i++;
				}
				echo '</div></div>';
				continue;
			endif;
			$i++;
			// Een keuzelijst met weinig keuzes als rondjes: rustiger, en alle prijzen in één oogopslag.
			$rondjes = $g['type'] === 'keuze' && count( $g['keuzes'] ) <= (int) apply_filters( 'dp_webshop_productopties_rondjes_max', 5 );
		?>
			<div class="dp-po-groep dp-po-groep--<?php echo esc_attr( $g['type'] ); ?>">
				<?php if ( $g['type'] === 'meerdere' || $rondjes ) : ?>
					<span class="dp-po-label" id="<?php echo esc_attr( $veld ); ?>-kop"><?php echo esc_html( $g['label'] ); ?></span>
					<div class="dp-po-lijst" role="<?php echo $rondjes ? 'radiogroup' : 'group'; ?>" aria-labelledby="<?php echo esc_attr( $veld ); ?>-kop">
						<?php
						foreach ( $g['keuzes'] as $nr => $k ) {
							$data = [ 'data-groep' => $g['id'], 'data-prijs' => (int) $k['prijs'] ];
							if ( $rondjes ) {
								echo dp_wpo_rij( 'radio', $veld . '-' . $k['id'], $veld, $k['id'], $data, $k['label'], $k['prijs'], '', $nr === 0 ); // phpcs:ignore WordPress.Security.EscapeOutput
							} else {
								echo dp_wpo_rij( 'checkbox', $veld . '-' . $k['id'], '', '1', $data + [ 'data-keuze' => $k['id'] ], $k['label'], $k['prijs'] ); // phpcs:ignore WordPress.Security.EscapeOutput
							}
						}
						?>
					</div>
				<?php else : ?>
					<label class="dp-po-label" for="<?php echo esc_attr( $veld ); ?>"><?php echo esc_html( $g['label'] ); ?></label>
					<div class="dp-po-kies">
						<select id="<?php echo esc_attr( $veld ); ?>" data-groep="<?php echo esc_attr( $g['id'] ); ?>">
							<?php foreach ( $g['keuzes'] as $k ) : ?>
								<option value="<?php echo esc_attr( $k['id'] ); ?>" data-prijs="<?php echo (int) $k['prijs']; ?>"><?php echo esc_html( $k['label'] . ( $k['prijs'] ? ' (+' . dp_wpo_bedrag( $k['prijs'] ) . ')' : '' ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>
				<?php if ( $g['uitleg'] !== '' ) : ?><p class="dp-po-uitleg"><?php echo esc_html( $g['uitleg'] ); ?></p><?php endif; ?>
			</div>
		<?php endwhile; ?>
		<?php if ( ! empty( $s['totaal'] ) ) : ?>
			<div class="dp-po-totaal" hidden>
				<span class="dp-po-totaal-label">Totaal</span>
				<span class="dp-po-totaal-bedrag"><strong></strong><span class="dp-po-meer"></span></span>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $s['direct_verbergen'] ) && $varianten ) :
			$selectors = array_map( fn( $id ) => '[data-fluent-cart-direct-checkout-button][data-cart-id="' . (int) $id . '"]', array_keys( $varianten ) );
		?>
			<style><?php echo implode( ',', $selectors ); // phpcs:ignore WordPress.Security.EscapeOutput ?>{display:none!important}</style>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/** Eén regel in een optielijst: vinkje of rondje, naam (met uitleg) en meerprijs rechts. */
function dp_wpo_rij( $soort, $id, $naam, $waarde, array $data, $label, $prijs, $uitleg = '', $aan = false ) {
	$attrs = '';
	foreach ( $data as $sleutel => $w ) {
		$attrs .= ' ' . $sleutel . '="' . esc_attr( $w ) . '"';
	}
	return sprintf(
		'<label class="dp-po-rij" for="%1$s"><input type="%2$s" id="%1$s"%3$s value="%4$s"%5$s%6$s><span class="dp-po-tekst"><span class="dp-po-naam">%7$s</span>%8$s</span>%9$s</label>',
		esc_attr( $id ),
		$soort === 'radio' ? 'radio' : 'checkbox',
		$naam !== '' ? ' name="' . esc_attr( $naam ) . '"' : '',
		esc_attr( $waarde ),
		$attrs,
		$aan ? ' checked' : '',
		esc_html( $label ),
		$uitleg !== '' ? '<span class="dp-po-uitleg">' . esc_html( $uitleg ) . '</span>' : '',
		$prijs ? '<span class="dp-po-prijs">+' . esc_html( dp_wpo_bedrag( $prijs ) ) . '</span>' : ''
	);
}

/** Product-ID uit de context die FluentCart aan de koopknop-haak meegeeft. */
function dp_wpo_product_uit_context( $ctx ) {
	$product = is_array( $ctx ) ? ( $ctx['product'] ?? null ) : ( is_object( $ctx ) ? ( $ctx->product ?? null ) : null );
	if ( is_object( $product ) && ! empty( $product->ID ) ) {
		return (int) $product->ID;
	}
	return (int) get_the_ID();
}

add_action( 'fluent_cart/product/single/before_actions_block', function ( $ctx ) {
	if ( ! empty( dp_wpo_instellingen()['auto'] ) ) {
		echo dp_wpo_blok( dp_wpo_product_uit_context( $ctx ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
} );

add_shortcode( 'dp_productopties', function ( $atts ) {
	$atts = shortcode_atts( [ 'id' => 0 ], $atts );
	return dp_wpo_blok( (int) $atts['id'] ?: (int) get_the_ID() );
} );

add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['dp_wpo_script'] ) ) {
		return;
	}
	?>
	<style id="dp-webshop-productopties">
		/*
		 * De koopknoppen staan in een grid of flexrij; de opties nemen daar de volle breedte.
		 * Kleuren volgen het thema: accent = FluentCart-knopkleur (of --primary), tekst erft.
		 */
		.dp-po { --dp-po-accent: var(--fct-primary-bg-color, var(--primary, #1f6feb)); --dp-po-lijn: var(--fct-border-color, rgba(20, 30, 50, .14)); --dp-po-hoek: 4px;
			display: flex; flex-direction: column; gap: 20px; margin: 4px 0 8px; width: 100%; grid-column: 1 / -1; flex: 0 0 100%; box-sizing: border-box; }
		.dp-po-groep { display: flex; flex-direction: column; gap: 8px; }
		.dp-po-label { font-size: .75em; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; opacity: .6; }
		.dp-po-lijst { display: flex; flex-direction: column; border: 1px solid var(--dp-po-lijn); border-radius: var(--dp-po-hoek); background: #fff; overflow: hidden; }
		.dp-po-rij { display: flex; align-items: center; gap: 14px; margin: 0; padding: 14px 16px; cursor: pointer; transition: background-color .15s ease; }
		.dp-po-rij + .dp-po-rij { border-top: 1px solid var(--dp-po-lijn); }
		.dp-po-rij:hover { background: rgba(20, 30, 50, .025); }
		.dp-po-rij:has(input:checked) { background: rgba(20, 30, 50, .03); background: color-mix(in srgb, var(--dp-po-accent) 6%, #fff); }
		.dp-po-rij input { appearance: none; -webkit-appearance: none; flex: 0 0 auto; display: grid; place-content: center; width: 20px; height: 20px; margin: 0; padding: 0; border: 1.5px solid rgba(20, 30, 50, .3); border-radius: 3px; background: #fff; cursor: pointer; transition: border-color .15s ease, background-color .15s ease; }
		.dp-po-rij input[type=radio] { border-radius: 50%; }
		.dp-po-rij:hover input:not(:checked) { border-color: rgba(20, 30, 50, .5); }
		.dp-po-rij input::after { content: ""; }
		.dp-po-rij input[type=checkbox]:checked { border-color: var(--dp-po-accent); background: var(--dp-po-accent); }
		.dp-po-rij input[type=checkbox]:checked::after { width: 10px; height: 5px; border: solid #fff; border-width: 0 0 2px 2px; transform: translateY(-1px) rotate(-45deg); }
		.dp-po-rij input[type=radio]:checked { border-color: var(--dp-po-accent); }
		.dp-po-rij input[type=radio]:checked::after { width: 10px; height: 10px; border-radius: 50%; background: var(--dp-po-accent); }
		.dp-po-rij input:focus-visible, .dp-po select:focus-visible { outline: 2px solid var(--dp-po-accent); outline-offset: 2px; }
		.dp-po-tekst { flex: 1; display: flex; flex-direction: column; gap: 2px; min-width: 0; }
		.dp-po-naam { font-weight: 500; line-height: 1.35; }
		.dp-po-prijs { white-space: nowrap; font-size: .95em; font-variant-numeric: tabular-nums; opacity: .65; transition: opacity .15s ease; }
		.dp-po-rij:has(input:checked) .dp-po-prijs { opacity: 1; }
		.dp-po-uitleg { margin: 0; font-size: .85em; line-height: 1.4; opacity: .6; }
		.dp-po-kies { position: relative; }
		.dp-po-kies::after { content: ""; position: absolute; top: 50%; right: 18px; width: 7px; height: 7px; border: solid currentColor; border-width: 0 1.5px 1.5px 0; opacity: .55; transform: translateY(-70%) rotate(45deg); pointer-events: none; }
		.dp-po select { appearance: none; -webkit-appearance: none; width: 100%; min-height: 50px; margin: 0; padding: 0 44px 0 16px; border: 1px solid var(--dp-po-lijn); border-radius: var(--dp-po-hoek); background: #fff; color: inherit; font: inherit; cursor: pointer; }
		.dp-po-totaal { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; margin: 0; padding-top: 16px; border-top: 1px solid var(--dp-po-lijn); }
		.dp-po-totaal[hidden] { display: none; }
		.dp-po-totaal-label { opacity: .7; }
		.dp-po-totaal-bedrag { display: flex; flex-direction: column; align-items: flex-end; text-align: right; }
		.dp-po-totaal strong { font-size: 1.3em; font-weight: 600; font-variant-numeric: tabular-nums; }
		.dp-po-meer { font-size: .8em; opacity: .6; }
		.dp-po-meer:empty { display: none; }
		.dp-po-regel { margin: 2px 0 0; font-size: .85em; opacity: .8; }
	</style>
	<script id="dp-webshop-productopties-js">
	(function () {
		function euro(c) { return '€' + (c / 100).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
		document.querySelectorAll('[data-dp-po]').forEach(function (blok) {
			var pid = blok.getAttribute('data-product');
			var varianten = {};
			try { varianten = JSON.parse(blok.getAttribute('data-varianten') || '{}'); } catch (e) {}
			var knop = document.querySelector('[data-fluent-cart-add-to-cart-button][data-product-id="' + pid + '"]');
			function variant() { return knop && knop.getAttribute('data-cart-id') ? knop.getAttribute('data-cart-id') : Object.keys(varianten)[0]; }
			// Aantal uit het hoeveelheid-veld van FluentCart (er staat er één op de productpagina).
			function aantal() {
				var q = document.querySelector('[data-fluent-cart-single-product-page-product-quantity-input]');
				var n = q ? parseInt(q.value, 10) : 1;
				return n > 0 ? n : 1;
			}
			function bijwerken() {
				var keuze = {}, meer = 0;
				blok.querySelectorAll('[data-groep]').forEach(function (el) {
					var groep = el.getAttribute('data-groep');
					if (el.type === 'checkbox' && el.hasAttribute('data-keuze')) {
						// Meerdere vinkjes: een lijst met de aangevinkte onderdelen.
						if (el.checked) { (keuze[groep] = keuze[groep] || []).push(el.getAttribute('data-keuze')); meer += +el.getAttribute('data-prijs') || 0; }
					} else if (el.type === 'checkbox') {
						if (el.checked) { keuze[groep] = '1'; meer += +el.getAttribute('data-prijs') || 0; }
					} else if (el.type === 'radio') {
						// Keuzelijst als rondjes: alleen het aangevinkte rondje telt.
						if (el.checked) { keuze[groep] = el.value; meer += +el.getAttribute('data-prijs') || 0; }
					} else {
						keuze[el.getAttribute('data-groep')] = el.value;
						var o = el.options[el.selectedIndex];
						meer += +(o && o.getAttribute('data-prijs')) || 0;
					}
				});
				// Het koekje gaat vanzelf mee met "In winkelwagen"; de server rekent de meerprijs zelf uit.
				document.cookie = 'dp_po_' + pid + '=' + encodeURIComponent(JSON.stringify(keuze)) + '; path=/; max-age=7200; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
				var totaal = blok.querySelector('.dp-po-totaal');
				var basis = varianten[variant()];
				if (totaal && basis !== undefined) {
					var n = aantal(), stuk = basis + meer, regels = [];
					if (n > 1) { regels.push(n + ' × ' + euro(stuk)); }
					if (meer) { regels.push('incl. ' + euro(meer) + ' voor opties' + (n > 1 ? ' per stuk' : '')); }
					totaal.querySelector('strong').textContent = euro(stuk * n);
					totaal.querySelector('.dp-po-meer').textContent = regels.join(' · ');
					totaal.hidden = false;
				}
			}
			blok.addEventListener('change', bijwerken);
			// Aantal: typen in het veld, of de min/plus van FluentCart (die zet de waarde zelf, zonder
			// event; daarom na de klik even laten afronden).
			document.addEventListener('input', function (e) {
				if (e.target.matches && e.target.matches('[data-fluent-cart-single-product-page-product-quantity-input]')) { bijwerken(); }
			});
			document.addEventListener('change', function (e) {
				if (e.target.matches && e.target.matches('[data-fluent-cart-single-product-page-product-quantity-input]')) { bijwerken(); }
			});
			document.addEventListener('click', function (e) {
				if (e.target.closest && e.target.closest('[data-fluent-cart-product-qty-increase-button], [data-fluent-cart-product-qty-decrease-button]')) { setTimeout(bijwerken, 0); }
			});
			if (knop) {
				new MutationObserver(bijwerken).observe(knop, { attributes: true, attributeFilter: ['data-cart-id'] });
				knop.addEventListener('click', bijwerken, true);
			}
			bijwerken();
		});
	})();
	</script>
	<?php
}, 5 );

/* ------------------------------------------------------------------ */
/*  Beheer: opties per product                                          */
/* ------------------------------------------------------------------ */

add_action( 'add_meta_boxes_fluent-products', function () {
	add_meta_box( 'dp-productopties', 'Productopties met meerprijs', 'dp_wpo_metabox', 'fluent-products', 'normal', 'high' );
} );

/** Bedrag in centen → invoerwaarde ("60,00"), of leeg. */
function dp_wpo_invoer( $centen ) {
	return ( null === $centen || '' === $centen ) ? '' : number_format( (int) $centen / 100, 2, ',', '' );
}

function dp_wpo_metabox( $post ) {
	$cfg = dp_wpo_eigen( $post->ID );
	// Voor het formulier: prijzen als bedrag in euro's.
	$formulier = array_map( function ( $g ) {
		$g['prijs']  = $g['prijs'] ? dp_wpo_invoer( $g['prijs'] ) : '';
		$g['keuzes'] = array_map( function ( $k ) {
			$k['prijs'] = $k['prijs'] ? dp_wpo_invoer( $k['prijs'] ) : '';
			return $k;
		}, $g['keuzes'] );
		return $g;
	}, $cfg );

	// Bibliotheek: alle opties, en wat dit product ervan gebruikt (prijzen als invoer; leeg = standaard).
	$bieb = array_map( fn( $d ) => [
		'id'     => $d['bieb'],
		'naam'   => $d['label'],
		'type'   => $d['type'],
		'prijs'  => dp_wpo_bedrag( $d['prijs'] ),
		'keuzes' => array_map( fn( $k ) => [ 'id' => $k['id'], 'label' => $k['label'], 'prijs' => dp_wpo_bedrag( $k['prijs'] ) ], $d['keuzes'] ),
	], dp_wpo_bieb_alle() );
	$gekozen = array_map( fn( $k ) => [
		'id'     => (int) $k['id'],
		'prijs'  => dp_wpo_invoer( $k['prijs'] ?? null ),
		'keuzes' => (object) array_map( 'dp_wpo_invoer', (array) ( $k['keuzes'] ?? [] ) ),
	], dp_wpo_bieb_keuze( $post->ID ) );

	wp_nonce_field( 'dp_wpo_opslaan', 'dp_wpo_nonce' );
	?>
	<h4 style="margin:4px 0 6px;">Uit de optiebibliotheek</h4>
	<?php if ( ! $bieb ) : ?>
		<p style="margin-top:0;">Nog geen opties in de bibliotheek. <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . DP_WPO_BIEB_TYPE ) ); ?>">Maak de eerste aan</a> voor opties die bij meer producten terugkomen, zoals "Opvoeren naar 25 km/u".</p>
	<?php else : ?>
		<p style="margin-top:0;">Vink aan wat bij dit product hoort. <strong>Laat een bedrag leeg</strong> voor de standaardprijs uit de bibliotheek (verandert die, dan gaat hij hier mee); vul een bedrag in voor een eigen prijs bij dit product. <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . DP_WPO_BIEB_TYPE ) ); ?>">Bibliotheek beheren</a></p>
	<?php endif; ?>
	<input type="hidden" name="dp_wpo_bieb" id="dp-wpo-bieb" value="<?php echo esc_attr( wp_json_encode( $gekozen ) ); ?>">
	<div id="dp-wpo-bieblijst" data-bieb="<?php echo esc_attr( wp_json_encode( $bieb ) ); ?>"></div>

	<h4 style="margin:18px 0 6px;">Alleen voor dit product</h4>
	<p style="margin-top:0;">Opties die niet in de bibliotheek staan. Een <strong>vinkje</strong> is één optie die aan of uit kan (bijvoorbeeld "Extra set wieltjes", +12,95). Een <strong>keuzelijst</strong> is precies één keuze uit meerdere; de eerste is de standaard. <strong>Meerdere vinkjes</strong> zet onderdelen onder één kop die de klant elk los kan aanvinken (bijvoorbeeld "Extra's": Inpakken +3,50, Kaartje +1,50). Bedragen in euro's.</p>
	<input type="hidden" name="dp_wpo_config" id="dp-wpo-config" value="<?php echo esc_attr( wp_json_encode( $formulier ) ); ?>">
	<div id="dp-wpo-groepen"></div>
	<p>
		<button type="button" class="button" data-wpo-nieuw="vinkje">+ Vinkje</button>
		<button type="button" class="button" data-wpo-nieuw="keuze">+ Keuzelijst</button>
		<button type="button" class="button" data-wpo-nieuw="meerdere">+ Meerdere vinkjes</button>
	</p>
	<style>
		.dp-wpo-groep { margin: 0 0 10px; padding: 12px 14px; border: 1px solid #dcdcde; border-radius: 6px; background: #fafafa; }
		.dp-wpo-rij { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 0 0 8px; }
		.dp-wpo-rij input[type=text] { flex: 1; min-width: 160px; }
		.dp-wpo-rij input.dp-wpo-prijs { flex: 0 0 110px; min-width: 0; }
		.dp-wpo-type { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; color: #50575e; }
		.dp-wpo-keuzes { margin: 6px 0 0 16px; }
		.dp-wpo-weg { color: #b32d2e !important; }
	</style>
	<script>
	(function () {
		var veld = document.getElementById('dp-wpo-config');
		var bak = document.getElementById('dp-wpo-groepen');
		var data = [];
		try { data = JSON.parse(veld.value || '[]') || []; } catch (e) { data = []; }
		function id() { return Math.random().toString(36).slice(2, 8); }
		function opslaan() { veld.value = JSON.stringify(data); }
		function invoer(waarde, plaats, klasse, bij) {
			var i = document.createElement('input');
			i.type = 'text'; i.value = waarde || ''; i.placeholder = plaats;
			if (klasse) i.className = klasse;
			i.addEventListener('input', function () { bij(i.value); opslaan(); });
			return i;
		}
		function knop(tekst, klasse, klik) {
			var b = document.createElement('button');
			b.type = 'button'; b.className = 'button-link ' + (klasse || ''); b.textContent = tekst;
			b.addEventListener('click', klik);
			return b;
		}
		function tekenen() {
			bak.innerHTML = '';
			data.forEach(function (g, gi) {
				var box = document.createElement('div'); box.className = 'dp-wpo-groep';
				var kop = document.createElement('div'); kop.className = 'dp-wpo-rij';
				var type = document.createElement('span'); type.className = 'dp-wpo-type'; type.textContent = { keuze: 'Keuzelijst', meerdere: 'Meerdere vinkjes' }[g.type] || 'Vinkje';
				kop.appendChild(type);
				kop.appendChild(invoer(g.label, { keuze: 'Naam, bijv. Accu', meerdere: 'Kop, bijv. Extra\'s' }[g.type] || 'Naam, bijv. Opvoeren naar 25 km/u', '', function (v) { g.label = v; }));
				if (g.type === 'vinkje') kop.appendChild(invoer(g.prijs, '+ bedrag', 'dp-wpo-prijs', function (v) { g.prijs = v; }));
				kop.appendChild(knop('Omhoog', '', function () { if (gi > 0) { data.splice(gi - 1, 0, data.splice(gi, 1)[0]); opslaan(); tekenen(); } }));
				kop.appendChild(knop('Verwijderen', 'dp-wpo-weg', function () { data.splice(gi, 1); opslaan(); tekenen(); }));
				box.appendChild(kop);
				var uitleg = document.createElement('div'); uitleg.className = 'dp-wpo-rij';
				uitleg.appendChild(invoer(g.uitleg, 'Uitleg onder de optie (optioneel)', '', function (v) { g.uitleg = v; }));
				box.appendChild(uitleg);
				if (g.type === 'keuze' || g.type === 'meerdere') {
					var lijst = document.createElement('div'); lijst.className = 'dp-wpo-keuzes';
					(g.keuzes || []).forEach(function (k, ki) {
						var r = document.createElement('div'); r.className = 'dp-wpo-rij';
						r.appendChild(invoer(k.label, g.type === 'meerdere' ? (ki === 0 ? 'Onderdeel, bijv. Inpakken' : 'Onderdeel, bijv. Kaartje') : (ki === 0 ? 'Standaardkeuze, bijv. 20Ah' : 'Keuze, bijv. 40Ah'), '', function (v) { k.label = v; }));
						r.appendChild(invoer(k.prijs, '+ bedrag', 'dp-wpo-prijs', function (v) { k.prijs = v; }));
						r.appendChild(knop('Verwijderen', 'dp-wpo-weg', function () { g.keuzes.splice(ki, 1); opslaan(); tekenen(); }));
						lijst.appendChild(r);
					});
					lijst.appendChild(knop(g.type === 'meerdere' ? '+ Onderdeel' : '+ Keuze', '', function () { g.keuzes = g.keuzes || []; g.keuzes.push({ id: id(), label: '', prijs: '' }); opslaan(); tekenen(); }));
					box.appendChild(lijst);
				}
				bak.appendChild(box);
			});
		}
		document.querySelectorAll('[data-wpo-nieuw]').forEach(function (b) {
			b.addEventListener('click', function () {
				var type = b.getAttribute('data-wpo-nieuw');
				data.push(type === 'vinkje'
					? { id: id(), type: 'vinkje', label: '', uitleg: '', prijs: '' }
					: { id: id(), type: type, label: '', uitleg: '', keuzes: [{ id: id(), label: '', prijs: '' }, { id: id(), label: '', prijs: '' }] });
				opslaan(); tekenen();
			});
		});
		tekenen();
	})();
	</script>
	<style>
		.dp-wpo-bieb { margin: 0 0 8px; padding: 10px 14px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff; }
		.dp-wpo-bieb.is-aan { border-color: #281E5D; background: #faf9ff; }
		.dp-wpo-bieb > label { display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer; }
		.dp-wpo-bieb-std { margin-left: auto; font-weight: 400; color: #646970; }
		.dp-wpo-bieb-prijzen { margin: 8px 0 0 26px; }
		.dp-wpo-bieb-prijzen .dp-wpo-rij { margin: 0 0 6px; }
		.dp-wpo-bieb-prijzen .dp-wpo-rij span { min-width: 140px; }
	</style>
	<script>
	(function () {
		var veld = document.getElementById('dp-wpo-bieb');
		var bak = document.getElementById('dp-wpo-bieblijst');
		var bieb = []; var keuze = [];
		try { bieb = JSON.parse(bak.getAttribute('data-bieb') || '[]') || []; } catch (e) {}
		try { keuze = JSON.parse(veld.value || '[]') || []; } catch (e) {}
		function vind(id) { for (var i = 0; i < keuze.length; i++) { if (+keuze[i].id === +id) return keuze[i]; } return null; }
		function opslaan() { veld.value = JSON.stringify(keuze); }
		function prijsveld(waarde, standaard, bij) {
			var i = document.createElement('input');
			i.type = 'text'; i.className = 'dp-wpo-prijs'; i.value = waarde || ''; i.placeholder = 'standaard ' + standaard;
			i.addEventListener('input', function () { bij(i.value); opslaan(); });
			return i;
		}
		function rij(tekst, invoer) {
			var r = document.createElement('div'); r.className = 'dp-wpo-rij';
			var s = document.createElement('span'); s.textContent = tekst; r.appendChild(s); r.appendChild(invoer);
			return r;
		}
		function tekenen() {
			bak.innerHTML = '';
			bieb.forEach(function (o) {
				var k = vind(o.id);
				var box = document.createElement('div'); box.className = 'dp-wpo-bieb' + (k ? ' is-aan' : '');
				var lab = document.createElement('label');
				var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!k;
				cb.addEventListener('change', function () {
					if (cb.checked) { keuze.push({ id: o.id, prijs: '', keuzes: {} }); }
					else { keuze = keuze.filter(function (x) { return +x.id !== +o.id; }); }
					opslaan(); tekenen();
				});
				lab.appendChild(cb);
				lab.appendChild(document.createTextNode(o.naam));
				var std = document.createElement('span'); std.className = 'dp-wpo-bieb-std';
				std.textContent = o.type === 'vinkje' ? 'Vinkje · standaard ' + o.prijs : (o.type === 'meerdere' ? 'Meerdere vinkjes (' + o.keuzes.length + ')' : 'Keuzelijst (' + o.keuzes.length + ' keuzes)');
				lab.appendChild(std);
				box.appendChild(lab);
				if (k) {
					var p = document.createElement('div'); p.className = 'dp-wpo-bieb-prijzen';
					if (o.type !== 'vinkje') {
						k.keuzes = k.keuzes && !Array.isArray(k.keuzes) ? k.keuzes : {};
						o.keuzes.forEach(function (kz) {
							p.appendChild(rij(kz.label, prijsveld(k.keuzes[kz.id], kz.prijs, function (v) { k.keuzes[kz.id] = v; })));
						});
					} else {
						p.appendChild(rij('Prijs bij dit product', prijsveld(k.prijs, o.prijs, function (v) { k.prijs = v; })));
					}
					box.appendChild(p);
				}
				bak.appendChild(box);
			});
		}
		tekenen();
	})();
	</script>
	<?php
}

add_action( 'save_post_fluent-products', function ( $post_id ) {
	if ( ! ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		dp_wpo_opslaan_uit_formulier( $post_id );
	}
} );

/**
 * Bewaar de velden van het invoerblok (dp_wpo_config, dp_wpo_bieb) uit $_POST. Gebruikt door
 * het productgegevens-scherm en door het kaartje in de FluentCart-editor. Geeft false zonder
 * geldige nonce of rechten.
 */
function dp_wpo_opslaan_uit_formulier( $post_id ) {
	if ( ! isset( $_POST['dp_wpo_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['dp_wpo_nonce'] ), 'dp_wpo_opslaan' ) ) {
		return false;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return false;
	}
	$invoer = json_decode( wp_unslash( (string) ( $_POST['dp_wpo_config'] ?? '[]' ) ), true );
	$cfg    = dp_wpo_schoon( is_array( $invoer ) ? $invoer : [], true );
	if ( $cfg ) {
		update_post_meta( $post_id, DP_WPO_META, $cfg );
	} else {
		delete_post_meta( $post_id, DP_WPO_META );
	}
	if ( isset( $_POST['dp_wpo_bieb'] ) ) {
		$bieb = json_decode( wp_unslash( (string) $_POST['dp_wpo_bieb'] ), true );
		$bieb = dp_wpo_bieb_schoon( is_array( $bieb ) ? $bieb : [], true );
		if ( $bieb ) {
			update_post_meta( $post_id, DP_WPO_BIEB_META, $bieb );
		} else {
			delete_post_meta( $post_id, DP_WPO_BIEB_META );
		}
	}
	return true;
}

/* ------------------------------------------------------------------ */
/*  Beheer: de bibliotheek zelf (Productgegevens → Opties)              */
/* ------------------------------------------------------------------ */

add_action( 'add_meta_boxes_' . DP_WPO_BIEB_TYPE, function () {
	add_meta_box( 'dp-wpo-optie', 'Instellingen van de optie', 'dp_wpo_optie_metabox', DP_WPO_BIEB_TYPE, 'normal', 'high' );
	add_meta_box( 'dp-wpo-optie-producten', 'Bij producten', 'dp_wpo_optie_producten_metabox', DP_WPO_BIEB_TYPE, 'normal', 'default' );
} );

function dp_wpo_optie_metabox( $post ) {
	$d      = (array) get_post_meta( $post->ID, 'dp_po_def', true );
	$type   = dp_wpo_soort( $d['type'] ?? 'vinkje' );
	$keuzes = array_map( fn( $k ) => [ 'id' => $k['id'] ?? '', 'label' => $k['label'] ?? '', 'prijs' => ! empty( $k['prijs'] ) ? dp_wpo_invoer( $k['prijs'] ) : '' ], (array) ( $d['keuzes'] ?? [] ) );
	wp_nonce_field( 'dp_wpo_optie_opslaan', 'dp_wpo_optie_nonce' );
	?>
	<p style="margin-top:0;">De naam van de optie is de titel hierboven, bijvoorbeeld "Opvoeren naar 25 km/u" of "Accu". Die naam ziet de klant op de productpagina en in de winkelwagen.</p>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="dp-wpo-optie-type">Soort</label></th>
			<td>
				<select name="dp_wpo_optie[type]" id="dp-wpo-optie-type">
					<option value="vinkje" <?php selected( $type, 'vinkje' ); ?>>Vinkje (aan of uit)</option>
					<option value="keuze" <?php selected( $type, 'keuze' ); ?>>Keuzelijst (precies één van meerdere)</option>
					<option value="meerdere" <?php selected( $type, 'meerdere' ); ?>>Meerdere vinkjes (elk los aan te vinken)</option>
				</select>
			</td>
		</tr>
		<tr data-wpo-voor="vinkje">
			<th scope="row"><label for="dp-wpo-optie-prijs">Standaardprijs</label></th>
			<td><input type="text" name="dp_wpo_optie[prijs]" id="dp-wpo-optie-prijs" class="small-text" style="width:110px;" value="<?php echo esc_attr( ! empty( $d['prijs'] ) ? dp_wpo_invoer( $d['prijs'] ) : '' ); ?>" placeholder="0,00"> <span class="description">in euro's; per product aan te passen</span></td>
		</tr>
		<tr data-wpo-voor="keuze meerdere">
			<th scope="row">Keuzes / onderdelen</th>
			<td>
				<input type="hidden" name="dp_wpo_optie[keuzes]" id="dp-wpo-optie-keuzes" value="<?php echo esc_attr( wp_json_encode( $keuzes ) ); ?>">
				<div id="dp-wpo-optie-keuzelijst"></div>
				<p><button type="button" class="button" id="dp-wpo-optie-nieuw">+ Keuze</button></p>
				<p class="description">Keuzelijst: de eerste keuze is de standaard (meestal +0, bijvoorbeeld "20Ah"). Meerdere vinkjes: elk onderdeel kan de klant los aanvinken (bijvoorbeeld "Inpakken" +3,50 en "Kaartje" +1,50). Standaardprijzen in euro's; per product aan te passen.</p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="dp-wpo-optie-uitleg">Uitleg</label></th>
			<td><input type="text" name="dp_wpo_optie[uitleg]" id="dp-wpo-optie-uitleg" class="large-text" value="<?php echo esc_attr( $d['uitleg'] ?? '' ); ?>" placeholder="Korte uitleg onder de optie op de productpagina (optioneel)"></td>
		</tr>
	</table>
	<script>
	(function () {
		var type = document.getElementById('dp-wpo-optie-type');
		var veld = document.getElementById('dp-wpo-optie-keuzes');
		var bak = document.getElementById('dp-wpo-optie-keuzelijst');
		var keuzes = []; try { keuzes = JSON.parse(veld.value || '[]') || []; } catch (e) {}
		function id() { return Math.random().toString(36).slice(2, 8); }
		function opslaan() { veld.value = JSON.stringify(keuzes); }
		function wissel() { document.querySelectorAll('[data-wpo-voor]').forEach(function (r) { r.style.display = r.getAttribute('data-wpo-voor').split(' ').indexOf(type.value) !== -1 ? '' : 'none'; }); document.getElementById('dp-wpo-optie-nieuw').textContent = type.value === 'meerdere' ? '+ Onderdeel' : '+ Keuze'; if (type.value !== 'vinkje' && !keuzes.length) { keuzes = [{ id: id(), label: '', prijs: '' }, { id: id(), label: '', prijs: '' }]; opslaan(); } tekenen(); }
		function tekenen() {
			bak.innerHTML = '';
			keuzes.forEach(function (k, i) {
				var r = document.createElement('p');
				var l = document.createElement('input'); l.type = 'text'; l.value = k.label; l.placeholder = type.value === 'meerdere' ? 'Onderdeel, bijv. ' + (i === 0 ? 'Inpakken' : 'Kaartje') : (i === 0 ? 'Standaardkeuze, bijv. 20Ah' : 'Keuze, bijv. 40Ah'); l.style.width = '240px';
				l.addEventListener('input', function () { k.label = l.value; opslaan(); });
				var p = document.createElement('input'); p.type = 'text'; p.value = k.prijs; p.placeholder = '+ bedrag'; p.style.width = '110px'; p.style.marginLeft = '6px';
				p.addEventListener('input', function () { k.prijs = p.value; opslaan(); });
				var w = document.createElement('button'); w.type = 'button'; w.className = 'button-link'; w.textContent = 'Verwijderen'; w.style.marginLeft = '8px'; w.style.color = '#b32d2e';
				w.addEventListener('click', function () { keuzes.splice(i, 1); opslaan(); tekenen(); });
				r.appendChild(l); r.appendChild(p); r.appendChild(w); bak.appendChild(r);
			});
		}
		document.getElementById('dp-wpo-optie-nieuw').addEventListener('click', function () { keuzes.push({ id: id(), label: '', prijs: '' }); opslaan(); tekenen(); });
		type.addEventListener('change', wissel);
		tekenen(); wissel();
	})();
	</script>
	<?php
}

function dp_wpo_optie_producten_metabox( $post ) {
	if ( $post->post_status !== 'publish' ) {
		echo '<p>Publiceer de optie eerst; daarna kun je hem hier in één keer aan producten toevoegen.</p>';
		return;
	}
	$ids  = dp_wpo_bieb_gebruik()[ $post->ID ] ?? [];
	$cats = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false, 'orderby' => 'name' ] );
	$link = fn( $actie ) => wp_nonce_url( admin_url( 'admin-post.php?action=dp_wpo_bieb_categorie&optie=' . $post->ID . '&actie=' . $actie ), 'dp_wpo_bieb_categorie' );
	?>
	<p style="margin-top:0;">Gebruikt bij <strong><?php echo (int) count( $ids ); ?></strong> <?php echo count( $ids ) === 1 ? 'product' : 'producten'; ?>.
		<?php if ( $ids ) : ?>
			<?php echo esc_html( implode( ', ', array_map( 'get_the_title', array_slice( $ids, 0, 12 ) ) ) ); ?><?php echo count( $ids ) > 12 ? ' …' : ''; ?>
		<?php endif; ?>
	</p>
	<?php if ( ! is_wp_error( $cats ) && $cats ) : ?>
		<p>
			<label for="dp-wpo-cat">In één keer bij alle producten in categorie</label><br>
			<select id="dp-wpo-cat">
				<?php foreach ( $cats as $c ) : ?>
					<option value="<?php echo (int) $c->term_id; ?>"><?php echo esc_html( ( $c->parent ? '— ' : '' ) . $c->name . ' (' . (int) $c->count . ')' ); ?></option>
				<?php endforeach; ?>
			</select>
			<a class="button" data-wpo-cat="<?php echo esc_url( $link( 'toevoegen' ) ); ?>" href="#">Toevoegen</a>
			<a class="button-link" style="color:#b32d2e; margin-left:6px;" data-wpo-cat="<?php echo esc_url( $link( 'weghalen' ) ); ?>" href="#">Weghalen</a>
		</p>
		<p class="description">Subcategorieën tellen mee. Toegevoegde producten volgen de standaardprijs; een eigen bedrag vul je per product in. Losse producten kun je ook in de productlijst aanvinken en via "Bulkacties" de optie geven.</p>
		<script>
		document.querySelectorAll('[data-wpo-cat]').forEach(function (a) {
			a.addEventListener('click', function (e) {
				e.preventDefault();
				var sel = document.getElementById('dp-wpo-cat');
				if (!window.confirm((a.textContent.trim() === 'Toevoegen' ? 'Toevoegen aan' : 'Weghalen bij') + ' alle producten in "' + sel.options[sel.selectedIndex].text + '"?')) return;
				location.href = a.getAttribute('data-wpo-cat') + '&term=' + encodeURIComponent(sel.value);
			});
		});
		</script>
	<?php endif; ?>
	<?php
}

add_action( 'save_post_' . DP_WPO_BIEB_TYPE, function ( $post_id ) {
	if ( ! isset( $_POST['dp_wpo_optie_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['dp_wpo_optie_nonce'] ), 'dp_wpo_optie_opslaan' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$in     = (array) wp_unslash( $_POST['dp_wpo_optie'] ?? [] );
	$keuzes = json_decode( (string) ( $in['keuzes'] ?? '[]' ), true );
	// Zelfde opschoning als bij eigen opties (naam doet hier niet mee: dat is de titel).
	$schoon = dp_wpo_schoon( [ [
		'id'     => 'x',
		'label'  => 'x',
		'uitleg' => $in['uitleg'] ?? '',
		'type'   => $in['type'] ?? 'vinkje',
		'prijs'  => $in['prijs'] ?? '',
		'keuzes' => is_array( $keuzes ) ? $keuzes : [],
	] ], true );
	$g = $schoon[0] ?? [ 'type' => dp_wpo_soort( $in['type'] ?? 'keuze' ), 'uitleg' => sanitize_text_field( (string) ( $in['uitleg'] ?? '' ) ), 'prijs' => 0, 'keuzes' => [] ];
	update_post_meta( $post_id, 'dp_po_def', [ 'type' => $g['type'], 'uitleg' => $g['uitleg'], 'prijs' => $g['prijs'], 'keuzes' => $g['keuzes'] ] );
} );

add_action( 'admin_post_dp_wpo_bieb_categorie', function () {
	check_admin_referer( 'dp_wpo_bieb_categorie' );
	$optie = absint( $_GET['optie'] ?? 0 );
	$term  = absint( $_GET['term'] ?? 0 );
	if ( ! $optie || ! $term || ! current_user_can( 'edit_post', $optie ) ) {
		wp_die( 'Geen toegang.' );
	}
	$ids = get_posts( [
		'post_type'   => 'fluent-products',
		'post_status' => 'any',
		'numberposts' => -1,
		'fields'      => 'ids',
		'tax_query'   => [ [ 'taxonomy' => 'product-categories', 'field' => 'term_id', 'terms' => [ $term ], 'include_children' => true ] ],
	] );
	$toevoegen = ( $_GET['actie'] ?? '' ) !== 'weghalen';
	$n         = dp_wpo_bieb_toewijzen( $optie, $ids, $toevoegen );
	wp_safe_redirect( add_query_arg( [ 'dp_wpo_n' => $n, 'dp_wpo_actie' => $toevoegen ? 'toegevoegd' : 'weggehaald' ], get_edit_post_link( $optie, 'raw' ) ) );
	exit;
} );

// Bulkacties in de productlijst (Productgegevens): optie toevoegen of weghalen.
add_filter( 'bulk_actions-edit-fluent-products', function ( $acties ) {
	foreach ( dp_wpo_bieb_alle() as $o ) {
		$acties[ 'dp_wpo_plus_' . $o['bieb'] ]  = 'Optie toevoegen: ' . $o['label'];
	}
	foreach ( dp_wpo_bieb_alle() as $o ) {
		$acties[ 'dp_wpo_min_' . $o['bieb'] ] = 'Optie weghalen: ' . $o['label'];
	}
	return $acties;
} );

add_filter( 'handle_bulk_actions-edit-fluent-products', function ( $terug, $actie, $ids ) {
	if ( ! preg_match( '/^dp_wpo_(plus|min)_(\d+)$/', (string) $actie, $m ) ) {
		return $terug;
	}
	$n = dp_wpo_bieb_toewijzen( (int) $m[2], (array) $ids, $m[1] === 'plus' );
	return add_query_arg( [ 'dp_wpo_n' => $n, 'dp_wpo_actie' => $m[1] === 'plus' ? 'toegevoegd' : 'weggehaald', 'dp_wpo_optie' => (int) $m[2] ], $terug );
}, 10, 3 );

add_action( 'admin_notices', function () {
	if ( ! isset( $_GET['dp_wpo_n'], $_GET['dp_wpo_actie'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$n     = (int) $_GET['dp_wpo_n']; // phpcs:ignore WordPress.Security.NonceVerification
	$actie = $_GET['dp_wpo_actie'] === 'weggehaald' ? 'weggehaald bij' : 'toegevoegd aan'; // phpcs:ignore WordPress.Security.NonceVerification
	printf( '<div class="notice notice-success is-dismissible"><p>Optie %s %d %s.</p></div>', esc_html( $actie ), (int) $n, $n === 1 ? 'product' : 'producten' );
} );

// Lijst van de bibliotheek: soort, standaardprijs en gebruik.
add_filter( 'manage_' . DP_WPO_BIEB_TYPE . '_posts_columns', function ( $kolommen ) {
	$datum = $kolommen['date'] ?? null;
	unset( $kolommen['date'] );
	$kolommen['dp_soort']   = 'Soort';
	$kolommen['dp_prijs']   = 'Standaardprijs';
	$kolommen['dp_gebruik'] = 'Bij producten';
	return $kolommen;
} );
add_action( 'manage_' . DP_WPO_BIEB_TYPE . '_posts_custom_column', function ( $kolom, $post_id ) {
	$d = (array) get_post_meta( $post_id, 'dp_po_def', true );
	if ( $kolom === 'dp_soort' ) {
		echo esc_html( dp_wpo_soort_naam( $d['type'] ?? '' ) . ( in_array( $d['type'] ?? '', [ 'keuze', 'meerdere' ], true ) ? ' (' . count( (array) ( $d['keuzes'] ?? [] ) ) . ')' : '' ) );
	} elseif ( $kolom === 'dp_prijs' ) {
		if ( in_array( $d['type'] ?? '', [ 'keuze', 'meerdere' ], true ) ) {
			echo esc_html( implode( ' / ', array_map( fn( $k ) => ( $k['label'] ?? '' ) . ( ! empty( $k['prijs'] ) ? ' +' . dp_wpo_bedrag( $k['prijs'] ) : '' ), (array) ( $d['keuzes'] ?? [] ) ) ) );
		} else {
			echo esc_html( '+' . dp_wpo_bedrag( (int) ( $d['prijs'] ?? 0 ) ) );
		}
	} elseif ( $kolom === 'dp_gebruik' ) {
		echo (int) count( dp_wpo_bieb_gebruik()[ $post_id ] ?? [] );
	}
}, 10, 2 );

/* ------------------------------------------------------------------ */
/*  In de FluentCart-producteditor: kaartje "Opties met meerprijs"     */
/*  onder het prijzenblok, met wat er is ingesteld. "Bewerken" klapt    */
/*  daar hetzelfde invoerblok open als op het productgegevens-scherm   */
/*  (opgehaald via AJAX) met een eigen knop Opslaan, los van die van   */
/*  FluentCart. De editor is een Vue-app zonder haken: het script      */
/*  zoekt het prijzenblok (.fct-product-pricing-wrap) en zet het        */
/*  kaartje eronder. Vindt het dat blok niet, dan zweeft het kaartje   */
/*  rechtsonder. Het product-ID komt uit het adres (#/products/123).    */
/* ------------------------------------------------------------------ */

add_action( 'wp_ajax_dp_wpo_samenvatting', function () {
	check_ajax_referer( 'dp_wpo_samenvatting', 'nonce' );
	$id = absint( $_GET['id'] ?? 0 );
	if ( ! $id || get_post_type( $id ) !== 'fluent-products' || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error();
	}
	$regels = [];
	foreach ( dp_wpo_config( $id ) as $g ) {
		if ( $g['type'] === 'vinkje' ) {
			$regels[] = [ $g['label'], $g['prijs'] ? '+' . dp_wpo_bedrag( $g['prijs'] ) : '' ];
		} else {
			// Keuzelijst: "20Ah / 40Ah"; meerdere vinkjes: "Inpakken · Kaartje".
			$regels[] = [ $g['label'], implode( $g['type'] === 'meerdere' ? ' · ' : ' / ', array_map( fn( $k ) => $k['label'] . ( $k['prijs'] ? ' (+' . dp_wpo_bedrag( $k['prijs'] ) . ')' : '' ), $g['keuzes'] ) ) ];
		}
	}
	wp_send_json_success( [ 'regels' => $regels, 'url' => admin_url( 'post.php?action=edit&post=' . $id ) . '#dp-productopties' ] );
} );

/* Het invoerblok voor in het kaartje: dezelfde uitvoer als de metabox, scripts inbegrepen. */
add_action( 'wp_ajax_dp_wpo_fc_bewerker', function () {
	check_ajax_referer( 'dp_wpo_samenvatting', 'nonce' );
	$id = absint( $_GET['id'] ?? 0 );
	if ( ! $id || get_post_type( $id ) !== 'fluent-products' || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error();
	}
	ob_start();
	dp_wpo_metabox( get_post( $id ) );
	wp_send_json_success( [ 'html' => ob_get_clean() ] );
} );

/* Opslaan vanuit het kaartje: dezelfde velden en nonce als het productgegevens-scherm. */
add_action( 'wp_ajax_dp_wpo_fc_opslaan', function () {
	$id = absint( $_POST['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification -- dp_wpo_opslaan_uit_formulier controleert de nonce
	if ( ! $id || get_post_type( $id ) !== 'fluent-products' || ! dp_wpo_opslaan_uit_formulier( $id ) ) {
		wp_send_json_error( [ 'melding' => 'Opslaan lukte niet. Ververs de pagina en probeer het opnieuw.' ] );
	}
	wp_send_json_success();
} );

add_action( 'admin_footer', function () {
	if ( ( $_GET['page'] ?? '' ) !== 'fluent-cart' ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	?>
	<style>
		.dp-wpo-fc { box-sizing: border-box; margin: 24px 0; padding: 20px 22px; border: 1px solid #e4e7ec; border-radius: 8px; background: #fff; color: #1d2327; font-size: 13px; }
		.dp-wpo-fc.is-zwevend { position: fixed; right: 24px; bottom: 76px; z-index: 99989; width: 320px; max-width: calc(100vw - 48px); margin: 0; box-shadow: 0 6px 20px rgba(0, 0, 0, .12); }
		.dp-wpo-fc-kop { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
		.dp-wpo-fc-titel { font-size: 16px; font-weight: 500; }
		.dp-wpo-fc-knop { display: inline-flex; align-items: center; padding: 6px 14px; border: 1px solid #d0d5dd; border-radius: 6px; background: #fff; color: #1d2327; font-weight: 500; text-decoration: none; white-space: nowrap; }
		.dp-wpo-fc-knop:hover, .dp-wpo-fc-knop:focus { border-color: #281E5D; color: #281E5D; }
		.dp-wpo-fc-lijst { margin: 0; padding: 0; list-style: none; }
		.dp-wpo-fc-lijst li { display: flex; justify-content: space-between; gap: 12px; margin: 0; padding: 8px 0; border-top: 1px solid #f0f1f3; }
		.dp-wpo-fc-lijst li span:last-child { color: #50575e; text-align: right; }
		.dp-wpo-fc-leeg, .dp-wpo-fc-voet { margin: 0; color: #6b7280; line-height: 1.5; }
		.dp-wpo-fc-voet { margin-top: 10px; font-size: 12px; }
		.dp-wpo-fc.is-zwevend.is-bewerken { width: 640px; max-height: calc(100vh - 140px); overflow: auto; }
		.dp-wpo-fc-bewerker { padding-top: 4px; border-top: 1px solid #f0f1f3; }
		.dp-wpo-fc-bewerker h4 { font-size: 14px; }
		.dp-wpo-fc-bewerker p { line-height: 1.5; }
		.dp-wpo-fc-bewerker input[type=text] { box-sizing: border-box; min-height: 32px; padding: 4px 8px; border: 1px solid #d0d5dd; border-radius: 6px; font-size: 13px; }
		.dp-wpo-fc-acties { display: flex; align-items: center; gap: 10px; margin-top: 16px; padding-top: 14px; border-top: 1px solid #f0f1f3; }
		.dp-wpo-fc-knop.is-primair { border-color: #281E5D; background: #281E5D; color: #fff; cursor: pointer; }
		.dp-wpo-fc-knop.is-primair:hover, .dp-wpo-fc-knop.is-primair:focus { background: #1b1440; color: #fff; }
		.dp-wpo-fc-knop[disabled] { opacity: .6; cursor: wait; }
		button.dp-wpo-fc-knop { font: inherit; cursor: pointer; }
		.dp-wpo-fc-status { color: #6b7280; }
		.dp-wpo-fc-status.is-fout { color: #b32d2e; }
	</style>
	<script>
	(function () {
		var ajax = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce = <?php echo wp_json_encode( wp_create_nonce( 'dp_wpo_samenvatting' ) ); ?>;
		var kaart = null, gegevens = null, geladenOm = 0, wacht, opgehaald = null;
		var bewerkt = null, gewijzigd = false; // product-ID waarvan het invoerblok open staat

		function productId() { var m = location.hash.match(/^#\/products\/(\d+)/); return m ? m[1] : null; }

		function el(tag, klasse, tekst) { var e = document.createElement(tag); if (klasse) e.className = klasse; if (tekst) e.textContent = tekst; return e; }

		function sluiten() {
			bewerkt = null; gewijzigd = false;
			kaart.classList.remove('is-bewerken');
			kaart.removeAttribute('data-sleutel'); // samenvatting opnieuw tekenen
		}

		function bewerken() {
			var id = gegevens.id;
			var knop = kaart.querySelector('.dp-wpo-fc-kop .dp-wpo-fc-knop');
			if (knop) { knop.setAttribute('disabled', ''); knop.textContent = 'Laden…'; }
			fetch(ajax + '?action=dp_wpo_fc_bewerker&nonce=' + encodeURIComponent(nonce) + '&id=' + id, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (j) {
					if (!j || !j.success || productId() !== id) throw new Error();
					bewerkt = id; gewijzigd = false;
					kaart.innerHTML = '';
					kaart.classList.add('is-bewerken');
					var kop = el('div', 'dp-wpo-fc-kop');
					kop.appendChild(el('span', 'dp-wpo-fc-titel', 'Opties met meerprijs'));
					kaart.appendChild(kop);
					var vak = el('div', 'dp-wpo-fc-bewerker');
					vak.innerHTML = j.data.html;
					kaart.appendChild(vak);
					// Scripts uit innerHTML draaien niet vanzelf: opnieuw aanmaken (het vak staat al in de pagina).
					vak.querySelectorAll('script').forEach(function (oud) { var s = document.createElement('script'); s.textContent = oud.textContent; oud.replaceWith(s); });
					['input', 'change', 'click'].forEach(function (t) { vak.addEventListener(t, function (e) { if (t !== 'click' || e.target.closest('button')) gewijzigd = true; }); });

					var acties = el('div', 'dp-wpo-fc-acties');
					var opslaan = el('button', 'dp-wpo-fc-knop is-primair', 'Opties opslaan'); opslaan.type = 'button';
					var annuleren = el('button', 'dp-wpo-fc-knop', 'Annuleren'); annuleren.type = 'button';
					var status = el('span', 'dp-wpo-fc-status');
					acties.appendChild(opslaan); acties.appendChild(annuleren); acties.appendChild(status);
					kaart.appendChild(acties);

					annuleren.addEventListener('click', function () {
						if (gewijzigd && !window.confirm('Je wijzigingen aan de opties weggooien?')) return;
						sluiten(); vullen();
					});
					opslaan.addEventListener('click', function () {
						var data = new FormData();
						data.append('action', 'dp_wpo_fc_opslaan');
						data.append('id', id);
						vak.querySelectorAll('input[type=hidden][name]').forEach(function (i) { data.append(i.name, i.value); });
						opslaan.setAttribute('disabled', ''); status.className = 'dp-wpo-fc-status'; status.textContent = 'Opslaan…';
						fetch(ajax, { method: 'POST', body: data, credentials: 'same-origin' })
							.then(function (r) { return r.json(); })
							.then(function (a) {
								if (!a || !a.success) throw new Error(a && a.data && a.data.melding);
								sluiten(); laad();
							})
							.catch(function (e) {
								opslaan.removeAttribute('disabled');
								status.className = 'dp-wpo-fc-status is-fout';
								status.textContent = (e && e.message) || 'Opslaan lukte niet. Probeer het opnieuw.';
							});
					});
				})
				.catch(function () { location.href = gegevens.url; }); // terugval: het productgegevens-scherm
		}

		// Niet ongemerkt weggaan met niet-opgeslagen opties.
		window.addEventListener('beforeunload', function (e) { if (bewerkt && gewijzigd) { e.preventDefault(); e.returnValue = ''; } });

		function vullen() {
			if (bewerkt) {
				if (bewerkt === gegevens.id) return; // invoerblok staat open: niet overschrijven
				sluiten(); // ander product geopend
			}
			var sleutel = gegevens.id + JSON.stringify(gegevens.regels);
			if (kaart.getAttribute('data-sleutel') === sleutel) return;
			kaart.setAttribute('data-sleutel', sleutel);
			kaart.innerHTML = '';
			var kop = el('div', 'dp-wpo-fc-kop');
			kop.appendChild(el('span', 'dp-wpo-fc-titel', 'Opties met meerprijs'));
			var knop = el('button', 'dp-wpo-fc-knop', gegevens.regels.length ? 'Opties bewerken' : 'Opties toevoegen');
			knop.type = 'button';
			knop.addEventListener('click', bewerken);
			kop.appendChild(knop);
			kaart.appendChild(kop);
			if (gegevens.regels.length) {
				var lijst = el('ul', 'dp-wpo-fc-lijst');
				gegevens.regels.forEach(function (r) { var li = el('li'); li.appendChild(el('span', '', r[0])); li.appendChild(el('span', '', r[1])); lijst.appendChild(li); });
				kaart.appendChild(lijst);
				kaart.appendChild(el('p', 'dp-wpo-fc-voet', 'Klanten kiezen deze opties op de productpagina; de meerprijs komt bovenop de prijs hierboven.'));
			} else {
				kaart.appendChild(el('p', 'dp-wpo-fc-leeg', 'Nog geen opties. Bijvoorbeeld een vinkje "Opvoeren naar 25 km/u" (+€60) of een keuzelijst "Accu" met 20Ah en 40Ah (+€200).'));
			}
		}

		function plaats() {
			var id = productId();
			// FluentCart wisselt van product zonder hashchange (pushState): een ander ID in het adres = opnieuw ophalen.
			if (id && (!gegevens || gegevens.id !== id) && opgehaald !== id) { laad(); return; }
			if (!id || !gegevens || gegevens.id !== id) { if (kaart && (!id)) kaart.remove(); return; }
			if (!kaart) { kaart = el('div', 'dp-wpo-fc'); kaart.id = 'dp-wpo-fc'; }
			vullen();
			var prijs = document.querySelector('.fct-product-pricing-wrap');
			var doel = prijs ? (prijs.closest('.fct-content-card') || prijs) : null;
			if (doel) {
				kaart.classList.remove('is-zwevend');
				if (doel.nextElementSibling !== kaart) doel.insertAdjacentElement('afterend', kaart);
			} else if (!/^#\/products\/\d+\/?(\?.*)?$/.test(location.hash)) {
				kaart.remove(); // ander tabblad van het product (upgradepaden, integraties)
			} else if (Date.now() - geladenOm > 3000) {
				kaart.classList.add('is-zwevend');
				if (kaart.parentNode !== document.body) document.body.appendChild(kaart);
			}
		}

		function laad() {
			var id = productId();
			if (!id) { plaats(); return; }
			opgehaald = id;
			geladenOm = Date.now();
			fetch(ajax + '?action=dp_wpo_samenvatting&nonce=' + encodeURIComponent(nonce) + '&id=' + id, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (j) { if (j && j.success) { gegevens = j.data; gegevens.id = id; plaats(); setTimeout(plaats, 3200); } })
				.catch(function () {});
		}

		window.addEventListener('hashchange', laad);
		window.addEventListener('popstate', function () { setTimeout(plaats, 50); });
		document.addEventListener('visibilitychange', function () { if (!document.hidden) laad(); });
		new MutationObserver(function () { clearTimeout(wacht); wacht = setTimeout(plaats, 150); })
			.observe(document.getElementById('wpbody-content') || document.body, { childList: true, subtree: true });
		laad();
	})();
	</script>
	<?php
} );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_productopties', 'dp_webshop_productopties', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : [];
			return [
				'auto'             => empty( $in['auto'] ) ? 0 : 1,
				'direct_verbergen' => empty( $in['direct_verbergen'] ) ? 0 : 1,
				'totaal'           => empty( $in['totaal'] ) ? 0 : 1,
				'vinkjes_titel'    => sanitize_text_field( (string) ( $in['vinkjes_titel'] ?? '' ) ),
			];
		},
	] );
	dp_webshop_register_module_settings( 'productopties', 'dp_wpo_render', [
		'title'       => 'Productopties met meerprijs',
		'description' => 'Opties zoals opvoeren of een grotere accu.',
	] );
} );

function dp_wpo_render() {
	global $wpdb;
	$s        = dp_wpo_instellingen();
	$producten = $wpdb->get_results( $wpdb->prepare(
		"SELECT DISTINCT p.ID, p.post_title FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key IN (%s, %s) AND p.post_type = 'fluent-products' AND p.post_status <> 'trash' ORDER BY p.post_title",
		DP_WPO_META,
		DP_WPO_BIEB_META
	) );
	$bieb = dp_wpo_bieb_alle();
	$vink = function ( $k, $tekst ) use ( $s ) {
		printf(
			'<label><input type="hidden" name="dp_webshop_productopties[%1$s]" value="0"><input type="checkbox" name="dp_webshop_productopties[%1$s]" value="1" %2$s> %3$s</label>',
			esc_attr( $k ), checked( ! empty( $s[ $k ] ), true, false ), esc_html( $tekst )
		);
	};
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_productopties' ); ?>
			<div class="dpw-veld">
				<strong>Productpagina</strong>
				<?php $vink( 'auto', 'Opties vanzelf boven de koopknoppen tonen' ); ?>
				<?php $vink( 'totaal', 'Live totaalprijs onder de opties' ); ?>
				<?php $vink( 'direct_verbergen', '"Direct kopen" verbergen bij producten met opties (die knop slaat de opties over)' ); ?>
				<label style="display:block;margin-top:10px;">Kop boven losse extra opties<br>
					<input type="text" class="regular-text" name="dp_webshop_productopties[vinkjes_titel]" value="<?php echo esc_attr( $s['vinkjes_titel'] ?? '' ); ?>" placeholder="Extra opties">
				</label>
				<p class="dpw-hint">Losse vinkjes (bijv. "Stokhouder +€50") staan samen in één lijst; dit is de kop erboven. Leeg laten = geen kop. Keuzegroepen zoals "Accu" houden hun eigen naam als kop.</p>
				<p class="dpw-hint">Staan de opties niet op de goede plek in je Bricks-sjabloon? Zet het eerste vinkje uit en plaats de shortcode <code class="dpw-code">[dp_productopties]</code> zelf, bijvoorbeeld boven de koopknop.</p>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<p><strong>Optiebibliotheek</strong> (<?php echo (int) count( $bieb ); ?>): opties die bij meer producten terugkomen, één keer aangemaakt onder <?php echo dp_wpo_onder_productgegevens() ? 'Productgegevens → Opties' : 'FluentCart → Productopties'; ?>. <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . DP_WPO_BIEB_TYPE ) ); ?>">Bibliotheek openen</a></p>
			<p><strong>Producten met opties</strong> (<?php echo (int) count( $producten ); ?>)</p>
			<?php if ( $producten ) : ?>
				<ul style="margin:0 0 10px 18px; list-style:disc;">
					<?php foreach ( $producten as $p ) : ?>
						<li><a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>"><?php echo esc_html( $p->post_title ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<p>Opties stel je in op het productgegevens-scherm van een product (blok "Productopties met meerprijs"). De klant ziet de gekozen opties in winkelwagen, kassa, bestelling, mail en bon.</p>
			<p>Goed om te weten: FluentCart houdt de winkelwagen bij per variant. Legt een klant hetzelfde product nog eens in de winkelwagen met andere opties, dan gelden de laatst gekozen opties voor die regel.</p>
		</div>
	</div>
	<?php
}
