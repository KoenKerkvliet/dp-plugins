<?php
/**
 * Module Name: Bovenliggende categorieën
 * Description: Een product in een subcategorie krijgt vanzelf ook de bovenliggende categorieën. Een filter "Soort product" met alleen hoofdcategorieën telt namelijk alleen directe koppelingen: zonder dit ontbreken hoofdcategorieën waarvan alle producten in een subcategorie staan. Categorieën zijn uit te sluiten (bijvoorbeeld losse opties).
 * Category: catalogus
 * Vervalt zodra: filters bij een hoofdcategorie ook de producten in de subcategorieën meetellen.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_HOOFDCAT_VERSION', '1.0.0' );

/** Term-ID's waarvan de bovenliggende categorieën niet worden toegevoegd. */
function dp_whc_uitgesloten() {
	$s = dp_webshop_instellingen( 'dp_webshop_hoofdcategorieen', [ 'uitsluiten' => [] ] );
	return array_values( array_filter( array_map( 'absint', (array) $s['uitsluiten'] ) ) );
}

/** Voeg de ontbrekende bovenliggende categorieën toe. Geeft het aantal toegevoegde terug. */
function dp_whc_aanvullen( $post_id ) {
	static $bezig = false;
	if ( $bezig || get_post_type( $post_id ) !== 'fluent-products' ) {
		return 0;
	}
	$huidig = array_map( 'intval', (array) wp_get_object_terms( $post_id, 'product-categories', [ 'fields' => 'ids' ] ) );
	$uit    = dp_whc_uitgesloten();
	$erbij  = [];
	foreach ( $huidig as $term_id ) {
		if ( in_array( $term_id, $uit, true ) ) {
			continue;
		}
		foreach ( get_ancestors( $term_id, 'product-categories', 'taxonomy' ) as $ouder ) {
			$erbij[] = (int) $ouder;
		}
	}
	$erbij = array_values( array_diff( array_unique( $erbij ), $huidig ) );
	if ( $erbij ) {
		$bezig = true;
		wp_set_object_terms( $post_id, $erbij, 'product-categories', true ); // integers: nooit als nieuwe termnaam
		$bezig = false;
	}
	return count( $erbij );
}

add_action( 'set_object_terms', function ( $object_id, $terms, $tt_ids, $taxonomy ) {
	if ( $taxonomy === 'product-categories' ) {
		dp_whc_aanvullen( $object_id );
	}
}, 10, 4 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_hoofdcategorieen', 'dp_webshop_hoofdcategorieen', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : [];
			return [ 'uitsluiten' => array_values( array_filter( array_map( 'absint', (array) ( $in['uitsluiten'] ?? [] ) ) ) ) ];
		},
	] );
	dp_webshop_register_module_settings( 'hoofdcategorieen', 'dp_whc_render', [
		'title'       => 'Bovenliggende categorieën',
		'description' => 'Subcategorie → ook de hoofdcategorie.',
	] );
} );

add_action( 'admin_post_dp_whc_alles', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dp_whc_alles' ) ) {
		wp_die( 'Geen toegang.' );
	}
	$n = 0;
	foreach ( get_posts( [ 'post_type' => 'fluent-products', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ] ) as $id ) {
		$n += dp_whc_aanvullen( $id ) ? 1 : 0;
	}
	wp_safe_redirect( add_query_arg( 'dp_whc_n', $n, admin_url( 'admin.php?page=dp-webshop#settings-hoofdcategorieen' ) ) );
	exit;
} );

function dp_whc_render() {
	$uit  = dp_whc_uitgesloten();
	$cats = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false, 'childless' => false ] );
	$n    = isset( $_GET['dp_whc_n'] ) ? (int) $_GET['dp_whc_n'] : null; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="dpw-kaart">
		<?php if ( null !== $n ) : ?>
			<p class="dpw-melding"><?php echo esc_html( sprintf( '%d producten kregen er een bovenliggende categorie bij.', $n ) ); ?></p>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_hoofdcategorieen' ); ?>
			<div class="dpw-veld">
				<strong>Uitsluiten</strong>
				<?php if ( is_wp_error( $cats ) || ! $cats ) : ?>
					<p class="dpw-hint">Nog geen productcategorieën.</p>
				<?php else : ?>
					<div style="max-height:220px; overflow:auto; border:1px solid #eee; border-radius:6px; padding:8px 10px;">
						<?php foreach ( $cats as $c ) : ?>
							<label>
								<input type="checkbox" name="dp_webshop_hoofdcategorieen[uitsluiten][]" value="<?php echo esc_attr( $c->term_id ); ?>" <?php checked( in_array( (int) $c->term_id, $uit, true ) ); ?>>
								<?php echo esc_html( $c->name ); ?>
							</label>
						<?php endforeach; ?>
					</div>
					<p class="dpw-hint">Een product in een uitgesloten categorie krijgt daarvoor geen bovenliggende categorie erbij.</p>
				<?php endif; ?>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<p>Nieuwe en gewijzigde producten gaan vanzelf. Voor bestaande producten:</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dp_whc_alles">
				<?php wp_nonce_field( 'dp_whc_alles' ); ?>
				<button type="submit" class="dpw-knop dpw-knop--licht">Alle producten nalopen</button>
			</form>
		</div>
	</div>
	<?php
}
