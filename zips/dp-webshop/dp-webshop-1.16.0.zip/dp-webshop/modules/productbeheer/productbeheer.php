<?php
/**
 * Module Name: Productgegevens-scherm
 * Description: Maakt duidelijk waar wat staat. FluentCart beheert prijs, voorraad en foto's; het klassieke WordPress-scherm is de plek voor eigen velden (specificaties, JetEngine-velden, Past hierbij). Deze module hernoemt dat scherm naar "Productgegevens", haalt de knop "Nieuw product" daar weg (een product dat daar ontstaat heeft geen prijs of voorraad), zet een link naar FluentCart bovenaan, een kaartje "Productgegevens" onderaan de FluentCart-editor met de velden die FluentCart zelf niet heeft (of een knop ernaartoe), en toont de velden in de klassieke editor in plaats van in een smalle Gutenberg-balk.
 * Category: catalogus
 * Version: 1.1.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_PRODUCTBEHEER_VERSION', '1.1.1' );

function dp_wpb_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_productbeheer', [
		'menu_tonen'       => 1,
		'menu_label'       => 'Productgegevens',
		'geen_nieuw'       => 1,
		'melding'          => 1,
		'knop_fluentcart'  => 1,
		'klassieke_editor' => 1,
		'ingebed'          => 1,
	] );
}

function dp_wpb_aan( $sleutel ) {
	return ! empty( dp_wpb_instellingen()[ $sleutel ] );
}

/* Het klassieke productscherm in het menu (FluentCart verbergt het standaard). */
add_filter( 'fluent_cart/show_standalone_product_menu', function ( $toon ) {
	return dp_wpb_aan( 'menu_tonen' ) ? true : $toon;
}, 30 );

/* Naam van het scherm: "Productgegevens" in plaats van nog een keer "Producten". */
add_filter( 'post_type_labels_fluent-products', function ( $labels ) {
	$label = trim( (string) dp_wpb_instellingen()['menu_label'] );
	if ( $label === '' ) {
		return $labels;
	}
	$labels->name      = $label;
	$labels->menu_name = $label;
	$labels->all_items = 'Alle producten';
	$labels->edit_item = $label . ' bewerken';
	return $labels;
} );

/* De klassieke editor: eigen velden als gewone blokken onder de tekst, niet in een balk onderaan. */
add_filter( 'use_block_editor_for_post_type', function ( $gebruik, $post_type ) {
	return ( $post_type === 'fluent-products' && ( dp_wpb_aan( 'klassieke_editor' ) || dp_wpb_ingebed() ) ) ? false : $gebruik;
}, 20, 2 );

/*
 * Geen "Nieuw product" op dit scherm. Een product dat hier ontstaat heeft geen rij in de
 * FluentCart-tabellen: geen prijs, geen variant, geen voorraad, en is dus niet te koop.
 */
add_action( 'admin_menu', function () {
	if ( dp_wpb_aan( 'geen_nieuw' ) ) {
		remove_submenu_page( 'edit.php?post_type=fluent-products', 'post-new.php?post_type=fluent-products' );
	}
}, 999 );

add_action( 'load-post-new.php', function () {
	if ( dp_wpb_aan( 'geen_nieuw' ) && ( $_GET['post_type'] ?? '' ) === 'fluent-products' ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_safe_redirect( admin_url( 'admin.php?page=fluent-cart#/products' ) );
		exit;
	}
} );

add_action( 'admin_bar_menu', function ( $balk ) {
	if ( dp_wpb_aan( 'geen_nieuw' ) ) {
		$balk->remove_node( 'new-fluent-products' );
	}
}, 999 );

add_action( 'admin_head', function () {
	$scherm = get_current_screen();
	if ( ! $scherm || $scherm->post_type !== 'fluent-products' || ! dp_wpb_aan( 'geen_nieuw' ) ) {
		return;
	}
	echo '<style>.post-type-fluent-products .page-title-action { display: none; }</style>';
} );

/*
 * FluentCart zet bovenaan dit scherm een eigen productkop (terugpijl, naam, links naar de
 * editortabbladen), maar laadt de opmaak ervan hier niet: dan staan er losse blauwe links.
 * De melding hieronder doet hetzelfde; staat die aan, dan de kop van FluentCart weg.
 */
add_action( 'admin_head', function () {
	$scherm = get_current_screen();
	if ( $scherm && $scherm->base === 'post' && $scherm->post_type === 'fluent-products' && dp_wpb_aan( 'melding' ) ) {
		echo '<style>.post-type-fluent-products .fct-admin-product-header { display: none !important; }</style>';
	}
} );

/* Bovenaan het bewerkscherm: waar de rest van het product staat. */
add_action( 'admin_notices', function () {
	$scherm = get_current_screen();
	if ( ! $scherm || $scherm->base !== 'post' || $scherm->post_type !== 'fluent-products' || ! dp_wpb_aan( 'melding' ) ) {
		return;
	}
	$id = (int) ( $_GET['post'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $id ) {
		return;
	}
	printf(
		'<div class="notice notice-info"><p>Prijs, voorraad, varianten, foto\'s en categorieën beheer je in FluentCart. Hier vul je de extra productgegevens in. <a href="%s" class="button button-small" style="margin-left:6px;">Open dit product in FluentCart</a></p></div>',
		esc_url( dp_webshop_fluentcart_product_url( $id ) )
	);
} );

/*
 * In de FluentCart-editor: een vaste knop naar de productgegevens van het product dat open
 * staat. De editor is een Vue-app zonder haken; de knop leest alleen het product-ID uit het
 * adres (#/products/123). Verandert FluentCart zijn scherm, dan verdwijnt hooguit de knop.
 */
add_action( 'admin_footer', function () {
	// Met het kaartje Productgegevens in de editor is de knop overbodig.
	if ( ( $_GET['page'] ?? '' ) !== 'fluent-cart' || ! dp_wpb_aan( 'knop_fluentcart' ) || dp_wpb_aan( 'ingebed' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$label = trim( (string) dp_wpb_instellingen()['menu_label'] ) ?: 'Productgegevens';
	?>
	<style>
		#dp-wpb-knop { position: fixed; right: 24px; bottom: 24px; z-index: 99990; display: none; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 6px; background: #281E5D; color: #fff; font-size: 13px; font-weight: 600; text-decoration: none; box-shadow: 0 4px 14px rgba(40, 30, 93, .28); }
		#dp-wpb-knop:hover, #dp-wpb-knop:focus { background: #4a3a8a; color: #fff; }
		#dp-wpb-knop .dashicons { font-size: 16px; width: 16px; height: 16px; }
	</style>
	<a id="dp-wpb-knop" href="#"><span class="dashicons dashicons-list-view" aria-hidden="true"></span><?php echo esc_html( $label ); ?> invullen</a>
	<script>
	(function () {
		var knop = document.getElementById('dp-wpb-knop');
		var basis = <?php echo wp_json_encode( admin_url( 'post.php?action=edit&post=' ) ); ?>;
		function bij() {
			var m = location.hash.match(/^#\/products\/(\d+)/);
			if (m) { knop.href = basis + m[1]; knop.style.display = 'inline-flex'; }
			else { knop.style.display = 'none'; }
		}
		window.addEventListener('hashchange', bij);
		bij();
	})();
	</script>
	<?php
} );

/* ------------------------------------------------------------------ */
/*  In de FluentCart-editor: kaartje "Productgegevens"                  */
/*  Het klassieke bewerkscherm draait ingebed (iframe, ?dp_ingebed=1)   */
/*  met alleen wat FluentCart zelf niet heeft: eigen velden (JetEngine),*/
/*  specificaties en andere blokken van plugins. Titel, tekst,          */
/*  samenvatting, afbeelding, status en de taxonomieën die FluentCart   */
/*  toont staan er niet in, en bij opslaan zet de server die velden     */
/*  terug op wat in de database staat: wat intussen in FluentCart is    */
/*  gewijzigd, overschrijft het kaartje nooit. Opslaan is het gewone    */
/*  WordPress-opslaan (post.php), dus elke plugin bewaart zijn velden   */
/*  zoals altijd.                                                       */
/* ------------------------------------------------------------------ */

function dp_wpb_ingebed() {
	global $pagenow;
	return is_admin() && $pagenow === 'post.php' && ! empty( $_REQUEST['dp_ingebed'] ) && dp_wpb_aan( 'ingebed' ); // phpcs:ignore WordPress.Security.NonceVerification
}

/** Taxonomieën die de FluentCart-editor zelf toont (alle openbare bij producten). */
function dp_wpb_fluentcart_taxonomieen() {
	if ( class_exists( '\FluentCart\Api\Taxonomy' ) && method_exists( '\FluentCart\Api\Taxonomy', 'getTaxonomies' ) ) {
		$lijst = array_keys( (array) \FluentCart\Api\Taxonomy::getTaxonomies() );
		if ( $lijst ) {
			return $lijst;
		}
	}
	return [ 'product-categories', 'product-brands' ];
}

/* Opslaan vanuit het kaartje: wat FluentCart beheert terug naar de database-waarde. */
add_action( 'admin_init', function () {
	if ( ! dp_wpb_ingebed() || ( $_POST['action'] ?? '' ) !== 'editpost' ) { // phpcs:ignore WordPress.Security.NonceVerification -- post.php controleert de nonce
		return;
	}
	$post = get_post( (int) ( $_POST['post_ID'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $post || $post->post_type !== 'fluent-products' ) {
		return;
	}
	// $_POST is door WordPress van slashes voorzien; database-waarden dus ook.
	$_POST['post_title']     = wp_slash( $post->post_title );
	$_POST['content']        = wp_slash( $post->post_content );
	$_POST['excerpt']        = wp_slash( $post->post_excerpt );
	$_POST['post_name']      = $post->post_name;
	$_POST['post_status']    = $post->post_status;
	$_POST['post_author']    = $post->post_author;
	$_POST['post_password']  = wp_slash( $post->post_password );
	$_POST['comment_status'] = $post->comment_status;
	$_POST['ping_status']    = $post->ping_status;
	$_POST['menu_order']     = $post->menu_order;
	$_POST['parent_id']      = $post->post_parent;
	foreach ( [ 'visibility', 'sticky', 'publish', 'saveasdraft', 'saveasprivate', 'advanced', 'pending', 'edit_date', 'post_author_override', '_thumbnail_id', 'meta', 'metakeyinput', 'metakeyselect', 'metavalue', 'post_category', 'dp_wpo_nonce', 'dp_wpo_config', 'dp_wpo_bieb' ] as $k ) {
		unset( $_POST[ $k ] );
	}
	foreach ( [ 'aa', 'mm', 'jj', 'hh', 'mn', 'ss' ] as $k ) {
		unset( $_POST[ $k ], $_POST[ 'hidden_' . $k ], $_POST[ 'cur_' . $k ] );
	}
	foreach ( dp_wpb_fluentcart_taxonomieen() as $tax ) {
		unset( $_POST['tax_input'][ $tax ] );
	}
}, 1 );

add_filter( 'redirect_post_location', function ( $adres ) {
	return ! empty( $_POST['dp_ingebed'] ) ? add_query_arg( 'dp_ingebed', 1, $adres ) : $adres; // phpcs:ignore WordPress.Security.NonceVerification
} );

/* Het ingebedde scherm: alleen de blokken die FluentCart niet heeft, in één kolom. */
add_action( 'load-post.php', function () {
	if ( ! dp_wpb_ingebed() || ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) !== 'GET' ) { // alleen de weergave; opslaan loopt normaal
		return;
	}
	foreach ( [ 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'comments', 'trackbacks', 'custom-fields', 'revisions' ] as $onderdeel ) {
		remove_post_type_support( 'fluent-products', $onderdeel );
	}
	add_filter( 'get_user_option_screen_layout_fluent-products', fn() => 1 );
	// Geen autosave: bij een concept schrijft die titel en tekst direct weg, en die komen hier niet vandaan.
	add_action( 'admin_enqueue_scripts', fn() => wp_dequeue_script( 'autosave' ), 100 );
	add_action( 'do_meta_boxes', function ( $post_type, $context ) {
		foreach ( [ 'submitdiv', 'slugdiv', 'litespeed_meta_boxes', 'dp-productopties' ] as $id ) {
			remove_meta_box( $id, $post_type, $context );
		}
	}, 999, 2 );
	add_action( 'edit_form_top', function () {
		echo '<input type="hidden" name="dp_ingebed" value="1">';
	} );
} );

add_action( 'admin_head', function () {
	if ( ! dp_wpb_ingebed() ) {
		return;
	}
	// Taxonomieblokken die FluentCart toont: verborgen maar aanwezig, want JetEngine leest de
	// aangevinkte categorieën om te bepalen welke velden bij dit product horen.
	$verborgen = [];
	foreach ( dp_wpb_fluentcart_taxonomieen() as $tax ) {
		$verborgen[] = '#' . $tax . 'div';
		$verborgen[] = '#tagsdiv-' . $tax;
	}
	?>
	<style id="dp-wpb-ingebed">
		html, html.wp-toolbar { height: auto !important; padding-top: 0 !important; background: #fff; }
		body { min-width: 0 !important; background: #fff !important; overflow: hidden; }
		#wpwrap { min-height: 0 !important; }
		#wpadminbar, #adminmenumain, #wpfooter, #screen-meta, #screen-meta-links, .wrap > h1, .wrap > .page-title-action, .wrap > .wp-header-end,
		.notice, .update-nag, .updated, div.error, #post-body-content, #message, .fct-admin-product-header, <?php echo esc_html( implode( ', ', $verborgen ) ); ?> { display: none !important; }
		#wpcontent, .auto-fold #wpcontent { margin-left: 0 !important; padding-left: 0 !important; }
		#wpbody-content { padding-bottom: 0 !important; }
		.wrap { margin: 0 !important; }
		#poststuff { min-width: 0 !important; padding-top: 0 !important; }
		#post-body.columns-2, #post-body.columns-1 { margin-right: 0 !important; }
		#post-body #postbox-container-1, #post-body #postbox-container-2 { float: none !important; width: 100% !important; margin-right: 0 !important; }
		#poststuff .postbox { margin-bottom: 14px; border-color: #e4e7ec; border-radius: 6px; }
		#poststuff .postbox:last-child { margin-bottom: 0; }
	</style>
	<?php
} );

add_action( 'admin_footer', function () {
	if ( ! dp_wpb_ingebed() ) {
		return;
	}
	?>
	<script>
	// Links in het kaartje openen in een nieuw tabblad, niet in het kleine venster.
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a[href]');
		if (!a || a.target) return;
		var href = a.getAttribute('href') || '';
		if (href === '' || href.charAt(0) === '#' || /^javascript:/i.test(href)) return;
		a.target = '_blank';
	}, true);
	</script>
	<?php
} );

/* Het kaartje in de FluentCart-editor, onderaan de kolom met de productblokken. */
add_action( 'admin_footer', function () {
	if ( ( $_GET['page'] ?? '' ) !== 'fluent-cart' || ! dp_wpb_aan( 'ingebed' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$label = trim( (string) dp_wpb_instellingen()['menu_label'] ) ?: 'Productgegevens';
	?>
	<style>
		.dp-wpb-fc { box-sizing: border-box; margin: 24px 0; padding: 20px 22px; border: 1px solid #e4e7ec; border-radius: 8px; background: #fff; color: #1d2327; font-size: 13px; }
		.dp-wpb-fc-kop { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
		.dp-wpb-fc-titel { font-size: 16px; font-weight: 500; }
		.dp-wpb-fc-sub { margin: 4px 0 0; color: #6b7280; }
		.dp-wpb-fc-acties { display: flex; align-items: center; gap: 10px; }
		.dp-wpb-fc-status { color: #6b7280; }
		.dp-wpb-fc-status.is-fout { color: #b32d2e; }
		.dp-wpb-fc-status.is-open { color: #9a6700; }
		.dp-wpb-fc-knop { display: inline-flex; align-items: center; padding: 6px 14px; border: 1px solid #281E5D; border-radius: 6px; background: #281E5D; color: #fff; font: inherit; font-weight: 500; cursor: pointer; white-space: nowrap; }
		.dp-wpb-fc-knop:hover, .dp-wpb-fc-knop:focus { background: #1b1440; }
		.dp-wpb-fc-knop[disabled] { opacity: .6; cursor: wait; }
		.dp-wpb-fc-frame { display: block; width: 100%; height: 160px; margin-top: 14px; border: 0; }
	</style>
	<script>
	(function () {
		var basis = <?php echo wp_json_encode( admin_url( 'post.php?action=edit&dp_ingebed=1&post=' ) ); ?>;
		var label = <?php echo wp_json_encode( $label ); ?>;
		var kaart = null, frame, knop, status, id = null, gewijzigd = false, bezig = false, wacht, ververs, vangnet;

		function productId() { var m = location.hash.match(/^#\/products\/(\d+)\/?(\?.*)?$/); return m ? m[1] : null; }
		function el(tag, klasse, tekst) { var e = document.createElement(tag); if (klasse) e.className = klasse; if (tekst) e.textContent = tekst; return e; }
		function melden(tekst, soort) { status.textContent = tekst || ''; status.className = 'dp-wpb-fc-status' + (soort ? ' is-' + soort : ''); }

		function maak() {
			kaart = el('div', 'dp-wpb-fc'); kaart.id = 'dp-wpb-fc';
			var kop = el('div', 'dp-wpb-fc-kop');
			var links = el('div');
			links.appendChild(el('div', 'dp-wpb-fc-titel', label));
			links.appendChild(el('p', 'dp-wpb-fc-sub', 'Velden die FluentCart zelf niet heeft, zoals kerngegevens en specificaties.'));
			kop.appendChild(links);
			var acties = el('div', 'dp-wpb-fc-acties');
			status = el('span', 'dp-wpb-fc-status');
			knop = el('button', 'dp-wpb-fc-knop', label + ' opslaan'); knop.type = 'button';
			knop.addEventListener('click', opslaan);
			acties.appendChild(status); acties.appendChild(knop);
			kop.appendChild(acties);
			kaart.appendChild(kop);
			frame = el('iframe', 'dp-wpb-fc-frame'); frame.title = label; frame.setAttribute('loading', 'lazy');
			frame.addEventListener('load', geladen);
			kaart.appendChild(frame);
		}

		function laden() { gewijzigd = false; bezig = false; knop.disabled = false; melden('Laden…'); frame.style.height = '160px'; frame.src = basis + id; }

		function doc() { try { return frame.contentDocument; } catch (e) { return null; } }

		function hoogte() {
			var d = doc(), vak = d && (d.getElementById('poststuff') || d.getElementById('wpbody-content'));
			if (!vak) return;
			var h = Math.ceil(vak.getBoundingClientRect().bottom + (d.defaultView.pageYOffset || 0)) + 4;
			if (Math.abs(parseInt(frame.style.height, 10) - h) > 2) frame.style.height = h + 'px';
		}

		function geladen() {
			var d = doc();
			if (!d || !d.body || !/post\.php/.test(d.location.href)) return;
			clearTimeout(vangnet); bezig = false; knop.disabled = false;
			if (!d.getElementById('post')) { melden('Opslaan lukte niet. Ververs de pagina en probeer het opnieuw.', 'fout'); frame.style.height = '320px'; return; }
			gewijzigd = false;
			melden(/[?&]message=\d/.test(d.location.search) ? 'Opgeslagen' : '');
			var markeer = function () { if (!gewijzigd) { gewijzigd = true; melden('Niet opgeslagen', 'open'); } };
			d.addEventListener('input', markeer, true);
			d.addEventListener('change', markeer, true);
			d.addEventListener('click', function (e) { var t = e.target.closest && e.target.closest('.inside button, .inside .button, .inside [role=button]'); if (t) markeer(); }, true);
			hoogte();
			// Meegroeien: blokken die open- en dichtklappen of velden die verschijnen (JetEngine-voorwaarden).
			var RO = d.defaultView.ResizeObserver, t;
			if (RO) new RO(hoogte).observe(d.body);
			new d.defaultView.MutationObserver(function () { clearTimeout(t); t = setTimeout(hoogte, 60); })
				.observe(d.body, { subtree: true, childList: true, attributes: true, attributeFilter: [ 'class', 'style', 'hidden' ] });
		}

		function opslaan() {
			var d = doc(), form = d && d.getElementById('post');
			if (!form || bezig) return;
			if (form.checkValidity && !form.checkValidity()) { form.reportValidity(); melden('Vul de verplichte velden in.', 'fout'); return; }
			try { if (frame.contentWindow.tinymce) frame.contentWindow.tinymce.triggerSave(); } catch (e) {}
			bezig = true; knop.disabled = true; melden('Opslaan…');
			// Houdt een plugin het versturen tegen (bijvoorbeeld een eigen controle), dan niet blijven hangen.
			vangnet = setTimeout(function () { bezig = false; knop.disabled = false; melden('Niet opgeslagen: controleer de velden hieronder.', 'fout'); }, 20000);
			if (form.requestSubmit) form.requestSubmit(); else form.submit();
		}

		function plaats() {
			var nieuw = productId();
			var prijs = document.querySelector('.fct-product-pricing-wrap');
			var anker = prijs ? (prijs.closest('.fct-content-card') || prijs) : null;
			if (!nieuw || !anker || !anker.parentNode) { if (kaart && kaart.parentNode) kaart.remove(); return; }
			if (!kaart) maak();
			var kolom = anker.parentNode;
			// Onderaan de kolom. Alleen verplaatsen als het nodig is: een verplaatst iframe laadt opnieuw.
			if (kaart.parentNode !== kolom || kaart.nextElementSibling) kolom.appendChild(kaart);
			if (nieuw !== id) { id = nieuw; laden(); }
		}

		// Slaat FluentCart het product op (bijvoorbeeld een andere categorie), dan het kaartje verversen:
		// welke velden bij het product horen kan daarvan afhangen. Niet als er iets niet is opgeslagen.
		function fcVerzoek(url, methode) {
			if (!id || !kaart || /^get$/i.test(methode || 'GET')) return;
			var u = String(url || ''); try { u = decodeURIComponent(u); } catch (e) {}
			if (!new RegExp('fluent-cart/v2/products/(.*/)?' + id + '(\\D|$)').test(u)) return;
			clearTimeout(ververs);
			ververs = setTimeout(function () { if (!gewijzigd && !bezig && kaart.parentNode) laden(); }, 1200);
		}
		if (window.fetch) {
			var eigenFetch = window.fetch;
			window.fetch = function (invoer, opties) {
				var belofte = eigenFetch.apply(this, arguments);
				try {
					var url = typeof invoer === 'string' ? invoer : (invoer && invoer.url);
					var methode = (opties && opties.method) || (invoer && invoer.method) || 'GET';
					belofte.then(function (r) { if (r && r.ok) fcVerzoek(url, methode); }, function () {});
				} catch (e) {}
				return belofte;
			};
		}
		var eigenOpen = XMLHttpRequest.prototype.open;
		XMLHttpRequest.prototype.open = function (methode, url) {
			try { this.addEventListener('load', function () { if (this.status < 400) fcVerzoek(url, methode); }); } catch (e) {}
			return eigenOpen.apply(this, arguments);
		};

		window.addEventListener('beforeunload', function (e) { if (gewijzigd && kaart && kaart.parentNode) { e.preventDefault(); e.returnValue = ''; } });
		window.addEventListener('hashchange', plaats);
		window.addEventListener('resize', function () { if (kaart && kaart.parentNode) hoogte(); });
		new MutationObserver(function () { clearTimeout(wacht); wacht = setTimeout(plaats, 150); })
			.observe(document.getElementById('wpbody-content') || document.body, { childList: true, subtree: true });
		plaats();
	})();
	</script>
	<?php
} );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_productbeheer', 'dp_webshop_productbeheer', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : [];
			$uit = [ 'menu_label' => sanitize_text_field( $in['menu_label'] ?? 'Productgegevens' ) ];
			foreach ( [ 'menu_tonen', 'geen_nieuw', 'melding', 'knop_fluentcart', 'klassieke_editor', 'ingebed' ] as $k ) {
				$uit[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
			return $uit;
		},
	] );
	dp_webshop_register_module_settings( 'productbeheer', 'dp_wpb_render', [
		'title'       => 'Productgegevens-scherm',
		'description' => 'Het klassieke productscherm naast de FluentCart-editor.',
	] );
} );

function dp_wpb_render() {
	$s      = dp_wpb_instellingen();
	$vinkje = function ( $sleutel, $tekst, $hint = '' ) use ( $s ) {
		printf(
			'<label><input type="hidden" name="dp_webshop_productbeheer[%1$s]" value="0"><input type="checkbox" name="dp_webshop_productbeheer[%1$s]" value="1" %2$s> %3$s</label>%4$s',
			esc_attr( $sleutel ),
			checked( ! empty( $s[ $sleutel ] ), true, false ),
			esc_html( $tekst ),
			$hint ? '<p class="dpw-hint">' . esc_html( $hint ) . '</p>' : ''
		);
	};
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_productbeheer' ); ?>
			<div class="dpw-veld">
				<strong>Naam in het menu</strong>
				<input type="text" class="regular-text" name="dp_webshop_productbeheer[menu_label]" value="<?php echo esc_attr( $s['menu_label'] ); ?>">
				<p class="dpw-hint">Voorkomt twee keer "Producten" in het menu (FluentCart heeft er zelf ook een).</p>
			</div>
			<div class="dpw-veld">
				<strong>Onderdelen</strong>
				<?php
				$vinkje( 'menu_tonen', 'Het scherm in het menu tonen', 'FluentCart verbergt het klassieke productscherm. Zonder dit scherm kan de klant eigen velden niet invullen.' );
				$vinkje( 'geen_nieuw', 'Geen "Nieuw product" op dit scherm', 'Nieuwe producten maak je altijd in FluentCart; een adres als post-new.php stuurt door naar FluentCart.' );
				$vinkje( 'melding', 'Link naar FluentCart bovenaan het bewerkscherm', 'Vervangt de productkop van FluentCart, die op dit scherm zonder opmaak (als losse blauwe links) staat.' );
				$vinkje( 'ingebed', 'Kaartje "' . ( $s['menu_label'] ?: 'Productgegevens' ) . '" in de FluentCart-editor', 'Onderaan de producteditor van FluentCart: de velden die FluentCart zelf niet heeft (bijvoorbeeld JetEngine-velden en specificaties), met een eigen knop Opslaan. Titel, tekst, status en categorieën blijven van FluentCart.' );
				$vinkje( 'knop_fluentcart', 'Knop "' . ( $s['menu_label'] ?: 'Productgegevens' ) . ' invullen" in de FluentCart-editor', 'Alleen zonder het kaartje hierboven.' );
				$vinkje( 'klassieke_editor', 'Klassieke editor voor producten', 'Gutenberg zet eigen velden in een smalle balk onderaan; de klassieke editor toont ze als gewone blokken.' );
				?>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
	</div>
	<?php
}
