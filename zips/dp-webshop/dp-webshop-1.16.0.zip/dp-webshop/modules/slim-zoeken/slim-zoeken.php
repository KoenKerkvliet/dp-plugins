<?php
/**
 * Module Name: Slimmer zoeken
 * Description: Het zoekveld van de site doorzoekt alleen producten, en vindt ze ook op merk, categorie, kleur en andere eigenschappen. Elk zoekwoord moet ergens raken, dus "opvouwbare scootmobiel" geeft de opvouwbare scootmobielen. Houdt rekening met Nederlandse vervoegingen: "opvouwbare" vindt "opvouwbaar". Categorieën zijn uit te sluiten (bijvoorbeeld losse onderdelen).
 * Category: winkel
 * Vervalt zodra: het zoeken van FluentCart ook op merk, categorie en eigenschappen zoekt en met vervoegingen overweg kan.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_ZOEKEN_VERSION', '1.0.0' );

function dp_wpz_instellingen() {
	return dp_webshop_instellingen( 'dp_webshop_zoeken', [
		'alleen_producten' => 1,
		'uitsluiten'       => [],   // term-ID's van product-categories
		'per_pagina'       => 12,   // 0 = WordPress-standaard laten
	] );
}

/** Taxonomieën waarvan de termnamen meetellen: alle publieke van FluentCart-producten. */
function dp_wpz_taxonomieen() {
	$uit = [];
	foreach ( get_object_taxonomies( 'fluent-products', 'objects' ) as $naam => $tax ) {
		if ( ! empty( $tax->public ) ) {
			$uit[] = $naam;
		}
	}
	return $uit;
}

/**
 * Past een zoekwoord bij een termnaam? Nederlands verbuigt ("opvouwbaar" → "opvouwbare"),
 * dus naast gewoon bevatten telt ook een lang gemeenschappelijk begin. Korte woorden
 * ("de", "2e") alleen als los woord, anders matcht alles.
 */
function dp_wpz_term_past( $woord, $naam ) {
	if ( mb_strlen( $woord ) < 3 ) {
		return in_array( $woord, preg_split( '/\s+/', $naam ), true );
	}
	if ( str_contains( $naam, $woord ) || str_contains( $woord, $naam ) ) {
		return true;
	}
	$kort   = min( mb_strlen( $woord ), mb_strlen( $naam ) );
	$gelijk = 0;
	while ( $gelijk < $kort && mb_substr( $woord, $gelijk, 1 ) === mb_substr( $naam, $gelijk, 1 ) ) {
		$gelijk++;
	}
	return $gelijk >= 5 && $gelijk >= $kort - 2;
}

add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return;
	}
	$s = dp_wpz_instellingen();
	if ( ! empty( $s['alleen_producten'] ) ) {
		$query->set( 'post_type', 'fluent-products' );
	}
	$uit = array_filter( array_map( 'absint', (array) $s['uitsluiten'] ) );
	if ( $uit ) {
		$tax   = (array) $query->get( 'tax_query' );
		$tax[] = [ 'taxonomy' => 'product-categories', 'field' => 'term_id', 'terms' => $uit, 'operator' => 'NOT IN' ];
		$query->set( 'tax_query', $tax );
	}
	if ( (int) $s['per_pagina'] > 0 ) {
		$query->set( 'posts_per_page', (int) $s['per_pagina'] );
	}
} );

add_filter( 'posts_search', function ( $search, $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return $search;
	}
	global $wpdb;
	$woorden = array_filter(
		preg_split( '/\s+/', mb_strtolower( trim( (string) $query->get( 's' ) ) ) ),
		fn( $w ) => mb_strlen( $w ) >= 2
	);
	$taxonomieen = dp_wpz_taxonomieen();
	if ( ! $woorden || ! $taxonomieen ) {
		return $search;
	}
	$in    = implode( ',', array_map( fn( $t ) => "'" . esc_sql( $t ) . "'", $taxonomieen ) );
	$termen = $wpdb->get_results(
		"SELECT tt.term_taxonomy_id AS id, LOWER(t.name) AS naam FROM {$wpdb->terms} t
		 JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
		 WHERE tt.taxonomy IN ($in)"
	);
	$delen = [];
	foreach ( $woorden as $woord ) {
		$like = '%' . $wpdb->esc_like( $woord ) . '%';
		$ids  = [];
		foreach ( $termen as $term ) {
			if ( dp_wpz_term_past( $woord, $term->naam ) ) {
				$ids[] = (int) $term->id;
			}
		}
		$of = $wpdb->prepare(
			"{$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_excerpt LIKE %s OR {$wpdb->posts}.post_content LIKE %s",
			$like, $like, $like
		);
		if ( $ids ) {
			$of .= " OR {$wpdb->posts}.ID IN (SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN (" . implode( ',', $ids ) . '))';
		}
		$delen[] = "( $of )";
	}
	return ' AND ( ' . implode( ' AND ', $delen ) . ' ) ';
}, 10, 2 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_zoeken', 'dp_webshop_zoeken', [
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : [];
			return [
				'alleen_producten' => empty( $in['alleen_producten'] ) ? 0 : 1,
				'uitsluiten'       => array_values( array_filter( array_map( 'absint', (array) ( $in['uitsluiten'] ?? [] ) ) ) ),
				'per_pagina'       => max( 0, min( 100, (int) ( $in['per_pagina'] ?? 12 ) ) ),
			];
		},
	] );
	dp_webshop_register_module_settings( 'slim-zoeken', 'dp_wpz_render', [
		'title'       => 'Slimmer zoeken',
		'description' => 'Wat het zoekveld doorzoekt.',
	] );
} );

function dp_wpz_render() {
	$s     = dp_wpz_instellingen();
	$cats  = get_terms( [ 'taxonomy' => 'product-categories', 'hide_empty' => false ] );
	$namen = array_map( fn( $t ) => get_taxonomy( $t )->labels->name ?? $t, dp_wpz_taxonomieen() );
	?>
	<div class="dpw-kaart">
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_zoeken' ); ?>
			<div class="dpw-veld">
				<strong>Wat doorzoeken</strong>
				<label>
					<input type="hidden" name="dp_webshop_zoeken[alleen_producten]" value="0">
					<input type="checkbox" name="dp_webshop_zoeken[alleen_producten]" value="1" <?php checked( ! empty( $s['alleen_producten'] ) ); ?>>
					Alleen producten (geen pagina's of berichten)
				</label>
			</div>
			<div class="dpw-veld">
				<strong>Categorieën overslaan</strong>
				<?php if ( is_wp_error( $cats ) || ! $cats ) : ?>
					<p class="dpw-hint">Nog geen productcategorieën.</p>
				<?php else : ?>
					<div style="max-height:220px; overflow:auto; border:1px solid #eee; border-radius:6px; padding:8px 10px;">
						<?php foreach ( $cats as $c ) : ?>
							<label>
								<input type="checkbox" name="dp_webshop_zoeken[uitsluiten][]" value="<?php echo esc_attr( $c->term_id ); ?>" <?php checked( in_array( (int) $c->term_id, array_map( 'intval', (array) $s['uitsluiten'] ), true ) ); ?>>
								<?php echo esc_html( $c->name ); ?> <span style="color:#999;">(<?php echo (int) $c->count; ?>)</span>
							</label>
						<?php endforeach; ?>
					</div>
					<p class="dpw-hint">Bijvoorbeeld losse opties en onderdelen die je niet los in de zoekresultaten wilt.</p>
				<?php endif; ?>
			</div>
			<div class="dpw-veld">
				<strong>Resultaten per pagina</strong>
				<input type="number" min="0" max="100" name="dp_webshop_zoeken[per_pagina]" value="<?php echo esc_attr( (int) $s['per_pagina'] ); ?>" style="width:90px;">
				<p class="dpw-hint">0 = de instelling van WordPress (Instellingen → Lezen).</p>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<div class="dpw-uitleg">
			<p>Termen die meetellen bij het zoeken: <?php echo esc_html( implode( ', ', $namen ) ); ?>.</p>
		</div>
	</div>
	<?php
}
