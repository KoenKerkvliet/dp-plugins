<?php
/**
 * Module Name: Prijs voor filters en sorteren
 * Description: FluentCart bewaart prijzen in eigen tabellen, dus een prijsfilter of "sorteer op prijs" in Bricks of JetEngine ziet ze niet. Deze module houdt de laagste prijs (in euro's) bij als gewoon productveld, bij elke wijziging in FluentCart. Met een knop om alle bestaande producten in één keer bij te werken.
 * Category: winkel
 * Vervalt zodra: Bricks- of JetEngine-filters de prijzen uit FluentCart zelf kunnen lezen (prijsfilter en sorteren op prijs).
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DP_WEBSHOP_PRIJS_VERSION', '1.0.0' );

/** Naam van het veld (post meta). Standaard dp_prijs; per site aan te passen. */
function dp_wpp_meta() {
	$m = sanitize_key( (string) get_option( 'dp_webshop_prijs_meta', 'dp_prijs' ) );
	return $m !== '' ? $m : 'dp_prijs';
}

/** Laagste prijs van een product in euro's bijwerken (uit fct_product_details.min_price, in centen). */
function dp_wpp_sync( $post_id ) {
	global $wpdb;
	$post_id = absint( $post_id );
	if ( ! $post_id || get_post_type( $post_id ) !== 'fluent-products' ) {
		return;
	}
	$min = $wpdb->get_var( $wpdb->prepare( "SELECT min_price FROM {$wpdb->prefix}fct_product_details WHERE post_id = %d", $post_id ) );
	if ( $min === null ) {
		return;
	}
	$euro = round( (int) $min / 100, 2 );
	if ( (string) get_post_meta( $post_id, dp_wpp_meta(), true ) !== (string) $euro ) {
		update_post_meta( $post_id, dp_wpp_meta(), $euro );
	}
}

/*
 * FluentCart schrijft prijzen in meerdere stappen weg (product, daarna varianten). Daarom
 * pas op 'shutdown' synchroniseren, als alles in de database staat — één keer per product.
 */
function dp_wpp_plan( $post_id ) {
	static $wachtrij = null;
	$post_id = absint( $post_id );
	if ( ! $post_id ) {
		return;
	}
	if ( null === $wachtrij ) {
		$wachtrij = [];
		add_action( 'shutdown', function () use ( &$wachtrij ) {
			foreach ( array_keys( $wachtrij ) as $id ) {
				dp_wpp_sync( $id );
			}
		} );
	}
	$wachtrij[ $post_id ] = true;
}

add_action( 'fluent_cart/product_updated', function ( $args ) {
	$product = $args['product'] ?? null;
	dp_wpp_plan( is_object( $product ) ? ( $product->ID ?? 0 ) : ( $product['ID'] ?? 0 ) );
} );
add_action( 'fluent_cart/product/variants_updated', function ( $args ) {
	dp_wpp_plan( $args['post_id'] ?? 0 );
} );
add_action( 'save_post_fluent-products', 'dp_wpp_plan', 99 );

/* ------------------------------------------------------------------ */
/*  Instellingen                                                        */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
	register_setting( 'dp_webshop_prijs', 'dp_webshop_prijs_meta', [
		'type'              => 'string',
		'sanitize_callback' => function ( $v ) {
			$v = sanitize_key( (string) $v );
			return $v !== '' ? $v : 'dp_prijs';
		},
		'default'           => 'dp_prijs',
	] );
	dp_webshop_register_module_settings( 'prijs-voor-filters', 'dp_wpp_render', [
		'title'       => 'Prijs voor filters en sorteren',
		'description' => 'De laagste prijs als gewoon productveld.',
	] );
} );

/* Alles in één keer bijwerken (knop in het paneel). */
add_action( 'admin_post_dp_wpp_alles', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dp_wpp_alles' ) ) {
		wp_die( 'Geen toegang.' );
	}
	$ids = get_posts( [ 'post_type' => 'fluent-products', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ] );
	foreach ( $ids as $id ) {
		dp_wpp_sync( $id );
	}
	wp_safe_redirect( add_query_arg( 'dp_wpp_klaar', count( $ids ), admin_url( 'admin.php?page=dp-webshop#settings-prijs-voor-filters' ) ) );
	exit;
} );

function dp_wpp_render() {
	global $wpdb;
	$meta      = dp_wpp_meta();
	$producten = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'fluent-products' AND post_status IN ('publish','draft','private')" );
	$met       = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'fluent-products' AND pm.meta_key = %s", $meta ) );
	$klaar     = isset( $_GET['dp_wpp_klaar'] ) ? (int) $_GET['dp_wpp_klaar'] : null; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="dpw-kaart">
		<?php if ( null !== $klaar ) : ?>
			<p class="dpw-melding"><?php echo esc_html( sprintf( '%d producten bijgewerkt.', $klaar ) ); ?></p>
		<?php endif; ?>
		<div class="dpw-stats">
			<div class="dpw-stat"><strong><?php echo esc_html( number_format_i18n( $met ) ); ?></strong><span>met prijsveld</span></div>
			<div class="dpw-stat"><strong><?php echo esc_html( number_format_i18n( max( 0, $producten - $met ) ) ); ?></strong><span>nog zonder</span></div>
		</div>
		<form method="post" action="options.php">
			<?php settings_fields( 'dp_webshop_prijs' ); ?>
			<div class="dpw-veld">
				<strong>Naam van het veld</strong>
				<input type="text" class="regular-text" name="dp_webshop_prijs_meta" value="<?php echo esc_attr( $meta ); ?>">
				<p class="dpw-hint">Gebruik je al een veld (bijvoorbeeld uit een snippet), vul die naam dan hier in. Na een naamswijziging: "Alles bijwerken".</p>
			</div>
			<?php submit_button( 'Opslaan', 'primary', 'submit', false, [ 'class' => 'dpw-knop' ] ); ?>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px;">
			<input type="hidden" name="action" value="dp_wpp_alles">
			<?php wp_nonce_field( 'dp_wpp_alles' ); ?>
			<button type="submit" class="dpw-knop dpw-knop--licht">Alles bijwerken</button>
		</form>
		<div class="dpw-uitleg">
			<p>In Bricks: een prijsfilter (Filter - Range) met bron <em>Custom field</em> en veld <code class="dpw-code"><?php echo esc_html( $meta ); ?></code>, of een sorteeroptie op dat veld (numeriek).</p>
			<p>Het veld bevat de laagste prijs van het product, in euro's met punt als decimaalteken (bijvoorbeeld 1299.5).</p>
		</div>
	</div>
	<?php
}
