# DP Webshop

Design Pixels-modules voor webshops op **FluentCart**. Alleen installeren op sites met een winkel. Elke module staat apart aan of uit onder **DP Webshop** in het WordPress-menu. Dat menu is alleen zichtbaar voor gebruikers met een @designpixels.nl-adres, net als bij DP Toolbox.

Vereist: FluentCart en PHP 8.0 of hoger. Bricks is optioneel; sommige modules gebruiken het als het er is.

## Modules

| Groep | Module | Wat het doet |
|---|---|---|
| Catalogus | Productgegevens-scherm | Maakt het WordPress-scherm "Producten" duidelijk als aanvulling op FluentCart: een eigen naam, geen tweede "Nieuw product"-knop, en een kaartje "Productgegevens" onderaan de FluentCart-editor met de velden die FluentCart zelf niet heeft (JetEngine, specificaties), eigen knop Opslaan; titel, tekst, status en categorieën blijven van FluentCart. |
| Catalogus | Productspecificaties | Specificatietabel per product; in Bricks als `{dp_fc_specs}` (uit DP Toolbox). |
| Catalogus | Bovenliggende categorieën | Een product in een subcategorie krijgt vanzelf ook de hoofdcategorie, zodat een filter op hoofdcategorie klopt. |
| Catalogus | Productopties met meerprijs | Opties die de prijs verhogen (vinkje, keuzelijst of meerdere vinkjes onder één kop, bv. "Extra's": Inpakken + Kaartje), zoals "Opvoeren +€60". Live totaal op de productpagina; de keuze staat in winkelwagen, kassa, bestelling, mail en bon. Meerprijs rekent de server. Bewerken op het productgegevens-scherm of direct in de FluentCart-producteditor (kaartje onder Prijzen, eigen knop Opslaan). Optiebibliotheek onder Productgegevens → Opties: één keer aanmaken, per product aanvinken (leeg bedrag = standaardprijs), of in één keer per categorie of via bulkactie. |
| Catalogus | Past hierbij | Koppelt accessoires handmatig aan een product. Tonen via een Bricks-loop met een vaste klasse; `{dp_past_bij_aantal}` om de sectie te verbergen als er niets gekoppeld is. |
| Winkel & zoeken | Prijs voor filters en sorteren | Zet de laagste prijs in een gewoon veld (`dp_prijs`), zodat Bricks-filters en sortering erop werken. |
| Winkel & zoeken | Slimmer zoeken | Zoekt alleen in producten, ook op merk, categorie en eigenschappen, met Nederlandse vervoegingen. |
| Winkel & zoeken | Winkelfixes | Productfoto wisselt mee met de variant, srcset op productkaarten, kleur als filter met kleurstalen (uit DP Toolbox). |
| Verkoop | Verkoopelementen | Badges op productkaarten, kleurstalen, bezorgbelofte en voorraadlabel (uit DP Toolbox). |
| Verkoop | Winkeldashboard | Winkelkaarten op het dashboard (in het DP Toolbox-dashboard, anders als eigen widget): omzet vandaag en deze maand, te verwerken bestellingen, laatste bestellingen met status, snel een product aanmaken en voorraad bijna op. |
| Verkoop | Reviews | Productreviews met sterren, geverifieerde koop en moderatie; shortcodes en twee Bricks-elementen (uit DP Toolbox). |
| Afrekenen & verzending | Afrekenen verbeterd | Landenlijst uit de verzendzones, rustiger kassa- en winkelwagenopmaak in de huisstijl. |
| Afrekenen & verzending | Automatische verzendklasse | Nieuwe producten krijgen een verzendklasse op basis van prijs en categorie. |
| Afrekenen & verzending | Verzenddrempel | Gratis verzending vanaf een orderbedrag, optioneel met voortgangsbalk (uit DP Toolbox). |
| Taal & vindbaarheid | Nederlands | Vult ontbrekende Nederlandse FluentCart-teksten aan (uit DP Toolbox). |
| Taal & vindbaarheid | WooCommerce-URL's behouden | Categorie-adressen zoals in WooCommerce (`/product-category/hoofd/sub/`), voor een overstap zonder SEO-dip. |
| Overig | Winkelsnippets | Eigen PHP/CSS/JS voor deze ene winkel, in de database (zoals Code Snippets in DP Toolbox). Eigen zijbalk-item: DP Webshop → Winkelsnippets. Met een knop om snippets uit DP Toolbox over te nemen. |

## Overstap vanuit DP Toolbox

Zes modules kwamen uit DP Toolbox: Nederlands, Productspecificaties, Verkoopelementen, Verzenddrempel, Winkelfixes en Reviews. Vanaf DP Toolbox 2.58.0 zitten ze daar niet meer in.

- **Bij activeren** zet DP Webshop de modules aan die in DP Toolbox aan stonden. Instellingen blijven gelijk, want de optienamen zijn niet veranderd.
- **DP Toolbox 2.30.0 tot 2.58.0** heeft de modules nog. DP Webshop zet ze daar uit via het filter `dp_toolbox_module_requirements`; op de modulepagina van DP Toolbox staan ze grijs met "Verhuisd naar DP Webshop".
- **Nog oudere DP Toolbox**: laadt die een module toch, dan laadt DP Webshop zijn eigen kopie niet en meldt dat DP Toolbox bijgewerkt moet worden.
- **Winkelsnippets** uit DP Toolbox → Code Snippets verhuis je met *DP Webshop → Winkelsnippets → Nog in DP Toolbox → Aangevinkte overnemen*. Eerst hier opgeslagen, dan daar weggehaald: nooit dubbel actief, nooit kwijt.

Installeer DP Webshop vóór je DP Toolbox bijwerkt naar 2.58.0, anders zijn de winkelmodules tussendoor even weg (DP Toolbox toont dan een melding).

## Release

```bash
python3 release.py build     # ZIP van de huidige versie, niets anders
python3 release.py patch     # versie ophogen, ZIP, commit, tag (en push als er een remote is)
```

De ZIP komt in `Plugins/DP Webshop/<versie>/dp-webshop-<versie>.zip`. Vorige versies gaan naar `Archief/`.
