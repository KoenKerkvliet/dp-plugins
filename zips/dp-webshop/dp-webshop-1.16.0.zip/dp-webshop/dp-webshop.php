<?php
/**
 * Plugin Name: DP Webshop
 * Description: Design Pixels webshopmodules voor FluentCart — alleen voor sites met een winkel. Elke module apart aan of uit.
 * Version: 1.16.0
 * Author: Design Pixels
 * Text Domain: dp-webshop
 * Requires PHP: 8.0
 * Requires Plugins: fluent-cart
 * GitHub Plugin URI: KoenKerkvliet/dp-webshop
 * Primary Branch: main
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DP_WEBSHOP_VERSION', '1.16.0' );
define( 'DP_WEBSHOP_PATH', plugin_dir_path( __FILE__ ) );
define( 'DP_WEBSHOP_URL', plugin_dir_url( __FILE__ ) );

/* ------------------------------------------------------------------ */
/*  Wie ziet de plugin                                                  */
/*  Net als DP Toolbox: alleen gebruikers met een @designpixels.nl-     */
/*  adres zien het menu en de plugin-regel. De modules werken voor      */
/*  iedereen gewoon door.                                               */
/* ------------------------------------------------------------------ */

function dp_webshop_is_dp_user( $user_id = null ) {
    if ( null === $user_id ) {
        $user_id = get_current_user_id();
    }
    $user  = $user_id ? get_userdata( $user_id ) : null;
    $is_dp = $user && ! empty( $user->user_email )
        && str_ends_with( strtolower( trim( $user->user_email ) ), '@designpixels.nl' );

    return (bool) apply_filters( 'dp_webshop_is_dp_user', $is_dp, $user_id );
}

add_filter( 'all_plugins', function ( $plugins ) {
    if ( ! dp_webshop_is_dp_user() ) {
        unset( $plugins['dp-webshop/dp-webshop.php'] );
    }
    return $plugins;
}, 5 );

/* ------------------------------------------------------------------ */
/*  Omgeving                                                            */
/* ------------------------------------------------------------------ */

function dp_webshop_plugin_is_active( $bestand ) {
    if ( in_array( $bestand, (array) get_option( 'active_plugins', [] ), true ) ) {
        return true;
    }
    return is_multisite() && isset( ( (array) get_site_option( 'active_sitewide_plugins', [] ) )[ $bestand ] );
}

/** Draait FluentCart? Optie i.p.v. class_exists: dit draait al op plugins_loaded. */
function dp_webshop_fluentcart_is_available() {
    static $cached = null;
    return $cached ?? ( $cached = dp_webshop_plugin_is_active( 'fluent-cart/fluent-cart.php' ) );
}

/** Draait de site op Bricks (ook als child-thema)? */
function dp_webshop_bricks_is_available() {
    static $cached = null;
    return $cached ?? ( $cached = in_array( 'bricks', [ get_option( 'template' ), get_option( 'stylesheet' ) ], true ) );
}

/**
 * Instellingen van een module: de opgeslagen array over de standaarden heen. Zo krijgt
 * een module die er later een instelling bij krijgt vanzelf de standaardwaarde.
 */
function dp_webshop_instellingen( $optie, array $standaard ) {
    $opgeslagen = get_option( $optie, [] );
    return array_merge( $standaard, is_array( $opgeslagen ) ? $opgeslagen : [] );
}

/** Adres van een product in de FluentCart-editor. */
function dp_webshop_fluentcart_product_url( $product_id ) {
    if ( class_exists( '\FluentCart\App\Services\URL' ) && method_exists( '\FluentCart\App\Services\URL', 'getDashboardUrl' ) ) {
        return \FluentCart\App\Services\URL::getDashboardUrl( 'products/' . (int) $product_id );
    }
    return admin_url( 'admin.php?page=fluent-cart#/products/' . (int) $product_id );
}

/* ------------------------------------------------------------------ */
/*  Modules                                                             */
/* ------------------------------------------------------------------ */

function dp_webshop_get_module_info( $module_file ) {
    return get_file_data( $module_file, [
        'name'        => 'Module Name',
        'description' => 'Description',
        'version'     => 'Version',
        'category'    => 'Category',
        'requires'    => 'Requires',
        'vervalt'     => 'Vervalt zodra',
    ] );
}

function dp_webshop_get_available_modules() {
    $modules = [];
    foreach ( glob( DP_WEBSHOP_PATH . 'modules/*/' ) ?: [] as $pad ) {
        $slug    = basename( $pad );
        $bestand = $pad . $slug . '.php';
        if ( ! file_exists( $bestand ) ) {
            continue;
        }
        $info             = dp_webshop_get_module_info( $bestand );
        $modules[ $slug ] = [
            'slug'        => $slug,
            'file'        => $bestand,
            'name'        => $info['name'] ?: $slug,
            'description' => $info['description'] ?: '',
            'version'     => $info['version'] ?: '',
            'category'    => $info['category'] ?: '',
            'requires'    => strtolower( trim( $info['requires'] ?: '' ) ),
            'vervalt'     => trim( $info['vervalt'] ?: '' ),
        ];
    }
    ksort( $modules );
    return $modules;
}

function dp_webshop_get_enabled_modules() {
    return (array) get_option( 'dp_webshop_enabled_modules', [] );
}

function dp_webshop_is_module_enabled( $slug ) {
    return in_array( $slug, dp_webshop_get_enabled_modules(), true );
}

/**
 * Vereiste van een module (header `Requires:`), of null als er geen is.
 * Bekend: `bricks`. Een onbekende waarde blokkeert niets.
 *
 * @return array|null [ 'met' => bool, 'reason' => string ]
 */
function dp_webshop_check_requirement( $vereist ) {
    if ( $vereist === 'bricks' ) {
        return [
            'met'    => dp_webshop_bricks_is_available(),
            'reason' => 'Vereist het Bricks-thema. Niet gevonden op deze site.',
        ];
    }
    return null;
}

function dp_webshop_module_requirement_met( $slug ) {
    $bestand = DP_WEBSHOP_PATH . 'modules/' . $slug . '/' . $slug . '.php';
    if ( ! file_exists( $bestand ) ) {
        return false;
    }
    $oordeel = dp_webshop_check_requirement( strtolower( trim( dp_webshop_get_module_info( $bestand )['requires'] ?? '' ) ) );
    return null === $oordeel || ! empty( $oordeel['met'] );
}

/* ------------------------------------------------------------------ */
/*  Overgang vanuit DP Toolbox                                          */
/*  Zes modules kwamen uit DP Toolbox. Normaal zet het filter hieronder */
/*  ze daar uit. Laadt een oude DP Toolbox ze toch, dan laden wij onze  */
/*  kopie niet: twee keer dezelfde module geeft dubbele badges of een   */
/*  fatale fout. Elke module definieert een eigen versieconstante;      */
/*  staat die er al, dan heeft DP Toolbox hem geladen.                  */
/* ------------------------------------------------------------------ */

function dp_webshop_verhuisde_modules() {
    // slug hier => [ slug in DP Toolbox, constante die de module definieert ]
    return [
        'nederlands'           => [ 'fluentcart-nederlands', 'DP_FCNL_VERSION' ],
        'productspecificaties' => [ 'fluentcart-productspecificaties', 'DP_FCPS_VERSION' ],
        'verkoopelementen'     => [ 'fluentcart-verkoopelementen', 'DP_FCVE_VERSION' ],
        'verzenddrempel'       => [ 'fluentcart-verzenddrempel', 'DP_FCVD_VERSION' ],
        'winkelfixes'          => [ 'fluentcart-winkelfixes', 'DP_FCWF_VERSION' ],
        'reviews'              => [ 'reviews', 'DP_REVIEWS_VERSION' ],
    ];
}

/**
 * Eerste keer: de modules die in DP Toolbox aan stonden, hier ook aanzetten.
 * Instellingen hoeven niet mee: de modules gebruiken dezelfde optienamen.
 */
function dp_webshop_neem_modules_over() {
    if ( false !== get_option( 'dp_webshop_enabled_modules', false ) ) {
        return;
    }
    $toolbox = (array) get_option( 'dp_toolbox_enabled_modules', [] );
    $aan     = [];
    foreach ( dp_webshop_verhuisde_modules() as $slug => [ $oud ] ) {
        if ( in_array( $oud, $toolbox, true ) ) {
            $aan[] = $slug;
        }
    }
    update_option( 'dp_webshop_enabled_modules', $aan );
}
register_activation_hook( __FILE__, 'dp_webshop_neem_modules_over' );
add_action( 'plugins_loaded', 'dp_webshop_neem_modules_over', 5 );

/**
 * DP Toolbox (vanaf 2.30.0) de verhuisde modules laten overslaan, via zijn eigen filter
 * voor modulevereisten: daar laadt hij ze dan niet meer, en zijn modulepagina toont ze
 * grijs met de reden. Zo hoeft DP Toolbox zelf niet aangepast te worden.
 */
add_filter( 'dp_toolbox_module_requirements', function ( $reqs ) {
    if ( ! dp_webshop_fluentcart_is_available() ) {
        return $reqs;
    }
    foreach ( dp_webshop_verhuisde_modules() as [ $oud ] ) {
        $reqs[ $oud ] = [
            'met'    => false,
            'reason' => 'Verhuisd naar DP Webshop. Zet hem daar aan; de instellingen zijn meegegaan.',
        ];
    }
    return $reqs;
} );

/** Modules die DP Toolbox in deze request toch al geladen heeft (versie vóór 2.30.0). */
function dp_webshop_modules_via_toolbox() {
    global $dp_webshop_via_toolbox;
    return (array) $dp_webshop_via_toolbox;
}

/**
 * Laden. Priority 20: ná DP Toolbox (10), zodat we kunnen zien wat daar al draait.
 */
add_action( 'plugins_loaded', function () {
    global $dp_webshop_via_toolbox;
    $dp_webshop_via_toolbox = [];

    if ( ! dp_webshop_fluentcart_is_available() ) {
        return; // melding: zie hieronder
    }

    $verhuisd = dp_webshop_verhuisde_modules();

    foreach ( dp_webshop_get_enabled_modules() as $slug ) {
        if ( isset( $verhuisd[ $slug ] ) && defined( $verhuisd[ $slug ][1] ) ) {
            $dp_webshop_via_toolbox[] = $slug;
            continue;
        }
        if ( ! dp_webshop_module_requirement_met( $slug ) ) {
            continue;
        }
        $bestand = DP_WEBSHOP_PATH . 'modules/' . $slug . '/' . $slug . '.php';
        if ( file_exists( $bestand ) ) {
            require_once $bestand;
        }
    }
}, 20 );

add_action( 'admin_notices', function () {
    $scherm = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( ! dp_webshop_is_dp_user() || ! $scherm || ! in_array( $scherm->id, [ 'plugins', 'toplevel_page_dp-webshop' ], true ) ) {
        return;
    }
    if ( ! dp_webshop_fluentcart_is_available() ) {
        echo '<div class="notice notice-warning"><p><strong>DP Webshop</strong> doet niets zonder FluentCart. Activeer FluentCart, of zet DP Webshop uit op deze site.</p></div>';
        return;
    }
    $via = dp_webshop_modules_via_toolbox();
    if ( $via ) {
        printf(
            '<div class="notice notice-info"><p><strong>DP Webshop:</strong> %s %s nog via DP Toolbox. Werk DP Toolbox bij, dan neemt DP Webshop %s vanzelf over; de instellingen blijven gelijk.</p></div>',
            esc_html( implode( ', ', $via ) ),
            count( $via ) === 1 ? 'draait' : 'draaien',
            count( $via ) === 1 ? 'hem' : 'ze'
        );
    }
} );

/* Beheer */
require_once DP_WEBSHOP_PATH . 'includes/admin-ui.php';
require_once DP_WEBSHOP_PATH . 'includes/settings-page.php';
require_once DP_WEBSHOP_PATH . 'includes/dp-menu-groep.php'; // gedeeld met alle DP-plugins
