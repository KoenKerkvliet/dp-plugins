<?php
/**
 * DP Webshop — modulepagina. Opbouw en uiterlijk overgenomen van DP Toolbox, zodat
 * beide plugins hetzelfde aanvoelen; alleen het tabblad Modules.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ------------------------------------------------------------------ */
/*  Access control helpers                                             */
/* ------------------------------------------------------------------ */

/**
 * Wie mag DP Webshop zien en gebruiken?
 *
 * Uitsluitend ingelogde gebruikers met een @designpixels.nl-adres. Bewust geen
 * instelling per rol of per gebruiker: dat is een deur die per ongeluk open kan
 * blijven staan. Andere beheerders zien het menu niet en zien de plugin niet op
 * de plugin-pagina; de modules blijven voor hen wel gewoon werken.
 */
function dp_webshop_current_user_has_access() {
    $user = wp_get_current_user();
    if ( ! $user || ! $user->ID ) return false;

    return dp_webshop_is_dp_user( $user->ID );
}

/* ------------------------------------------------------------------ */
/*  Register settings                                                  */
/* ------------------------------------------------------------------ */

add_action( 'admin_init', function () {
    register_setting( 'dp_webshop_settings', 'dp_webshop_enabled_modules', [
        'type'              => 'array',
        'sanitize_callback' => function ( $input ) {
            $input = is_array( $input ) ? array_map( 'sanitize_key', $input ) : [];
            // Harde gate: een module met een onvervulde vereiste kan nooit
            // aangezet worden, ook niet door een geknutselde POST.
            return array_values( array_filter( $input, 'dp_webshop_module_requirement_met' ) );
        },
        'default' => [],
    ] );
} );

/* ------------------------------------------------------------------ */
/*  Menu registration with access control                              */
/* ------------------------------------------------------------------ */

add_action( 'admin_menu', function () {
    // Always register with manage_options, we handle visibility ourselves
    add_menu_page(
        'DP Webshop',
        'DP Webshop',
        'manage_options',
        'dp-webshop',
        'dp_webshop_settings_page',
        'dashicons-cart',
        '3.5' // Direct onder DP Toolbox (3)
    );
    add_submenu_page(
        'dp-webshop',
        'Modules',
        'Modules',
        'manage_options',
        'dp-webshop'
    );
}, 9 );

// Sort submenu items alphabetically (after all modules registered their pages)
add_action( 'admin_menu', function () {
    global $submenu;
    if ( empty( $submenu['dp-webshop'] ) ) return;

    // Eerste item ("Modules") behouden bovenaan
    $first = array_shift( $submenu['dp-webshop'] );
    usort( $submenu['dp-webshop'], function ( $a, $b ) {
        return strcasecmp( $a[0], $b[0] );
    } );
    array_unshift( $submenu['dp-webshop'], $first );
}, 999 );

// Hide menu for users without access
add_action( 'admin_menu', function () {
    if ( ! dp_webshop_current_user_has_access() ) {
        remove_menu_page( 'dp-webshop' );
    }
}, PHP_INT_MAX );

/* Settings link on Plugins page */
add_filter( 'plugin_action_links_dp-webshop/dp-webshop.php', function ( $links ) {
    $url  = admin_url( 'admin.php?page=dp-webshop' );
    $link = '<a href="' . esc_url( $url ) . '">Instellingen</a>';
    array_unshift( $links, $link );
    return $links;
} );

/* ------------------------------------------------------------------ */
/*  Pagina                                                              */
/* ------------------------------------------------------------------ */

function dp_webshop_settings_page() {
    if ( ! dp_webshop_current_user_has_access() ) {
        wp_die( 'Je hebt geen toegang tot deze pagina.' );
    }

    $tab      = 'modules';
    $base_url = admin_url( 'admin.php?page=dp-webshop' );

    // Pre-calculate module counts for header display
    $all_modules  = dp_webshop_get_available_modules();
    $enabled_mods = dp_webshop_get_enabled_modules();
    $active_count = count( array_intersect( array_keys( $all_modules ), $enabled_mods ) );
    $total_count  = count( $all_modules );
    ?>
    <div class="wrap dp-webshop-settings">

        <style>
            .dp-webshop-settings { max-width: 1100px; }

            .dp-webshop-header {
                background: linear-gradient(135deg, #1a1235 0%, #281E5D 40%, #3d2d7a 100%);
                color: #fff;
                padding: 24px 32px 0;
                border-radius: 10px 10px 0 0;
                margin-bottom: 0;
            }
            .dp-webshop-header h1 { margin: 0 0 4px; font-size: 22px; font-weight: 700; color: #fff; }
            .dp-webshop-header p  { margin: 0 0 18px; opacity: 0.7; font-size: 13px; }

            .dp-webshop-tabs {
                display: flex; gap: 0; margin: 0; padding: 0; list-style: none; flex: 1;
            }
            .dp-webshop-tab-bar {
                display: flex; align-items: flex-end;
            }
            .dp-header-actions {
                display: flex; align-items: center; gap: 14px;
                margin-left: auto; padding: 6px 0 10px;
            }
            .dp-header-counter {
                font-size: 13px; color: rgba(255,255,255,0.6);
            }
            .dp-header-counter strong {
                color: #fff; font-weight: 700; font-size: 15px;
            }
            .dp-header-actions .button-primary {
                background: rgba(255,255,255,0.15) !important; border-color: rgba(255,255,255,0.25) !important;
                color: #fff !important; font-size: 12px !important; padding: 4px 18px !important;
                border-radius: 6px !important; height: auto !important; line-height: 1.6 !important;
            }
            .dp-header-actions .button-primary:hover {
                background: rgba(255,255,255,0.25) !important;
            }
            .dp-webshop-tabs a {
                display: flex; align-items: center; gap: 6px;
                padding: 10px 22px; color: rgba(255,255,255,0.55); text-decoration: none;
                font-size: 13px; font-weight: 500;
                border-bottom: 3px solid transparent; transition: all 0.2s; white-space: nowrap;
            }
            .dp-webshop-tabs a:hover { color: rgba(255,255,255,0.85); background: rgba(255,255,255,0.05); }
            .dp-webshop-tabs a.active { color: #fff; border-bottom-color: #c4b5fd; }
            .dp-webshop-tabs .dashicons { font-size: 15px; width: 15px; height: 15px; line-height: 15px; }

            .dp-webshop-content {
                background: #f0f0f1; border-radius: 0 0 10px 10px;
                padding: 24px 32px; border: 1px solid #ddd; border-top: none;
            }

            /* Toggle switch (shared) */
            .dp-toggle input[type="checkbox"] { display: none; }
            .dp-toggle label {
                display: block; width: 42px; height: 22px; background: #ccc;
                border-radius: 11px; position: relative; cursor: pointer; transition: background 0.2s; flex-shrink: 0;
            }
            .dp-toggle label::after {
                content: ''; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px;
                background: #fff; border-radius: 50%; transition: transform 0.2s; box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            }
            .dp-toggle input:checked + label { background: #281E5D; }
            .dp-toggle input:checked + label::after { transform: translateX(20px); }

            /* Admin settings */
            .dp-admin-section { margin-bottom: 32px; }
            .dp-admin-section h2 {
                font-size: 15px; font-weight: 700; color: #1d2327;
                margin: 0 0 6px; padding-bottom: 8px; border-bottom: 2px solid #281E5D;
            }
            .dp-admin-section p.desc { margin: 0 0 12px; font-size: 13px; color: #666; }

            /* Buttons */
            .dp-webshop-settings .submit { margin-top: 8px; }
            .dp-webshop-settings .button-primary {
                background: #281E5D; border-color: #281E5D; border-radius: 6px;
                padding: 6px 22px; font-size: 13px; height: auto; line-height: 1.6;
            }
            .dp-webshop-settings .button-primary:hover,
            .dp-webshop-settings .button-primary:focus { background: #4a3a8a; border-color: #4a3a8a; }
        </style>

        <h1 class="dp-webshop-notice-anchor" style="margin:0;padding:0;height:0;overflow:hidden;"></h1>

        <div class="dp-webshop-header">
            <h1><img src="<?php echo esc_url( DP_WEBSHOP_URL . 'assets/dp-icon.png' ); ?>" alt="" style="width:28px;height:28px;vertical-align:middle;margin-right:10px;border-radius:6px;">DP Webshop</h1>
            <p>Design Pixels webshopmodules voor FluentCart</p>
            <div class="dp-webshop-tab-bar">
                <nav class="dp-webshop-tabs">
                    <a href="<?php echo esc_url( $base_url ); ?>" class="active">
                        <span class="dashicons dashicons-admin-plugins"></span> Modules
                    </a>
                </nav>
                <div class="dp-header-actions" id="dp-header-actions">
                        <?php if ( $tab === 'modules' ) : ?>
                            <span class="dp-header-counter"><strong><?php echo $active_count; ?></strong> / <?php echo $total_count; ?> actief</span>
                            <button type="submit" form="dp-modules-form" class="button button-primary">Opslaan</button>
                        <?php endif; ?>
                    </div>
            </div>
        </div>

        <div class="dp-webshop-content">
            <?php dp_webshop_render_modules_tab(); ?>
        </div>
    </div>
    <?php
}

/* ------------------------------------------------------------------ */
/*  Modules tab                                                        */
/* ------------------------------------------------------------------ */

function dp_webshop_render_modules_tab() {
    $modules      = dp_webshop_get_available_modules();
    $enabled      = dp_webshop_get_enabled_modules();
    $via_toolbox  = dp_webshop_modules_via_toolbox();

    // Meldingen per module (bv. "draait nog via DP Toolbox").
    $notices = [];
    foreach ( $via_toolbox as $slug ) {
        $notices[ $slug ] = 'Draait nu nog via DP Toolbox. Werk DP Toolbox bij, dan neemt DP Webshop deze module over met dezelfde instellingen.';
    }
    $notices = apply_filters( 'dp_webshop_module_notices', $notices );

    // Onvervulde vereisten (header "Requires:").
    $requirements = [];
    foreach ( $modules as $slug => $module ) {
        $oordeel = dp_webshop_check_requirement( $module['requires'] );
        if ( $oordeel && empty( $oordeel['met'] ) ) {
            $requirements[ $slug ] = $oordeel;
        }
    }

    /*
     * De categorie staat in de module-header ("Category: winkel"), niet in een
     * lijst hier. Onbekend of leeg belandt zichtbaar in "Overig".
     */
    $categories = [
        'catalogus' => [ 'label' => 'Catalogus',               'icon' => 'dashicons-products' ],
        'winkel'    => [ 'label' => 'Winkel & zoeken',         'icon' => 'dashicons-store' ],
        'verkoop'   => [ 'label' => 'Verkoop',                 'icon' => 'dashicons-megaphone' ],
        'afrekenen' => [ 'label' => 'Afrekenen & verzending',  'icon' => 'dashicons-cart' ],
        'taal-seo'  => [ 'label' => 'Taal & vindbaarheid',     'icon' => 'dashicons-translation' ],
        'other'     => [ 'label' => 'Overig',                  'icon' => 'dashicons-marker' ],
    ];

    $grouped = [];
    foreach ( $modules as $slug => $module ) {
        $cat = $module['category'] ?? '';
        // Onbekende of ontbrekende categorie belandt zichtbaar in "Overig",
        // niet stilzwijgend tussen de rest.
        if ( ! isset( $categories[ $cat ] ) ) {
            $cat = 'other';
        }
        $grouped[ $cat ][ $slug ] = $module;
    }
    foreach ( $grouped as &$group ) {
        uasort( $group, function ( $a, $b ) { return strcasecmp( $a['name'], $b['name'] ); } );
    }
    unset( $group );

    $active_count = count( array_intersect( array_keys( $modules ), $enabled ) );
    $total_count  = count( $modules );
    $first_cat    = array_key_first( $categories );
    ?>
    <style>
        /* --- Sidebar layout --- */
        .dp-modules-layout {
            display: flex; gap: 0; min-height: 400px;
            margin: -24px -32px; /* bleed into .dp-webshop-content padding */
        }

        /* --- Sidebar --- */
        .dp-modules-sidebar {
            width: 240px; flex-shrink: 0;
            background: #fff; border-right: 1px solid #e0e0e0;
            display: flex; flex-direction: column;
            border-radius: 0 0 0 10px;
        }
        .dp-sidebar-nav {
            flex: 1; padding: 16px 0; display: flex; flex-direction: column; gap: 2px;
        }
        .dp-sidebar-item {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 18px; cursor: pointer;
            font-size: 13px; font-weight: 500; color: #666;
            border-left: 3px solid transparent;
            transition: all 0.15s;
            text-decoration: none;
        }
        .dp-sidebar-item:hover {
            color: #1d2327; background: #f8f7fc;
        }
        .dp-sidebar-item.is-active {
            color: #281E5D; font-weight: 600; background: #f3f0ff;
            border-left-color: #281E5D;
        }
        .dp-sidebar-item .dashicons {
            font-size: 16px; width: 16px; height: 16px; line-height: 16px;
            color: inherit; opacity: 0.6;
        }
        .dp-sidebar-item.is-active .dashicons { opacity: 1; }
        .dp-sidebar-count {
            margin-left: auto; font-size: 11px; color: #aaa;
            background: #f0f0f1; padding: 1px 8px; border-radius: 10px;
        }
        .dp-sidebar-item.is-active .dp-sidebar-count {
            background: #eee8ff; color: #281E5D;
        }

        /* --- Main content --- */
        .dp-modules-main {
            flex: 1; padding: 24px 28px; min-width: 0;
        }
        .dp-cat-panel { display: none; }
        .dp-cat-panel.is-visible { display: block; }

        .dp-cat-panel-header {
            display: flex; align-items: center; gap: 8px;
            margin: 0 0 16px; padding-bottom: 10px;
            border-bottom: 2px solid #281E5D;
        }
        .dp-cat-panel-header .dashicons { color: #281E5D; font-size: 18px; width: 18px; height: 18px; }
        .dp-cat-panel-header h2 { margin: 0; font-size: 15px; font-weight: 700; color: #1d2327; }

        .dp-module-list {
            display: flex; flex-direction: column; gap: 8px;
        }

        .dp-module-card {
            background: #fff; border: 1px solid #e0e0e0; border-radius: 8px;
            padding: 14px 16px; display: flex; align-items: center; gap: 12px;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .dp-module-card:hover { border-color: #281E5D; box-shadow: 0 2px 8px rgba(40,30,93,0.08); }
        .dp-module-card.is-active  { border-left: 3px solid #281E5D; }
        .dp-module-card.is-inactive { opacity: 0.55; }
        .dp-module-card.is-inactive:hover { opacity: 1; }

        /* Module die op deze site niet aangezet kan worden (vereiste niet vervuld) */
        .dp-module-card.is-blocked { opacity: 1; background: #fafafa; border-style: dashed; }
        .dp-module-card.is-blocked:hover { border-color: #e0e0e0; box-shadow: none; }
        .dp-module-card.is-blocked .dp-toggle { opacity: 0.35; pointer-events: none; }
        .dp-module-card.is-blocked h3 { color: #777; }
        .dp-module-vervalt { display: flex; align-items: flex-start; gap: 4px; margin: 3px 0 0 !important; font-size: 11px !important; line-height: 1.4; color: #8a8497 !important; }
        .dp-module-vervalt .dashicons { flex-shrink: 0; width: 13px; height: 13px; margin-top: 1px; font-size: 13px; color: #b3aac7; }
        .dp-vervalt-uitleg { display: flex; align-items: flex-start; gap: 6px; margin: 0 0 14px; padding: 10px 14px; border: 1px solid #e4e0ef; border-radius: 8px; background: #f9f8fc; font-size: 12px; line-height: 1.5; color: #50575e; }
        .dp-vervalt-uitleg .dashicons { flex-shrink: 0; width: 16px; height: 16px; font-size: 16px; color: #281E5D; }
        .dp-module-blocked {
            margin: 4px 0 0; font-size: 12px; line-height: 1.4; color: #8a6d1f;
        }

        .dp-module-info { flex: 1; min-width: 0; }
        .dp-module-info h3 { margin: 0; font-size: 13px; font-weight: 600; color: #1d2327; }
        .dp-module-info h3 .dp-version { color: #bbb; font-size: 10px; font-weight: 400; margin-left: 4px; }
        .dp-module-info p {
            margin: 3px 0 0; color: #888; font-size: 12px; line-height: 1.5;
        }

        .dp-module-icons {
            display: flex; gap: 6px; align-items: center; flex-shrink: 0;
        }
        .dp-module-tip {
            position: relative; cursor: help;
            color: #bbb; font-size: 16px; line-height: 1;
            transition: color 0.15s;
        }
        .dp-module-tip:hover { color: #281E5D; }
        .dp-module-tip .dashicons { font-size: 16px; width: 16px; height: 16px; }
        .dp-module-tip .dp-module-tip-text {
            display: none; position: absolute; right: -8px; top: 28px; z-index: 10;
            background: #1d2327; color: #fff; font-size: 12px; font-weight: 400;
            padding: 8px 12px; border-radius: 6px; width: 260px; white-space: normal; line-height: 1.5;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        }
        .dp-module-tip .dp-module-tip-text::before {
            content: ''; position: absolute; top: -6px; right: 12px;
            border-left: 6px solid transparent; border-right: 6px solid transparent;
            border-bottom: 6px solid #1d2327;
        }
        .dp-module-tip:hover .dp-module-tip-text { display: block; }

        .dp-module-warn {
            position: relative; cursor: help;
            color: #c48a00; font-size: 16px; line-height: 1;
        }
        .dp-module-warn .dashicons { font-size: 16px; width: 16px; height: 16px; }
        .dp-module-warn .dp-module-warn-tip {
            display: none; position: absolute; right: -8px; top: 28px; z-index: 10;
            background: #1d2327; color: #fff; font-size: 12px; font-weight: 400;
            padding: 8px 12px; border-radius: 6px; width: 240px; white-space: normal; line-height: 1.5;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        }
        .dp-module-warn .dp-module-warn-tip::before {
            content: ''; position: absolute; top: -6px; right: 12px;
            border-left: 6px solid transparent; border-right: 6px solid transparent;
            border-bottom: 6px solid #1d2327;
        }
        .dp-module-warn:hover .dp-module-warn-tip { display: block; }

        /* Settings (gear) button — only on active modules with inline settings */
        .dp-module-settings-btn {
            background: none; border: 1px solid transparent; border-radius: 4px;
            color: #bbb; cursor: pointer; padding: 2px 4px; line-height: 1;
            display: inline-flex; align-items: center; transition: all 0.15s;
        }
        .dp-module-settings-btn:hover {
            color: #281E5D; border-color: #d8d3eb; background: #f5f3fb;
        }
        .dp-module-settings-btn.is-open {
            color: #281E5D; background: #eee8ff; border-color: #c4b5fd;
        }
        .dp-module-settings-btn .dashicons { font-size: 16px; width: 16px; height: 16px; }

        /* Inline settings panel container (under modules layout) */
        .dp-inline-settings-wrap {
            margin: 24px -32px -24px;  /* bleed into .dp-webshop-content padding */
            padding: 0;
            border-top: 1px solid #e0e0e0;
            background: #fff;
            border-radius: 0 0 10px 10px;
            display: none;
        }
        .dp-inline-settings-wrap.is-open { display: block; }
        .dp-inline-panel {
            display: none;
            padding: 22px 32px;
        }
        .dp-inline-panel.is-visible { display: block; }
        .dp-inline-panel-header {
            display: flex; align-items: center; gap: 10px;
            margin: 0 0 16px; padding-bottom: 12px;
            border-bottom: 2px solid #281E5D;
        }
        .dp-inline-panel-header h2 {
            margin: 0; font-size: 16px; font-weight: 700; color: #1d2327; flex: 1;
        }
        .dp-inline-panel-header .dp-inline-panel-desc {
            font-size: 12px; color: #888; font-weight: 400;
            margin-left: 8px;
        }
        .dp-inline-panel-close {
            background: none; border: 1px solid #ddd; border-radius: 4px;
            color: #888; cursor: pointer; padding: 3px 9px; font-size: 16px;
            line-height: 1; transition: all 0.15s;
        }
        .dp-inline-panel-close:hover {
            border-color: #d63638; color: #d63638;
        }
        /* Reset module-page styles that fight with inline context */
        .dp-inline-panel .dp-page-wrap { max-width: none; padding: 0; margin: 0; }
        .dp-inline-panel .dp-page-header,
        .dp-inline-panel .dp-page-content { background: transparent; padding: 0; border: none; border-radius: 0; }
        .dp-inline-panel .dp-page-header { display: none; }

        /* --- Zoeken --- */
        .dp-module-search { position: relative; padding: 12px; border-bottom: 1px solid #e0e0e0; }
        .dp-module-search .dashicons {
            position: absolute; left: 21px; top: 50%; transform: translateY(-50%);
            color: #8c8f94; font-size: 17px; width: 17px; height: 17px; pointer-events: none;
        }
        .dp-module-search input {
            width: 100%; padding: 6px 8px 6px 30px; border: 1px solid #dcdcde; border-radius: 4px;
            font-size: 13px; line-height: 1.5; box-shadow: none;
        }
        .dp-module-search input:focus { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; outline: none; }

        /* Tijdens het zoeken tonen we alle categorieën onder elkaar, met een
           kopje per categorie, zodat je meteen ziet waar een module thuishoort. */
        .dp-modules-main.is-searching .dp-cat-panel { display: block; }
        .dp-modules-main.is-searching .dp-cat-panel.is-empty { display: none; }
        .dp-modules-main.is-searching .dp-module-card.is-hidden { display: none; }
        .dp-search-empty {
            display: none; padding: 40px 24px; text-align: center; color: #646970; font-size: 14px;
        }
        .dp-modules-main.is-searching.has-no-results .dp-search-empty { display: block; }

        /* --- Gedeelde opmaak voor de instellingenpanelen van de nieuwe modules --- */
        .dpw-kaart { background: #fff; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; }
        .dpw-stats { display: flex; gap: 16px; margin-bottom: 22px; }
        .dpw-stat { flex: 1; background: #f8f7fc; border-radius: 8px; padding: 14px; text-align: center; }
        .dpw-stat strong { display: block; font-size: 26px; line-height: 1; color: #281E5D; margin-bottom: 4px; }
        .dpw-stat span { font-size: 11px; color: #666; text-transform: uppercase; letter-spacing: .5px; }
        .dpw-veld { margin-bottom: 20px; }
        .dpw-veld > strong { display: block; font-size: 13px; margin-bottom: 8px; color: #1d2327; }
        .dpw-veld label { display: block; margin-bottom: 6px; font-size: 14px; }
        .dpw-hint { font-size: 12px; color: #777; margin: 4px 0 0; line-height: 1.5; }
        .dpw-knop { background: #281E5D; color: #fff; border: 0; border-radius: 6px; padding: 8px 24px; font-size: 14px; font-weight: 600; cursor: pointer; }
        .dpw-knop:hover { background: #4a3a8a; color: #fff; }
        .dpw-knop--licht { background: #fff; color: #281E5D; border: 1px solid #d8d3eb; }
        .dpw-knop--licht:hover { background: #f5f3fb; color: #281E5D; }
        .dpw-code { background: #f4f4f6; border: 1px solid #e2e2e6; border-radius: 5px; padding: 2px 6px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; }
        .dpw-uitleg { border-top: 1px solid #eee; margin-top: 22px; padding-top: 16px; font-size: 13px; color: #555; }
        .dpw-uitleg p { margin: 0 0 8px; }
        .dpw-tabel { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .dpw-tabel th { text-align: left; font-size: 12px; color: #666; font-weight: 600; padding: 0 8px 6px 0; }
        .dpw-tabel td { padding: 4px 8px 4px 0; vertical-align: middle; }
        .dpw-melding { background: #f3f0ff; border-left: 3px solid #281E5D; border-radius: 0 6px 6px 0; padding: 10px 12px; font-size: 13px; margin: 0 0 18px; }
    </style>

    <form id="dp-modules-form" method="post" action="options.php">
        <?php settings_fields( 'dp_webshop_settings' ); ?>

        <div class="dp-modules-layout">
            <!-- Sidebar -->
            <div class="dp-modules-sidebar">
                <div class="dp-module-search">
                    <span class="dashicons dashicons-search"></span>
                    <input type="search" id="dp-module-search" placeholder="Zoek een module&hellip;"
                           autocomplete="off" aria-label="Zoek een module">
                </div>
                <nav class="dp-sidebar-nav">
                    <?php foreach ( $categories as $cat_key => $cat ) :
                        if ( empty( $grouped[ $cat_key ] ) ) continue;
                        $cat_active = count( array_intersect( array_keys( $grouped[ $cat_key ] ), $enabled ) );
                    ?>
                        <a class="dp-sidebar-item<?php echo $cat_key === $first_cat ? ' is-active' : ''; ?>"
                           href="#<?php echo esc_attr( $cat_key ); ?>"
                           data-cat="<?php echo esc_attr( $cat_key ); ?>">
                            <span class="dashicons <?php echo esc_attr( $cat['icon'] ); ?>"></span>
                            <?php echo esc_html( $cat['label'] ); ?>
                            <span class="dp-sidebar-count"><?php echo $cat_active; ?>/<?php echo count( $grouped[ $cat_key ] ); ?></span>
                        </a>
                    <?php endforeach; ?>
                </nav>
            </div>

            <!-- Module panels -->
            <div class="dp-modules-main">
                <?php if ( array_filter( array_column( $all_modules ?? dp_webshop_get_available_modules(), 'vervalt' ) ) ) : ?>
                    <p class="dp-vervalt-uitleg">
                        <span class="dashicons dashicons-clock"></span>
                        Modules met een klokje vullen FluentCart tijdelijk aan. Kijk bij elke FluentCart-update in de changelog of FluentCart het nu zelf kan; zet de module dan uit.
                    </p>
                <?php endif; ?>
                <?php foreach ( $categories as $cat_key => $cat ) :
                    if ( empty( $grouped[ $cat_key ] ) ) continue;
                    $cat_modules = $grouped[ $cat_key ];
                ?>
                    <div class="dp-cat-panel<?php echo $cat_key === $first_cat ? ' is-visible' : ''; ?>"
                         data-category="<?php echo esc_attr( $cat_key ); ?>">
                        <div class="dp-cat-panel-header">
                            <span class="dashicons <?php echo esc_attr( $cat['icon'] ); ?>"></span>
                            <h2><?php echo esc_html( $cat['label'] ); ?></h2>
                        </div>
                        <div class="dp-module-list">
                            <?php foreach ( $cat_modules as $slug => $module ) :
                                $is_active  = in_array( $slug, $enabled, true );
                                $has_notice = isset( $notices[ $slug ] );
                                $req        = $requirements[ $slug ] ?? null;
                                $blocked    = $req && empty( $req['met'] );
                            ?>
                                <div class="dp-module-card <?php echo $is_active ? 'is-active' : 'is-inactive'; ?><?php echo $blocked ? ' is-blocked' : ''; ?>"
                                     data-zoek="<?php echo esc_attr( strtolower( $module['name'] . ' ' . $module['description'] . ' ' . $slug . ' ' . ( $module['vervalt'] ?? '' ) ) ); ?>">
                                    <div class="dp-toggle">
                                        <input type="checkbox"
                                               id="dp-module-<?php echo esc_attr( $slug ); ?>"
                                               name="dp_webshop_enabled_modules[]"
                                               value="<?php echo esc_attr( $slug ); ?>"
                                               <?php checked( $is_active && ! $blocked ); ?>
                                               <?php disabled( $blocked ); ?>>
                                        <label for="dp-module-<?php echo esc_attr( $slug ); ?>"></label>
                                    </div>
                                    <div class="dp-module-info">
                                        <h3>
                                            <?php echo esc_html( $module['name'] ); ?>
                                            <span class="dp-version">v<?php echo esc_html( $module['version'] ); ?></span>
                                        </h3>
                                        <?php if ( ! empty( $module['vervalt'] ) ) : ?>
                                            <p class="dp-module-vervalt" title="Tijdelijke aanvulling op FluentCart">
                                                <span class="dashicons dashicons-clock"></span>Vervalt zodra <?php echo esc_html( $module['vervalt'] ); ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ( $blocked ) : ?>
                                            <p class="dp-module-blocked"><?php echo esc_html( $req['reason'] ); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dp-module-icons">
                                        <?php if ( $is_active && dp_webshop_has_inline_settings( $slug ) ) : ?>
                                            <button type="button"
                                                    class="dp-module-settings-btn"
                                                    data-module="<?php echo esc_attr( $slug ); ?>"
                                                    title="Instellingen">
                                                <span class="dashicons dashicons-admin-generic"></span>
                                            </button>
                                        <?php endif; ?>
                                        <?php if ( $has_notice ) : ?>
                                            <span class="dp-module-warn">
                                                <span class="dashicons dashicons-warning"></span>
                                                <span class="dp-module-warn-tip"><?php echo esc_html( $notices[ $slug ] ); ?></span>
                                            </span>
                                        <?php endif; ?>
                                        <?php if ( ! empty( $module['description'] ) ) : ?>
                                            <span class="dp-module-tip">
                                                <span class="dashicons dashicons-info-outline"></span>
                                                <span class="dp-module-tip-text"><?php echo esc_html( $module['description'] ); ?></span>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <p class="dp-search-empty">Geen module gevonden. Probeer een ander zoekwoord.</p>
            </div>
        </div>
    </form>

    <?php
    /* ----------------------------------------------------------------- */
    /*  Inline settings panels — pre-rendered, hidden by default          */
    /* ----------------------------------------------------------------- */
    $inline_settings = dp_webshop_get_inline_settings();
    // Filter: only render panels for modules that are currently enabled
    $inline_settings = array_filter( $inline_settings, function ( $cfg, $slug ) use ( $enabled ) {
        return in_array( $slug, $enabled, true ) && is_callable( $cfg['callback'] );
    }, ARRAY_FILTER_USE_BOTH );
    ?>
    <?php if ( ! empty( $inline_settings ) ) : ?>
        <div class="dp-inline-settings-wrap" id="dp-inline-settings-wrap">
            <?php foreach ( $inline_settings as $slug => $cfg ) : ?>
                <div class="dp-inline-panel"
                     data-inline-module="<?php echo esc_attr( $slug ); ?>"
                     id="settings-<?php echo esc_attr( $slug ); ?>">
                    <div class="dp-inline-panel-header">
                        <h2><?php echo esc_html( $cfg['title'] ?: $slug ); ?></h2>
                        <?php if ( ! empty( $cfg['description'] ) ) : ?>
                            <span class="dp-inline-panel-desc"><?php echo esc_html( $cfg['description'] ); ?></span>
                        <?php endif; ?>
                        <button type="button" class="dp-inline-panel-close" title="Sluiten">×</button>
                    </div>
                    <div class="dp-inline-panel-body">
                        <?php call_user_func( $cfg['callback'] ); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <script>
    (function(){
        var items  = document.querySelectorAll('.dp-sidebar-item');
        var panels = document.querySelectorAll('.dp-cat-panel');

        function activate(cat) {
            items.forEach(function(el)  { el.classList.toggle('is-active', el.dataset.cat === cat); });
            panels.forEach(function(el) { el.classList.toggle('is-visible', el.dataset.category === cat); });
            // Onthoud de actieve categorie, zodat we na een opslaan-redirect
            // (options.php dropt de #hash) in dezelfde tab blijven.
            try { sessionStorage.setItem('dp_webshop_active_cat', cat); } catch (e) {}
        }

        items.forEach(function(item) {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                activate(this.dataset.cat);
                // Preserve any settings-hash if open, otherwise just write the cat hash
                var openSlug = sessionStorage.getItem('dp_webshop_open_panel');
                history.replaceState(null, '', openSlug ? '#settings-' + openSlug : this.getAttribute('href'));
            });
        });

        /* --- Zoeken over alle categorieën heen --- */
        var zoekveld = document.getElementById('dp-module-search');
        var main     = document.querySelector('.dp-modules-main');
        var kaarten  = document.querySelectorAll('.dp-module-card');

        function zoek(term) {
            term = (term || '').trim().toLowerCase();

            if (!term) {
                // Terug naar normaal: alles zichtbaar, actieve categorie herstellen.
                main.classList.remove('is-searching', 'has-no-results');
                kaarten.forEach(function(k) { k.classList.remove('is-hidden'); });
                panels.forEach(function(p) { p.classList.remove('is-empty'); });
                var actief = document.querySelector('.dp-sidebar-item.is-active');
                if (actief) activate(actief.dataset.cat);
                return;
            }

            main.classList.add('is-searching');
            var totaal = 0;

            panels.forEach(function(panel) {
                var raak = 0;
                panel.querySelectorAll('.dp-module-card').forEach(function(kaart) {
                    var match = (kaart.dataset.zoek || '').indexOf(term) !== -1;
                    kaart.classList.toggle('is-hidden', !match);
                    if (match) raak++;
                });
                panel.classList.toggle('is-empty', raak === 0);
                totaal += raak;
            });

            main.classList.toggle('has-no-results', totaal === 0);
        }

        if (zoekveld) {
            zoekveld.addEventListener('input', function() { zoek(this.value); });
            zoekveld.addEventListener('keydown', function(e) {
                // Escape wist het veld en zet de weergave terug.
                if (e.key === 'Escape') { this.value = ''; zoek(''); return; }
                // Enter zou anders het omliggende formulier opslaan — dit veld
                // filtert alleen, het hoort niets te verzenden.
                if (e.key === 'Enter') { e.preventDefault(); }
            });
            // Een categorie aanklikken tijdens het zoeken wist de zoekterm,
            // anders klik je op iets dat niets lijkt te doen.
            items.forEach(function(item) {
                item.addEventListener('click', function() {
                    if (zoekveld.value) { zoekveld.value = ''; zoek(''); }
                });
            });
        }

        /* --- Inline settings panels --- */
        var inlineWrap   = document.getElementById('dp-inline-settings-wrap');
        var inlinePanels = document.querySelectorAll('.dp-inline-panel');
        var gearBtns     = document.querySelectorAll('.dp-module-settings-btn');

        function openInlinePanel(slug) {
            if (!inlineWrap) return;
            var target = document.querySelector('[data-inline-module="' + slug + '"]');
            if (!target) return;

            inlinePanels.forEach(function(p) { p.classList.remove('is-visible'); });
            gearBtns.forEach(function(b) { b.classList.toggle('is-open', b.dataset.module === slug); });

            target.classList.add('is-visible');
            inlineWrap.classList.add('is-open');
            sessionStorage.setItem('dp_webshop_open_panel', slug);
            history.replaceState(null, '', '#settings-' + slug);

            // Smooth-scroll AFTER the wrap becomes visible (next frame)
            requestAnimationFrame(function () {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        }

        function closeInlinePanel() {
            if (!inlineWrap) return;
            inlinePanels.forEach(function(p) { p.classList.remove('is-visible'); });
            gearBtns.forEach(function(b) { b.classList.remove('is-open'); });
            inlineWrap.classList.remove('is-open');
            sessionStorage.removeItem('dp_webshop_open_panel');
            // Strip the #settings-... hash but keep current category if any
            var activeCat = document.querySelector('.dp-sidebar-item.is-active');
            history.replaceState(null, '', activeCat ? activeCat.getAttribute('href') : location.pathname + location.search);
        }

        gearBtns.forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var slug = this.dataset.module;
                if (this.classList.contains('is-open')) {
                    closeInlinePanel();
                } else {
                    openInlinePanel(slug);
                }
            });
        });

        document.querySelectorAll('.dp-inline-panel-close').forEach(function(btn) {
            btn.addEventListener('click', closeInlinePanel);
        });

        /* --- Restore state from URL hash or sessionStorage --- */
        var hash = location.hash.replace('#', '');
        if (hash.indexOf('settings-') === 0) {
            var slug = hash.replace('settings-', '');
            // First activate the category that contains this module so the gear is reachable
            var btn = document.querySelector('.dp-module-settings-btn[data-module="' + slug + '"]');
            if (btn) {
                var card = btn.closest('.dp-cat-panel');
                if (card && card.dataset.category) activate(card.dataset.category);
                openInlinePanel(slug);
            }
        } else if (hash && document.querySelector('[data-cat="' + hash + '"]')) {
            activate(hash);
            // Re-open last panel from sessionStorage (within current cat)
            var lastSlug = sessionStorage.getItem('dp_webshop_open_panel');
            if (lastSlug && document.querySelector('.dp-module-settings-btn[data-module="' + lastSlug + '"]')) {
                openInlinePanel(lastSlug);
            }
        } else {
            // Geen categorie-hash in de URL (o.a. ná een instellingen-opslag-redirect):
            // herstel de laatst-actieve categorie zodat je in dezelfde tab blijft.
            var storedCat = sessionStorage.getItem('dp_webshop_active_cat');
            if (storedCat && document.querySelector('[data-cat="' + storedCat + '"]')) {
                activate(storedCat);
            }
            // Re-open last panel from sessionStorage
            var lastSlug = sessionStorage.getItem('dp_webshop_open_panel');
            if (lastSlug && document.querySelector('.dp-module-settings-btn[data-module="' + lastSlug + '"]')) {
                openInlinePanel(lastSlug);
            }
        }
    })();
    </script>
    <?php
}
