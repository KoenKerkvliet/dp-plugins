<?php
/**
 * Module Name: SMTP Mailer
 * Description: Configureer een SMTP-server voor betrouwbare e-mailverzending vanuit WordPress.
 * Category: tools
 * Version: 1.2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Restanten van een oudere versie opruimen.
 *
 * `dp_smtp_last_error` en `dp_smtp_debug_log` werden ooit weggeschreven maar
 * nooit meer gewist. Op sites die die versie hebben gedraaid staat er dus een
 * foutmelding van maanden geleden, terwijl de mail al lang weer werkt — en daar
 * ga je bij het zoeken naar een mailprobleem gegarandeerd op af. Voor inzicht
 * in de actuele situatie is er nu de module Mail Log.
 */
add_action( 'admin_init', function () {
    if ( get_option( 'dp_toolbox_smtp_opgeruimd' ) ) {
        return;
    }

    delete_option( 'dp_smtp_last_error' );
    delete_option( 'dp_smtp_debug_log' );

    update_option( 'dp_toolbox_smtp_opgeruimd', 1, false );
} );

/* ------------------------------------------------------------------ */
/*  Encryption helpers                                                 */
/* ------------------------------------------------------------------ */

/**
 * Stabiele encryptiesleutel — losgekoppeld van de WordPress auth-salt.
 *
 * Voorheen werd het SMTP-wachtwoord versleuteld met wp_salt('auth'). Die salt
 * is echter bedoeld om te kunnen roteren (security-keys regenereren, migratie,
 * host-onderhoud) — en elke rotatie maakte het opgeslagen wachtwoord
 * onontsleutelbaar, waarna mail stil faalde. Daarom nu een eigen, persistente
 * sleutel: een wp-config-constante als die bestaat, anders een eenmalig
 * gegenereerde optie (autoload uit).
 */
function dp_toolbox_smtp_enc_key() {
    if ( defined( 'DP_TOOLBOX_ENC_KEY' ) && DP_TOOLBOX_ENC_KEY ) {
        return DP_TOOLBOX_ENC_KEY;
    }
    $key = get_option( 'dp_toolbox_enc_key' );
    if ( ! $key ) {
        $key = wp_generate_password( 64, true, true );
        add_option( 'dp_toolbox_enc_key', $key, '', 'no' );
    }
    return $key;
}

function dp_toolbox_smtp_encrypt( $value ) {
    if ( $value === '' || $value === null ) {
        return '';
    }
    $key = dp_toolbox_smtp_enc_key();
    $iv  = substr( hash( 'sha256', $key ), 0, 16 );

    $encrypted = openssl_encrypt( $value, 'AES-256-CBC', $key, 0, $iv );
    return $encrypted !== false ? base64_encode( $encrypted ) : '';
}

function dp_toolbox_smtp_decrypt( $value ) {
    if ( empty( $value ) ) {
        return '';
    }
    $key = dp_toolbox_smtp_enc_key();
    $iv  = substr( hash( 'sha256', $key ), 0, 16 );

    $decoded   = base64_decode( $value );
    $decrypted = openssl_decrypt( $decoded, 'AES-256-CBC', $key, 0, $iv );
    return $decrypted !== false ? $decrypted : '';
}

/**
 * Ontsleutel volgens het oude schema (wp_salt('auth')-gebaseerd).
 * Uitsluitend voor eenmalige migratie van bestaande installaties — zolang de
 * auth-salt nog niet geroteerd is, kunnen we de waarde herstellen en met de
 * nieuwe stabiele sleutel her-versleutelen.
 */
function dp_toolbox_smtp_legacy_decrypt( $value ) {
    if ( empty( $value ) ) {
        return '';
    }
    $key = wp_salt( 'auth' );
    $iv  = substr( md5( $key ), 0, 16 );

    $decoded   = base64_decode( $value );
    $decrypted = openssl_decrypt( $decoded, 'AES-256-CBC', $key, 0, $iv );
    return $decrypted !== false ? $decrypted : '';
}

/* ------------------------------------------------------------------ */
/*  Get SMTP settings                                                  */
/* ------------------------------------------------------------------ */

function dp_toolbox_smtp_get_settings() {
    $defaults = [
        'host'       => 'smtp.emailit.com',
        'port'       => 587,
        'encryption' => 'tls',
        'auth'       => true,
        'username'   => 'emailit',
        'password'   => '',
        'from_email' => '',
        'from_name'  => '',
    ];

    $saved = get_option( 'dp_toolbox_smtp_settings', [] );
    $settings = wp_parse_args( $saved, $defaults );

    // Decrypt password
    if ( ! empty( $settings['password'] ) ) {
        $plain = dp_toolbox_smtp_decrypt( $settings['password'] );

        if ( $plain === '' ) {
            // Nieuwe sleutel faalde — probeer het oude (salt-gebaseerde) schema.
            $plain = dp_toolbox_smtp_legacy_decrypt( $settings['password'] );

            if ( $plain !== '' ) {
                // Hersteld: her-versleutel met de stabiele sleutel en bewaar (eenmalig).
                $saved['password'] = dp_toolbox_smtp_encrypt( $plain );
                update_option( 'dp_toolbox_smtp_settings', $saved );
                delete_option( 'dp_toolbox_smtp_decrypt_failed' );
            } elseif ( ! get_option( 'dp_toolbox_smtp_decrypt_failed' ) ) {
                // Onherstelbaar (salt geroteerd vóór migratie) — markeer voor admin-melding.
                update_option( 'dp_toolbox_smtp_decrypt_failed', 1 );
            }
        } elseif ( get_option( 'dp_toolbox_smtp_decrypt_failed' ) ) {
            delete_option( 'dp_toolbox_smtp_decrypt_failed' );
        }

        $settings['password'] = $plain;
    }

    return $settings;
}

/* ------------------------------------------------------------------ */
/*  Override PHPMailer with SMTP settings                               */
/* ------------------------------------------------------------------ */

add_action( 'phpmailer_init', function ( $phpmailer ) {
    $smtp = dp_toolbox_smtp_get_settings();

    if ( empty( $smtp['host'] ) ) {
        return;
    }

    $phpmailer->isSMTP();
    $phpmailer->Host       = $smtp['host'];
    $phpmailer->Port       = absint( $smtp['port'] );
    $phpmailer->SMTPSecure = $smtp['encryption'];
    $phpmailer->SMTPAuth   = (bool) $smtp['auth'];

    if ( $smtp['auth'] ) {
        $phpmailer->Username = $smtp['username'];
        $phpmailer->Password = $smtp['password'];
    }

    if ( ! empty( $smtp['from_email'] ) ) {
        $phpmailer->From = $smtp['from_email'];
    }
    if ( ! empty( $smtp['from_name'] ) ) {
        $phpmailer->FromName = $smtp['from_name'];
    }
} );

/* ------------------------------------------------------------------ */
/*  Override From headers (wp_mail filters)                            */
/* ------------------------------------------------------------------ */

add_filter( 'wp_mail_from', function ( $email ) {
    $smtp = dp_toolbox_smtp_get_settings();
    return ! empty( $smtp['from_email'] ) ? $smtp['from_email'] : $email;
} );

add_filter( 'wp_mail_from_name', function ( $name ) {
    $smtp = dp_toolbox_smtp_get_settings();
    return ! empty( $smtp['from_name'] ) ? $smtp['from_name'] : $name;
} );

/* ------------------------------------------------------------------ */
/*  JetFormBuilder: afzender gelijktrekken                             */
/* ------------------------------------------------------------------ */

/**
 * JetFormBuilder bouwt zijn e-mails met een expliciete From-header
 * ("From: naam <adres>"), standaard noreply@<sitehost>. Zo'n header wint van
 * de wp_mail_from-filter hierboven. Bij een mailprovider die alleen
 * geverifieerde domeinen accepteert — emailit doet dat — wordt die mail
 * geweigerd.
 *
 * Het gemene eraan is dat het half lijkt te werken: de bevestiging naar de
 * bezoeker komt vaak wél aan (Gmail is mild), terwijl de melding naar de
 * site-eigenaar stil verdwijnt. Deze twee filters trekken het weer gelijk.
 *
 * De filternamen bestaan alleen binnen JetFormBuilder; op sites zonder die
 * plugin vuren ze nooit.
 */
add_filter( 'jet-form-builder/send-email/from-address', function ( $email ) {
    $smtp = dp_toolbox_smtp_get_settings();
    return ! empty( $smtp['from_email'] ) ? $smtp['from_email'] : $email;
} );

add_filter( 'jet-form-builder/send-email/from-name', function ( $name ) {
    $smtp = dp_toolbox_smtp_get_settings();
    return ! empty( $smtp['from_name'] ) ? $smtp['from_name'] : $name;
} );

/* ------------------------------------------------------------------ */
/*  AJAX: send test email                                              */
/* ------------------------------------------------------------------ */

add_action( 'wp_ajax_dp_toolbox_smtp_test', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Geen toestemming.' );
    }

    check_ajax_referer( 'dp_toolbox_smtp', 'nonce' );

    $to = sanitize_email( $_POST['to'] ?? '' );
    if ( ! is_email( $to ) ) {
        wp_send_json_error( 'Ongeldig e-mailadres.' );
    }

    $subject = 'DP Toolbox — SMTP Testmail';
    $message = 'Dit is een testbericht van DP Toolbox SMTP Mailer.' . "\n\n"
             . 'Als je dit bericht ontvangt, werkt de SMTP-configuratie correct.' . "\n"
             . 'Verzonden op: ' . current_time( 'Y-m-d H:i:s' );

    // Capture PHPMailer errors
    global $phpmailer;
    $result = wp_mail( $to, $subject, $message );

    if ( $result ) {
        wp_send_json_success( [ 'message' => 'Testmail succesvol verzonden naar ' . $to ] );
    } else {
        $error = '';
        if ( isset( $phpmailer ) && $phpmailer instanceof \PHPMailer\PHPMailer\PHPMailer ) {
            $error = $phpmailer->ErrorInfo;
        }
        wp_send_json_error( 'Verzending mislukt.' . ( $error ? ' Fout: ' . $error : '' ) );
    }
} );

/* ------------------------------------------------------------------ */
/*  Conflict detection                                                 */
/* ------------------------------------------------------------------ */

add_filter( 'dp_toolbox_module_notices', function ( $notices ) {
    $smtp_plugins = [
        'wp-mail-smtp/wp_mail_smtp.php',
        'fluent-smtp/fluent-smtp.php',
        'post-smtp/postman-smtp.php',
        'easy-wp-smtp/easy-wp-smtp.php',
    ];

    foreach ( $smtp_plugins as $plugin ) {
        if ( is_plugin_active( $plugin ) ) {
            $data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
            $notices['smtp'] = 'Mogelijk conflict met ' . $data['Name'] . '. Gebruik slechts één SMTP-plugin.';
            break;
        }
    }

    return $notices;
} );

/* ------------------------------------------------------------------ */
/*  Notice: opgeslagen wachtwoord onontsleutelbaar                     */
/* ------------------------------------------------------------------ */

add_action( 'admin_notices', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    if ( ! get_option( 'dp_toolbox_smtp_decrypt_failed' ) ) {
        return;
    }
    $opt = get_option( 'dp_toolbox_smtp_settings', [] );
    if ( empty( $opt['password'] ) ) {
        return;
    }
    echo '<div class="notice notice-error"><p><strong>DP Toolbox — SMTP:</strong> '
       . 'Het opgeslagen SMTP-wachtwoord kon niet ontsleuteld worden. Waarschijnlijk zijn de '
       . 'WordPress security-keys (salts) gewijzigd. E-mail via SMTP werkt nu niet. '
       . 'Voer het wachtwoord / de API-key opnieuw in onder <em>DP Toolbox → SMTP Mailer</em>.'
       . '</p></div>';
} );

/* ------------------------------------------------------------------ */
/*  Admin page                                                         */
/* ------------------------------------------------------------------ */

if ( is_admin() ) {
    require_once __DIR__ . '/admin-page.php';
}
